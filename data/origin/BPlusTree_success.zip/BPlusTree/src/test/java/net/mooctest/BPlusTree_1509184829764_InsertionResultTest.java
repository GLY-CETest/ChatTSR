package net.mooctest;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;


public class BPlusTree_1509184829764_InsertionResultTest {

	@Test
	public void testInsertionResultIntegerNodeOfValueNodeOfValue() {
		//fail("Not yet implemented");
		ArrayList<Integer> keylist = new ArrayList<Integer>();
		keylist.add(1);
		keylist.add(2);
		keylist.add(3);
		ArrayList<Integer> valueslist = new ArrayList<Integer>();
		valueslist.add(1);
		valueslist.add(2);
		valueslist.add(3);
		
		LeafNode<Integer> leafNode = new LeafNode<Integer>(1);
		LeafNode< Integer> leafNode2 = new LeafNode<Integer>(2, leafNode);
		LeafNode<Integer> leafNode3 = new LeafNode<Integer>(3, leafNode, keylist, valueslist);
		
		InsertionResult<Integer> insertionResult = new InsertionResult<Integer>(1);
		InsertionResult<Integer> insertionResult2 = new InsertionResult<Integer>(2, new LeafNode<Integer>(2), new LeafNode<Integer>(2));
		InsertionResult<Integer> insertionResult3 = new InsertionResult<Integer>(2,leafNode3, leafNode3);
		
		
		assertEquals(1, insertionResult.getMinGap());
		assertEquals(leafNode3, insertionResult3.getRightNode());
		assertEquals(leafNode3, insertionResult3.getLeftNode());
		//System.out.println(insertionResult2.getLeftNode());
		assertEquals("2", insertionResult3.getSplitRootKey().toString());
		//System.out.println(insertionResult3.getSplitRootKey());
	}

}
