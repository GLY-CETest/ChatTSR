package net.mooctest;
import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;


public class BPlusTree_1509183799251_InternalNodeTest {

	 @Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer integer0 = new Integer(3047);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      LeafNode<String> leafNode1 = new LeafNode<String>(1, leafNode0);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode1, leafNode1);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      internalNode0.t = 610;
	      internalNode0.insert((-1), "#");
	      linkedList0.poll();
	      internalNode0.order(1);
	      leafNode1.keys = (List<Integer>) linkedList0;
	      internalNode0.order(0);
	      internalNode0.getNodeSize();
	      internalNode0.insert(0, "I");
	      InternalNode<Object> internalNode1 = new InternalNode<Object>(610);
	      internalNode0.order(1319);
	      internalNode1.t = 0;
	      // Undeclared exception!
	      try { 
	        internalNode1.getMaxChildNode();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer integer0 = new Integer(3047);
	      Integer.compareUnsigned(3047, 3047);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      LeafNode<String> leafNode1 = new LeafNode<String>(1, leafNode0);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode1, leafNode1);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      leafNode0.insert(Integer.MAX_VALUE, "s=M)AZe[gdR9");
	      internalNode0.t = 610;
	      internalNode0.insert((-1), "mLP>");
	      linkedList0.poll();
	      internalNode0.order(1);
	      internalNode0.t = 3047;
	      leafNode1.keys = (List<Integer>) linkedList0;
	      internalNode0.order(0);
	      // Undeclared exception!
	      try { 
	        internalNode0.toString();
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: -1, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer integer0 = new Integer(566);
	      linkedList0.add(integer0);
	      LinkedList<Node<Integer>> linkedList1 = new LinkedList<Node<Integer>>();
	      InternalNode<Integer> internalNode0 = new InternalNode<Integer>(566, linkedList0, linkedList1);
	      // Undeclared exception!
	      try { 
	        internalNode0.getChildNode(2);
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 0, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      LinkedList<Node<Object>> linkedList1 = new LinkedList<Node<Object>>();
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(3047, linkedList0, linkedList1);
	      Integer integer0 = new Integer(3047);
	      Integer.compareUnsigned(1631, 1631);
	      LeafNode<String> leafNode0 = new LeafNode<String>(3047);
	      LeafNode<String> leafNode1 = new LeafNode<String>(3047, leafNode0);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode1, leafNode1);
	      InternalNode<String> internalNode1 = new InternalNode<String>(3047, insertionResult0);
	      leafNode0.insert(Integer.MAX_VALUE, "s=M)AZe[gdR9");
	      internalNode1.insert((-1), "mLP>");
	      linkedList0.poll();
	      internalNode1.order(3047);
	      internalNode1.t = 1631;
	      internalNode1.order((-1));
	      internalNode0.getNodeSize();
	      internalNode0.keys = (List<Integer>) linkedList0;
	      LinkedList<Node<Integer>> linkedList2 = new LinkedList<Node<Integer>>();
	      internalNode1.insert(0, "");
	      InternalNode<Integer> internalNode2 = new InternalNode<Integer>(1631);
	      InsertionResult<Integer> insertionResult1 = new InsertionResult<Integer>(0);
	      InsertionResult<Integer> insertionResult2 = new InsertionResult<Integer>((Integer) null, internalNode2, internalNode2, insertionResult1);
	      InternalNode<Integer> internalNode3 = new InternalNode<Integer>(1631, insertionResult2);
	      // Undeclared exception!
	      try { 
	        internalNode3.order(609);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer.getInteger("");
	      linkedList0.add((Integer) null);
	      LinkedList<Node<Object>> linkedList1 = new LinkedList<Node<Object>>();
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(1740, linkedList0, linkedList1);
	      // Undeclared exception!
	      try { 
	        internalNode0.getChildNode(1740);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer integer0 = new Integer(3047);
	      Integer.compareUnsigned(1631, 1631);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      LeafNode<String> leafNode1 = new LeafNode<String>(1, leafNode0);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode1, leafNode1);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      leafNode0.insert(Integer.MAX_VALUE, "s=M)AZe[gdR9");
	      internalNode0.t = (-1);
	      // Undeclared exception!
	      try { 
	        internalNode0.insert((-1), "mLP>");
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -2
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      Integer integer0 = new Integer(362);
	      LeafNode<Integer> leafNode0 = new LeafNode<Integer>(362);
	      InsertionResult<Integer> insertionResult0 = new InsertionResult<Integer>(integer0, leafNode0, leafNode0);
	      Integer.compareUnsigned(111, 111);
	      InsertionResult<Integer> insertionResult1 = new InsertionResult<Integer>(integer0, leafNode0, leafNode0, insertionResult0);
	      InternalNode<Integer> internalNode0 = new InternalNode<Integer>(362, insertionResult1);
	      internalNode0.insert((-4495), integer0);
	      internalNode0.getMaxChildNode();
	      InsertionResult<Node<Integer>> insertionResult2 = new InsertionResult<Node<Integer>>((-3724));
	      assertEquals((-3724), insertionResult2.getMinGap());
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      LinkedList<Node<Object>> linkedList0 = new LinkedList<Node<Object>>();
	      Integer integer0 = new Integer(3047);
	      Integer.compareUnsigned(1631, 1631);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      leafNode0.insert(1, "s=M)AZe[gdR9");
	      internalNode0.insert((-1), "mLP>");
	      internalNode0.order(1);
	      internalNode0.t = 1631;
	      internalNode0.order(1);
	      assertEquals((-1), internalNode0.getNodeSize());
	      
	      LinkedList<Node<Integer>> linkedList1 = new LinkedList<Node<Integer>>();
	      internalNode0.insert(0, "");
	      assertEquals(0, internalNode0.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      Integer integer0 = new Integer(3047);
	      Integer.compareUnsigned(3047, 3047);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      leafNode0.insert(Integer.MAX_VALUE, "s0M)AZe[gdR9");
	      internalNode0.insert((-1), "mLP>");
	      internalNode0.order(1);
	      internalNode0.t = 3047;
	      internalNode0.order((-1));
	      LinkedList<Node<Integer>> linkedList0 = new LinkedList<Node<Integer>>();
	      internalNode0.getNodeSize();
	      InternalNode<Node<Integer>> internalNode1 = null;
	      try {
	        internalNode1 = new InternalNode<Node<Integer>>((-1));
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -2
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      Integer integer0 = new Integer(1);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      assertEquals(0, internalNode0.getNodeSize());
	      
	      leafNode0.insert(1, "s=M)AZe[gdR9");
	      internalNode0.insert((-1), "s=M)AZe[gdR9");
	      int int0 = internalNode0.order(1);
	      assertEquals((-1), internalNode0.getNodeSize());
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      LinkedList<Node<Object>> linkedList1 = new LinkedList<Node<Object>>();
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(3047, linkedList0, linkedList1);
	      Integer integer0 = new Integer(3047);
	      Integer.compareUnsigned(1631, 1631);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      LeafNode<String> leafNode1 = new LeafNode<String>(1, leafNode0);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode1, leafNode1);
	      InternalNode<String> internalNode1 = new InternalNode<String>(1, insertionResult0);
	      linkedList1.add((Node<Object>) internalNode0);
	      leafNode0.insert(Integer.MAX_VALUE, "s=M)AZe[gdR9");
	      internalNode1.insert((-1), "mLP>");
	      linkedList0.poll();
	      internalNode1.order(1);
	      internalNode1.t = 1631;
	      internalNode1.order((-1));
	      internalNode0.getNodeSize();
	      internalNode0.keys = (List<Integer>) linkedList0;
	      leafNode0.reverseToString();
	      LinkedList<Node<Integer>> linkedList2 = new LinkedList<Node<Integer>>();
	      internalNode1.getNodeSize();
	      // Undeclared exception!
	      try { 
	        internalNode0.order(1);
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: -1, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test11()  throws Throwable  {
	      Integer integer0 = new Integer(1);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      internalNode0.t = Integer.MAX_VALUE;
	      internalNode0.insert(Integer.MAX_VALUE, "s=M)AZe[gdR9");
	      assertEquals(1, internalNode0.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test12()  throws Throwable  {
	      Integer integer0 = new Integer(1);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      leafNode0.insert(Integer.MAX_VALUE, "s=M)AZe[gdR9");
	      internalNode0.insert((-1), "mLP>");
	      internalNode0.order(1);
	      // Undeclared exception!
	      try { 
	        internalNode0.insert((-1), "mLP>");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test13()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(105);
	      leafNode0.insert(368, integer0);
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(368);
	      InsertionResult<Object> insertionResult1 = new InsertionResult<Object>(integer0, leafNode0, leafNode0, insertionResult0);
	      leafNode0.t = 368;
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(368, insertionResult1);
	      internalNode0.order(2183);
	      internalNode0.toString();
	      internalNode0.getChildNode(229);
	      internalNode0.insert(3411, leafNode0);
	      Integer integer1 = new Integer(2183);
	      LeafNode<String> leafNode1 = null;
	      try {
	        leafNode1 = new LeafNode<String>((-685), (LeafNode<String>) null);
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -686
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test14()  throws Throwable  {
	      LinkedList<Node<Object>> linkedList0 = new LinkedList<Node<Object>>();
	      Integer integer0 = new Integer(3047);
	      LeafNode<String> leafNode0 = new LeafNode<String>(3047);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(3047, insertionResult0);
	      leafNode0.insert(4283, "s=M)AZe[gdR9");
	      internalNode0.order(4283);
	      LinkedList<Node<Integer>> linkedList1 = new LinkedList<Node<Integer>>();
	      assertEquals(0, linkedList1.size());
	  }

	  @Test(timeout = 4000)
	  public void test15()  throws Throwable  {
	      Integer integer0 = new Integer(1);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      internalNode0.t = 1;
	      InsertionResult<String> insertionResult1 = internalNode0.insert(1, "s=M)AZe[gdR9");
	      assertEquals(1, (int)insertionResult1.getSplitRootKey());
	      assertEquals(0, internalNode0.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test16()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer integer0 = new Integer(3047);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      LeafNode<String> leafNode1 = new LeafNode<String>(1, leafNode0);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode1, leafNode1);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      internalNode0.t = 610;
	      internalNode0.insert((-1), "mLP>");
	      internalNode0.order(1);
	      internalNode0.t = 3047;
	      internalNode0.order(0);
	      LinkedList<Node<Integer>> linkedList1 = new LinkedList<Node<Integer>>();
	      int int0 = internalNode0.getNodeSize();
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void test17()  throws Throwable  {
	      Integer integer0 = new Integer(372);
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(111);
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(372);
	      InsertionResult<Object> insertionResult1 = new InsertionResult<Object>(integer0, leafNode0, leafNode0, insertionResult0);
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(372, insertionResult1);
	      int int0 = internalNode0.order(2183);
	      internalNode0.getChildNode(229);
	      internalNode0.insert(3411, leafNode0);
	      Integer integer1 = new Integer(2183);
	      assertFalse(integer1.equals((Object)int0));
	  }

	  @Test(timeout = 4000)
	  public void test18()  throws Throwable  {
	      Integer integer0 = new Integer(362);
	      LeafNode<Integer> leafNode0 = new LeafNode<Integer>(362);
	      InsertionResult<Integer> insertionResult0 = new InsertionResult<Integer>(integer0, leafNode0, leafNode0);
	      Integer.compareUnsigned(111, 111);
	      InsertionResult<Integer> insertionResult1 = new InsertionResult<Integer>(integer0, leafNode0, leafNode0, insertionResult0);
	      InternalNode<Integer> internalNode0 = new InternalNode<Integer>(362, insertionResult1);
	      internalNode0.getMaxChildNode();
	      InsertionResult<Node<Integer>> insertionResult2 = new InsertionResult<Node<Integer>>((-3724));
	      InternalNode<Node<Integer>> internalNode1 = null;
	      try {
	        internalNode1 = new InternalNode<Node<Integer>>(2, insertionResult2);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test19()  throws Throwable  {
	  //    InsertionResult<String> insertionResult0 = new InsertionResult<String>(Integer.MAX_VALUE);
	  //    InternalNode<String> internalNode0 = new InternalNode<String>(Integer.MAX_VALUE, insertionResult0);
	  }

	  @Test(timeout = 4000)
	  public void test20()  throws Throwable  {
	      LinkedList<Node<Integer>> linkedList0 = new LinkedList<Node<Integer>>();
	      linkedList0.removeFirstOccurrence("");
	 //     InternalNode<Integer> internalNode0 = new InternalNode<Integer>(Integer.MAX_VALUE, (List<Integer>) null, linkedList0);
	  }

	  @Test(timeout = 4000)
	  public void test21()  throws Throwable  {
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(1162);
	      // Undeclared exception!
	      try { 
	        internalNode0.getChildNode(1162);
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test22()  throws Throwable  {
	      InternalNode<Integer> internalNode0 = new InternalNode<Integer>(815);
	      Integer integer0 = new Integer(815);
	      // Undeclared exception!
	      try { 
	        internalNode0.insert(815, integer0);
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test23()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      linkedList0.stream();
	      LinkedList<Node<Node<Integer>>> linkedList1 = new LinkedList<Node<Node<Integer>>>();
	      linkedList1.add((Node<Node<Integer>>) null);
	      InternalNode<Node<Integer>> internalNode0 = null;
	      try {
	        internalNode0 = new InternalNode<Node<Integer>>(1695, linkedList0, linkedList1);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test24()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer integer0 = new Integer(818);
	      linkedList0.offer(integer0);
	      LinkedList<Node<Integer>> linkedList1 = new LinkedList<Node<Integer>>();
	      InternalNode<Integer> internalNode0 = new InternalNode<Integer>(818, linkedList0, linkedList1);
	      // Undeclared exception!
	      try { 
	        internalNode0.insert(457, integer0);
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 0, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test25()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      LinkedList<Node<Object>> linkedList1 = new LinkedList<Node<Object>>();
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(3048, linkedList0, linkedList1);
	      assertEquals(0, internalNode0.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test26()  throws Throwable  {
	      InternalNode<Node<Integer>> internalNode0 = new InternalNode<Node<Integer>>(2860);
	      // Undeclared exception!
	      try { 
	        internalNode0.order(2860);
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test27()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      InternalNode<String> internalNode0 = null;
	      try {
	        internalNode0 = new InternalNode<String>(14, linkedList0, (List<Node<String>>) null);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test28()  throws Throwable  {
	      Integer integer0 = new Integer(388);
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(integer0, (Node<Object>) null, (Node<Object>) null);
	      InsertionResult<Object> insertionResult1 = new InsertionResult<Object>(integer0, (Node<Object>) null, (Node<Object>) null, insertionResult0);
	      InternalNode<Object> internalNode0 = null;
	      try {
	        internalNode0 = new InternalNode<Object>(388, insertionResult1);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test29()  throws Throwable  {
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(1822);
	      int int0 = internalNode0.getNodeSize();
	      assertEquals(0, int0);
	      
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      LinkedList<Node<Integer>> linkedList1 = new LinkedList<Node<Integer>>();
	      Integer integer0 = new Integer(1822);
	      assertFalse(integer0.equals((Object)int0));
	  }

	  @Test(timeout = 4000)
	  public void test30()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      LinkedList<Node<Integer>> linkedList1 = new LinkedList<Node<Integer>>();
	      InternalNode<Integer> internalNode0 = null;
	      try {
	        internalNode0 = new InternalNode<Integer>((-2851), linkedList0, linkedList1);
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -2852
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test31()  throws Throwable  {
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(0);
	      InternalNode<Object> internalNode0 = null;
	      try {
	        internalNode0 = new InternalNode<Object>(0, insertionResult0);
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -1
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test32()  throws Throwable  {
	      InternalNode<Object> internalNode0 = null;
	      try {
	        internalNode0 = new InternalNode<Object>((-473));
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -474
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test33()  throws Throwable  {
	   //   InternalNode<Object> internalNode0 = new InternalNode<Object>(Integer.MAX_VALUE);
	  }

	  @Test(timeout = 4000)
	  public void test34()  throws Throwable  {
	      LinkedList<Node<Object>> linkedList0 = new LinkedList<Node<Object>>();
	      Integer integer0 = new Integer(3047);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      internalNode0.t = 2;
	      leafNode0.insert(2147483607, "k6d3");
	      internalNode0.insert(3047, "s=M)AZe[gdR9");
	      LinkedList<Integer> linkedList1 = new LinkedList<Integer>();
	      InternalNode<Object> internalNode1 = new InternalNode<Object>(1);
	      // Undeclared exception!
	      try { 
	        internalNode1.toString();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test35()  throws Throwable  {
	      Integer integer0 = new Integer(1);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      internalNode0.t = 2;
	      InsertionResult<String> insertionResult1 = internalNode0.insert((-21), "s=M)AZe[gdR9");
	      assertEquals(0, internalNode0.getNodeSize());
	      assertEquals((-21), (int)insertionResult1.getSplitRootKey());
	  }

	  @Test(timeout = 4000)
	  public void test36()  throws Throwable  {
	      LinkedList<Node<Object>> linkedList0 = new LinkedList<Node<Object>>();
	      Integer integer0 = new Integer(3047);
	      LeafNode<String> leafNode0 = new LeafNode<String>(3047);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(3047, insertionResult0);
	      leafNode0.insert(4283, "s=M)AZe[gdR9");
	      internalNode0.insert((-1), "s=M)AZe[gdR9");
	      Integer integer1 = new Integer(4283);
	      int int0 = internalNode0.order((int) integer1);
	      assertEquals(1, internalNode0.getNodeSize());
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void test37()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer integer0 = new Integer(3047);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      LeafNode<String> leafNode1 = new LeafNode<String>(1, leafNode0);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode1, leafNode1);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      internalNode0.t = 610;
	      internalNode0.insert((-1), "z");
	      linkedList0.poll();
	      internalNode0.order(1);
	      leafNode1.keys = (List<Integer>) linkedList0;
	      internalNode0.order(0);
	      internalNode0.insert(0, "z");
	      InternalNode<Object> internalNode1 = new InternalNode<Object>(610);
	      // Undeclared exception!
	      try { 
	        internalNode1.getMaxChildNode();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test38()  throws Throwable  {
	      int int0 = 372;
	      Integer integer0 = new Integer(372);
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(372);
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(372);
	      InsertionResult<Object> insertionResult1 = new InsertionResult<Object>(integer0, leafNode0, leafNode0, insertionResult0);
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(372, insertionResult1);
	      int int1 = 2190;
	      internalNode0.order(2190);
	      // Undeclared exception!
	      try { 
	        internalNode0.toString();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test39()  throws Throwable  {
	      Integer integer0 = new Integer(1);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, leafNode0, leafNode0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, insertionResult0);
	      leafNode0.insert(2147483644, "s=)M)AZe[g;R9");
	      internalNode0.insert((-1), "s=)M)AZe[g;R9");
	      internalNode0.order(1);
	      // Undeclared exception!
	      try { 
	        internalNode0.insert((-1), "s=)M)AZe[g;R9");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }
}
