package net.mooctest;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;


public class BPlusTree_1509184829764_BPlusTreeTest {

	@Test
	public void testBPlusTreeInt() {
		//fail("Not yet implemented");
		ArrayList<Integer> keylist = new ArrayList<Integer>();
		keylist.add(1);
		keylist.add(2);
		keylist.add(3);
		ArrayList<Integer> valueslist = new ArrayList<Integer>();
		valueslist.add(1);
		valueslist.add(2);
		valueslist.add(3);
		
		LeafNode leafNode = new LeafNode(1);
		LeafNode leafNode2 = new LeafNode(2, leafNode);
		LeafNode leafNode3 = new LeafNode(3, leafNode, keylist, valueslist);
		Node node = new LeafNode(5);
		BPlusTree bPlusTree = new BPlusTree(5);
		BPlusTree bPlusTree2 = new BPlusTree(2,2);
		
		bPlusTree.insert(0, 1);
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 2; j++) {
				bPlusTree.insert(i, j);
			}
		}
		
		assertEquals("", bPlusTree2.reverseInOrder());
		assertEquals(2147483647, bPlusTree2.getMinGap());
		assertEquals(0, bPlusTree2.getSize());
		String string = "Filter stopped the search."+"\n"+"Current False Positive Probability: 0.0";
		assertNull(bPlusTree2.search(1));
//		bPlusTree2.search(1);
//		System.out.println();
		
	}

}
