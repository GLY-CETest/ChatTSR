package net.mooctest;
import static org.junit.Assert.*;

import org.junit.Test;


public class BPlusTree_1509183799251_IntegerBloomFilterTest {

	 @Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter((-2483), (-2483), (-2483));
	      // Undeclared exception!
	      try { 
	        integerBloomFilter0.contains((-424));
	      
	      } catch(NegativeArraySizeException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(483.7157701, 0);
	      integerBloomFilter0.getTotalHashFunctions();
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter((-1686), (-1686), 1);
	      integerBloomFilter0.clear();
	      integerBloomFilter0.getFilterSize();
	      integerBloomFilter0.add((-1686));
	      integerBloomFilter0.getExpectedFalsePositiveProbability();
	      integerBloomFilter0.clear();
	      integerBloomFilter0.clear();
	      integerBloomFilter0.add(1350);
	      integerBloomFilter0.add(1);
	      integerBloomFilter0.add(1350);
	      integerBloomFilter0.add(2842596);
	      integerBloomFilter0.getBitsPerElement();
	      integerBloomFilter0.add((-16));
	      integerBloomFilter0.clear();
	      integerBloomFilter0.getTotalHashFunctions();
	      integerBloomFilter0.add(0);
	      integerBloomFilter0.clear();
	      integerBloomFilter0.add(0);
	      integerBloomFilter0.getBitsPerElement();
	      integerBloomFilter0.getCurrentFalsePositiveProbability();
	      integerBloomFilter0.getCurrentFalsePositiveProbability();
	      integerBloomFilter0.add(1);
	      integerBloomFilter0.getBitsPerElement();
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(1736, 1852, 1852);
	      integerBloomFilter0.add(1736);
	      integerBloomFilter0.clear();
	      integerBloomFilter0.getExpectedFalsePositiveProbability();
	      integerBloomFilter0.getCurrentFalsePositiveProbability();
	      integerBloomFilter0.add(1736);
	      integerBloomFilter0.clear();
	      integerBloomFilter0.clear();
	      integerBloomFilter0.getCurrentFalsePositiveProbability();
	      integerBloomFilter0.clear();
	      integerBloomFilter0.add(0);
	      integerBloomFilter0.add(0);
	      integerBloomFilter0.clear();
	      integerBloomFilter0.add(0);
	      integerBloomFilter0.getFalsePositiveProbability(0.0);
	      integerBloomFilter0.getBitsPerElement();
	      integerBloomFilter0.getFilterSize();
	      // Undeclared exception!
	      integerBloomFilter0.contains(3215072);
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(3337, 3337, 1475);
	      integerBloomFilter0.getExpectedFalsePositiveProbability();
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = null;
	      try {
	        integerBloomFilter0 = new IntegerBloomFilter(487, (-2480), 487);
	      
	      } catch(NegativeArraySizeException e) {
	         //
	         // nbits < 0: -1207760
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(1549, 0, 0);
	      integerBloomFilter0.getTotalHashFunctions();
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter((-1938.298), 701);
	      integerBloomFilter0.getCurrentFalsePositiveProbability();
	      integerBloomFilter0.getBitsPerElement();
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(1, 0, 1);
	      integerBloomFilter0.clear();
	      integerBloomFilter0.clear();
	      // Undeclared exception!
	      try { 
	        integerBloomFilter0.add(2746);
	        fail("Expecting exception: ArithmeticException");
	      
	      } catch(ArithmeticException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = null;
	      try {
	        integerBloomFilter0 = new IntegerBloomFilter(2938.30632, 2124);
	      
	      } catch(NegativeArraySizeException e) {
	         //
	         // nbits < 0: -33984
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(1.0, 0);
	      integerBloomFilter0.add(0);
	      integerBloomFilter0.clear();
	      integerBloomFilter0.add(0);
	      integerBloomFilter0.getExpectedFalsePositiveProbability();
	      integerBloomFilter0.getFilterSize();
	      integerBloomFilter0.getFalsePositiveProbability(0);
	  }

	  @Test(timeout = 4000)
	  public void test11()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(0, 0);
	      integerBloomFilter0.getCurrentFalsePositiveProbability();
	  }

	  @Test(timeout = 4000)
	  public void test12()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(1695, 1720, 1695);
	      integerBloomFilter0.add(754);
	      integerBloomFilter0.clear();
	      integerBloomFilter0.contains(0);
	      integerBloomFilter0.contains(1);
	      integerBloomFilter0.add(1);
	      integerBloomFilter0.getCurrentFalsePositiveProbability();
	      integerBloomFilter0.add(1);
	      integerBloomFilter0.getFilterSize();
	      // Undeclared exception!
	      integerBloomFilter0.add((-2920));
	  }

	  @Test(timeout = 4000)
	  public void test13()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(2186, 0, 2178);
	      integerBloomFilter0.getFilterSize();
	      // Undeclared exception!
	      try { 
	        integerBloomFilter0.contains(3799);
	      
	      } catch(ArithmeticException e) {
	         //
	         // / by zero
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test14()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(1, 1, 1);
	      integerBloomFilter0.clear();
	      integerBloomFilter0.clear();
	      integerBloomFilter0.add((-1399));
	      integerBloomFilter0.clear();
	      integerBloomFilter0.clear();
	      integerBloomFilter0.clear();
	      integerBloomFilter0.add(0);
	      integerBloomFilter0.add((-1399));
	      integerBloomFilter0.clear();
	      integerBloomFilter0.add((-1910));
	      integerBloomFilter0.contains(0);
	      integerBloomFilter0.getFalsePositiveProbability((-1910));
	      integerBloomFilter0.add(0);
	      integerBloomFilter0.getFalsePositiveProbability(Double.NEGATIVE_INFINITY);
	      integerBloomFilter0.getFilterSize();
	      integerBloomFilter0.getBitsPerElement();
	      integerBloomFilter0.add(1);
	      integerBloomFilter0.getExpectedFalsePositiveProbability();
	      integerBloomFilter0.contains(0);
	      integerBloomFilter0.getExpectedFalsePositiveProbability();
	      integerBloomFilter0.clear();
	      integerBloomFilter0.getFalsePositiveProbability(0.0);
	      integerBloomFilter0.contains(0);
	      integerBloomFilter0.getCurrentFalsePositiveProbability();
	      integerBloomFilter0.getTotalHashFunctions();
	      integerBloomFilter0.add(0);
	      assertEquals(0.6321205588285577, integerBloomFilter0.getCurrentFalsePositiveProbability(), 0.01);
	  }

	  @Test(timeout = 4000)
	  public void test15()  throws Throwable  {
	      IntegerBloomFilter integerBloomFilter0 = new IntegerBloomFilter(1741.51, (-93));
	      integerBloomFilter0.getFilterSize();
	      // Undeclared exception!
	      try { 
	        integerBloomFilter0.add((-2639));
	      
	      } catch(NegativeArraySizeException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

}
