package net.mooctest;
import static org.junit.Assert.*;

import org.junit.Test;


public class BPlusTree_1509184036737_IntegerBloomFilterTest {

	@Test
	public void test() {
		IntegerBloomFilter inFilter=new IntegerBloomFilter(0.000001, 10);
		inFilter.add(40);
		assertTrue(inFilter.contains(40));
		assertFalse(inFilter.contains(50));
		assertEquals(29, inFilter.getBitsPerElement());
		assertEquals(290, inFilter.getFilterSize());
		assertEquals(20, inFilter.getTotalHashFunctions());
		inFilter.clear();
		assertFalse(inFilter.contains(40));
	}
	@Test
	public void test2(){
		IntegerBloomFilter inFilter=new IntegerBloomFilter(0.000001, 10);
		double efpp=inFilter.getExpectedFalsePositiveProbability();
		assertTrue(efpp==8.89124548750276E-7);
		inFilter.add(40);
		double cfpp=inFilter.getCurrentFalsePositiveProbability();
		
		assertTrue(cfpp==2.984336515583906E-24);
	}

}
