package net.mooctest;
import static org.junit.Assert.*;

import org.junit.Test;


public class BPlusTree_1509183799251_InsertionResultTest {

	@Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(0);
	      InsertionResult<String> insertionResult1 = new InsertionResult<String>(integer0, (Node<String>) null, (Node<String>) null, insertionResult0);
	      insertionResult1.getSplitRootKey();
	      assertEquals(0, insertionResult1.getMinGap());
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      Integer integer0 = new Integer(1);
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(integer0, (Node<String>) null, (Node<String>) null);
	      Integer integer1 = insertionResult0.getSplitRootKey();
	      assertEquals(1, (int)integer1);
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      Integer integer0 = new Integer((-257));
	      InternalNode<Integer> internalNode0 = new InternalNode<Integer>(1);
	      InsertionResult<Integer> insertionResult0 = new InsertionResult<Integer>(0);
	      InsertionResult<Integer> insertionResult1 = new InsertionResult<Integer>(integer0, internalNode0, internalNode0, insertionResult0);
	      insertionResult1.getSplitRootKey();
	      assertEquals(0, insertionResult1.getMinGap());
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      InsertionResult<Integer> insertionResult0 = new InsertionResult<Integer>(0);
	      insertionResult0.getRightNode();
	      assertEquals(0, insertionResult0.getMinGap());
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = leafNode0.insert(0, "");
	      assertEquals(Integer.MAX_VALUE, insertionResult0.getMinGap());
	      
	      InsertionResult<String> insertionResult1 = new InsertionResult<String>(integer0, (Node<String>) null, leafNode0);
	      Node<String> node0 = insertionResult1.getRightNode();
	      assertNotNull(node0);
	      assertEquals(0, insertionResult1.getMinGap());
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(1);
	      int int0 = insertionResult0.getMinGap();
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>((-1));
	      int int0 = insertionResult0.getMinGap();
	      assertEquals((-1), int0);
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      InternalNode<Object> internalNode0 = new InternalNode<Object>(1);
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(integer0, internalNode0, internalNode0);
	      Node<Object> node0 = insertionResult0.getLeftNode();
	      assertEquals(0, node0.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = leafNode0.insert(0, "");
	      Node<String> node0 = insertionResult0.getLeftNode();
	      assertEquals(Integer.MAX_VALUE, insertionResult0.getMinGap());
	      assertEquals(1, node0.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      InsertionResult<String> insertionResult0 = null;
	      try {
	        insertionResult0 = new InsertionResult<String>((Integer) null, (Node<String>) null, (Node<String>) null, (InsertionResult<String>) null);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(0);
	      int int0 = insertionResult0.getMinGap();
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void test11()  throws Throwable  {
	      InsertionResult<String> insertionResult0 = new InsertionResult<String>(0);
	      insertionResult0.getSplitRootKey();
	      assertEquals(0, insertionResult0.getMinGap());
	  }

	  @Test(timeout = 4000)
	  public void test12()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      InsertionResult<String> insertionResult0 = leafNode0.insert(0, "");
	      Node<String> node0 = insertionResult0.getRightNode();
	      assertEquals(0, node0.getNodeSize());
	      assertEquals(Integer.MAX_VALUE, insertionResult0.getMinGap());
	  }

	  @Test(timeout = 4000)
	  public void test13()  throws Throwable  {
	      InsertionResult<Integer> insertionResult0 = new InsertionResult<Integer>(0);
	      insertionResult0.getLeftNode();
	      assertEquals(0, insertionResult0.getMinGap());
	  }
}
