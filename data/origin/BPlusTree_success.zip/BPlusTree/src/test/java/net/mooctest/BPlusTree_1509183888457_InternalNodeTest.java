package net.mooctest;
import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class BPlusTree_1509183888457_InternalNodeTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		InternalNode node=new InternalNode(5);
		/*node.insert(0, new Integer(0));
		node.insert(1, new Integer(1));
		assertEquals(2,node.getNodeSize());
		System.out.println(node.order(0));*/
		InsertionResult split=new InsertionResult(5);
		split=new InsertionResult(2, new LeafNode(5), new LeafNode(3));
		node=new InternalNode(5, split);
		List<Integer> keys=new ArrayList<Integer>();
		keys.add(1);keys.add(2);
		keys.add(3);keys.add(4);
		List<Node> children=new ArrayList<Node>();
		LeafNode n1=new LeafNode(1);
		n1.insert(1, new Integer(1));
		/*n1.insert(3, new Integer(3));
		LeafNode n2=new LeafNode(1);
		n2.insert(1, new Integer(1));
		n2.insert(3, new Integer(3));
		LeafNode n3=new LeafNode(1);
		n3.insert(1, new Integer(1));
		n3.insert(3, new Integer(3));*/
		children.add(new LeafNode(1));
		children.add(new LeafNode(2));
		children.add(new LeafNode(3));
		node=new InternalNode(5, keys, children);
		try {
			Class zz=Class.forName("InternalNode");
			Field f=zz.getDeclaredField("totalWeight");
			f.setAccessible(true);
			f.set(node, 5);
			node.order(4);
			
		} catch (Exception e) {
		}
		
	}

}
