package net.mooctest;
import static org.junit.Assert.*;

import java.awt.List;
import java.util.ArrayList;

import org.junit.Test;


public class BPlusTree_1509184332697_BPlusTreeTest {

	@Test
	public void test() {
		try{BPlusTree bplus = new BPlusTree(0);}catch(IllegalArgumentException e){}
		BPlusTree bplus1 = new BPlusTree(2);
		BPlusTree bplus2 = new BPlusTree(2,1);
		Integer i =5;
		Integer i1 =6;
		Integer i2 =1;
		assertEquals("",bplus2.reverseInOrder());
		
		assertEquals(2147483647,bplus1.getMinGap());
//		assertEquals("",bplus1.search(0).toString());
		LeafNode leaf= new LeafNode(1);
//		assertEquals("",leaf.getValue(0).toString());
		assertEquals(null,bplus2.search(0));
		bplus1.search(0);
		
		
		
		bplus1.insert(0,i.shortValue());
		bplus2.insert(0,i.shortValue());
		bplus2.insert(3,i1.shortValue());
		assertEquals("5",bplus2.search(0).toString());
		
		assertEquals("0,",bplus1.reverseInOrder());
		assertEquals("3,0,",bplus2.reverseInOrder());
		
		assertEquals(2,bplus2.getSize());
		assertEquals(2147483647,bplus2.getMinGap());
		
		assertEquals(1,bplus2.order(0));
		assertEquals(-1,bplus2.order(2));
		assertEquals("03",bplus2.inOrder());
		assertEquals("0",bplus1.inOrder());
		
		assertEquals("0#3",bplus2.toString());
		
		
		IntegerBloomFilter interb = new IntegerBloomFilter(1,2);
		IntegerBloomFilter interb1 = new IntegerBloomFilter(1.1,2);
		assertEquals(0,interb.getBitsPerElement());
		assertEquals(1.0,interb.getCurrentFalsePositiveProbability(),0.01);
		assertEquals(1.0,interb.getExpectedFalsePositiveProbability(),0.01);
		interb.clear();
		interb.add(1);
		assertTrue(interb.contains(1));
		assertEquals(0,interb.getTotalHashFunctions());
		assertEquals(0,interb.getFilterSize());
		
		
		LeafNode l = new LeafNode(4);
		LeafNode l1 = new LeafNode(5,l);
		
		l1.insert(0, i.shortValue());
		l1.insert(0, i1.shortValue());
		l1.insert(1, i.shortValue());
		l1.insert(100, i.shortValue());
		l1.insert(1000, i.shortValue());
		l1.insert(10, i.shortValue());
		assertEquals("10,1,0,",l1.reverseToString());
		assertEquals(1,l1.calculateGap(1));
		assertEquals(2,l1.findLessThanOrEqualToKey(2));
		assertEquals(1,l1.findLessThanOrEqualToKey(1));
		assertEquals(0,l1.findLessThanOrEqualToKey(0));
		assertEquals(0,l1.findLessThanOrEqualToKey(-1));
		
		
		InternalNode inode = new InternalNode(5);
		try{InternalNode inode1 = new InternalNode(4,inode.insert(0, i.shortValue()));} catch(Exception e){}
		
		
		
	}

}
