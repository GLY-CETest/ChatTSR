package net.mooctest;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class BPlusTree_1509183888457_LeafNodeTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInsert() {
		LeafNode node=new LeafNode(5);
		node.insert(0, new Integer(0));
		node.insert(1, new Integer(1));
		assertEquals(2,node.getNodeSize());
		
		node=new LeafNode(10, new LeafNode(3));
		assertEquals(-1,node.order(0));
		node.insert(4, new Integer(4));
		node.insert(5, new Integer(5));
		Integer r=(Integer) node.getValue(4);
		assertEquals(4, r.intValue());
		assertNull(node.getValue(10));
		node.insert(6,new Integer(6));
		node.insert(7,new Integer(7));
		node.insert(8,new Integer(8));
	}

	@Test
	public void testOrder() {
		try {
			Class nodeC=Class.forName("Node");
			//Method m=nodeC.getMethod("findLessThanOrEqualToKey", int.class);
			
		} catch (ClassNotFoundException e) {
		}
	}

	@Test
	public void testGetNodeSize() {
		
	}

	@Test
	public void testInternalNodeInt() {
		
	}

	@Test
	public void testInternalNodeIntListOfIntegerListOfNodeOfValue() {
		
	}

	@Test
	public void testInternalNodeIntInsertionResultOfValue() {
		
	}

	@Test
	public void testGetChildNode() {
		
	}

	@Test
	public void testGetMaxChildNode() {
		
	}

	@Test
	public void testToString() {
		
	}
	
	@Test
	public void testOther1(){
		LeafNode prev=new LeafNode(5);
		List<Integer> inList=new ArrayList<Integer>();
		inList.add(1);inList.add(2);inList.add(3);
		List<String> ss=new ArrayList<String>();
		ss.add("1");ss.add("2");ss.add("3");
		LeafNode node=new LeafNode(5, prev, inList, ss);
	}

}
