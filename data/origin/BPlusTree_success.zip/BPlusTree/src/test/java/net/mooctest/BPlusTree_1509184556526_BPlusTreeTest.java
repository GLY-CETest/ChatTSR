package net.mooctest;
import static org.junit.Assert.*;

import org.junit.Test;


public class BPlusTree_1509184556526_BPlusTreeTest {

	
	BPlusTree bpt1=new BPlusTree(1);
	BPlusTree bpt2=new BPlusTree(3);
	BPlusTree bpt3=new BPlusTree(6,6);
	BPlusTree bpt5=new BPlusTree(2,1);
	BPlusTree bpt6=new BPlusTree(1,2);
	LeafNode ln=new LeafNode(3);
	InsertionResult ir=new InsertionResult(1,ln.getNext(),ln.getPrev());
	@Test
	public void test() {
		bpt1.getMinGap();
		bpt1.order(0);
		bpt1.reverseInOrder();
		bpt2.insert(2, "");
		bpt2.inOrder();
		bpt2.order(2);
		bpt2.search(2);
		bpt1.search(3);
		bpt1.toString();
		bpt5.insert(2, "o");
		bpt6.insert(0,bpt1);
		bpt6.order(2);
		bpt6.insert(2, "");
		ln.getValue(1);
		ln.reverseToString();
		ir.getLeftNode();
		try {
			LeafNode ln1=new LeafNode(0);
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		try {
			BPlusTree bpt4=new BPlusTree(0,1);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			BPlusTree bpt=new BPlusTree(0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bpt6.search(30);
		bpt3.getSize();
		bpt3.insert(2, 2);
		bpt3.reverseInOrder();
		ln.getPrev();
		
		try {
			LeafNode ln1=new LeafNode(0);
			//ln1.toString();
			ln1.findLessThanOrEqualToKey(1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ln.calculateGap(0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			try {
				ln.calculateGap(4);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ln.insert(8, 7);
			try {
				ln.getNext().findLessThanOrEqualToKey(0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			bpt2.getMinGap();
			bpt3.search(2).toString();
			try {
				BPlusTree b=new BPlusTree(0,2);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			bpt3.insert(1, null);
			bpt5.insert(0, bpt3);
			bpt5.insert(6, "0o");
			bpt3.insert(12, "tp");
			bpt1.insert(4, "oop");
			bpt3.toString();
	}

}
