package net.mooctest;
import static org.junit.Assert.*;

import org.junit.Test;



public class BPlusTree_1509184627529_BPlusTreeTest {

	@Test
	public void testBPlusTreeInt() {
		BPlusTree  tree = new BPlusTree(2);
		
		assertEquals(tree.getSize(),0);
		assertEquals(tree.getMinGap(),Integer.MAX_VALUE);
	}

	@Test
	public void testBPlusTreeIntInt() {
		BPlusTree  tree = new BPlusTree(2,10);
		
		assertEquals(tree.getSize(),0);
		assertEquals(tree.getMinGap(),Integer.MAX_VALUE);
		
	}

	@Test
	public void testSearch() {
		BPlusTree tree = new BPlusTree(2);
		
		BPlusTree tree2 = new BPlusTree(50,100);
		
		assertNull(tree.search(10));
		
		for(int i=0;i<50;i++)
			tree2.insert(i, "s"+i);
		
		assertNull(tree2.search(55));
		
		for(int i=0;i<50;i++)
			assertEquals("",tree2.search(i),"s"+i);
		
	}

	@Test
	public void testInsert() {
		
		BPlusTree tree2 = new BPlusTree(2,100);
		
		
		for(int i =1; i <=2;i++)
			tree2.insert(i, "s"+i);
		
		assertEquals("",tree2.search(1),"s1");
		assertEquals("",tree2.search(2),"s2");
	}

	@Test
	public void testReverseInOrder() {
		BPlusTree tree2 = new BPlusTree(5,100);
		
		
		for(int i =1; i <=9;i++)
			tree2.insert(i, "s"+i);
		
		//System.out.println(tree2.reverseInOrder());
		
		assertEquals(tree2.reverseInOrder(),"9,8,7,6,5,4,3,2,1,");
	}

	@Test
	public void testOrder() {
		BPlusTree tree2 = new BPlusTree(10,200);
		
		
		for(int i =1; i <=150;i++)
			tree2.insert(i, "s"+i);
		
		tree2.insert(170, "s"+170);
		tree2.insert(159, "s"+159);
		tree2.insert(167, "s"+167);
		
		assertEquals(tree2.order(159),151);
		assertEquals(tree2.order(170),153);
		assertEquals(tree2.order(167),152);
		
		//System.out.println(tree2.order(8));
		for(int i=1;i<= 150;i++)
			assertEquals(tree2.order(i),i);
		
		
		
		assertEquals(tree2.order(251),-1);
		assertEquals(tree2.order(-1),-1);
	}

	@Test
	public void testInOrder() {
		BPlusTree tree = new BPlusTree(2,10);
		
		
		tree.insert(1, "s1");
		tree.insert(2, "s2");
		tree.insert(3, "s3");
		
		//System.out.println(tree.inOrder());
		
		assertEquals(tree.inOrder(),"123");
	}

	@Test
	public void testToString(){
		BPlusTree tree = new BPlusTree(10,10);
		
		assertEquals(tree.toString(),"");
		
		tree.insert(1, "s1");
		tree.insert(2, "s2");
		
		assertEquals(tree.toString(),"1,2");
	}
}
