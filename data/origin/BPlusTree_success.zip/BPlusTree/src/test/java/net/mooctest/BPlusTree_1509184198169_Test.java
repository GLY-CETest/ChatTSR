package net.mooctest;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;


public class BPlusTree_1509184198169_Test {

	@Test
	public void test() {
		IntegerBloomFilter i1=new IntegerBloomFilter(1,2,3);
		IntegerBloomFilter i2=new IntegerBloomFilter(0.1,1);
		assertEquals(0.0001,1.0E-4,i2.getExpectedFalsePositiveProbability());
		assertEquals(0.0001,1.0E-4,i2.getCurrentFalsePositiveProbability());
		i1.clear();
		i1.add(4);
		assertEquals(true,i1.contains(4));
		assertEquals(false,i2.contains(0));
		assertEquals(1,i1.getBitsPerElement());
		assertEquals(2,i1.getFilterSize());
		assertEquals(3,i1.getTotalHashFunctions());
		
		Node n1=null;
		InsertionResult ii1=new InsertionResult(1,n1,n1);
		InsertionResult ii2=new InsertionResult(2,n1,n1,ii1);
		InsertionResult ii3=new InsertionResult(3);
		assertEquals(n1,ii1.getLeftNode());
		assertEquals(n1,ii1.getRightNode());
		ii1.getSplitRootKey();
		
		
		List values=new ArrayList();
		List keys=new ArrayList();
		int a=4;
		keys.add(a);
		values.add(a);
		LeafNode l1=new LeafNode(1);
		LeafNode l2=new LeafNode(2,l1);
		LeafNode l3=new LeafNode(3,l1,keys,values);
		assertEquals(-1,l1.order(1));
		assertEquals(0,l3.order(4));
		assertEquals(null,l1.getValue(1));
		assertEquals(4,l3.getValue(4));
		assertEquals(null,l3.insert(4, l1));
		assertEquals(l2,l3.getNext());
		assertEquals(l3,l2.getPrev());
		assertEquals("4",l3.toString());
		assertEquals("4,",l3.reverseToString());
		
		List<Node> children = new ArrayList<Node>();
		List<Integer> keys1=new ArrayList();
		keys1.add(1);
		children.add(l1);
		InternalNode iii1=new InternalNode(1);
		InternalNode iii2=new InternalNode(2,keys1,children);
		InternalNode iii3=new InternalNode(5,keys1,children);
		assertEquals(0,iii1.getNodeSize());
		assertEquals(-1,iii2.order(3));
		assertEquals(-1,iii2.order(0));
		iii2.insert(1, ii2);
		assertEquals("1",iii3.toString());
		
		 BPlusTree b1=new  BPlusTree(1);
		 BPlusTree b2=new  BPlusTree(1,2);
		 b1.insert(1, b1);
		 b1.search(0);
		 assertEquals("1,",b1.reverseInOrder());
		 assertEquals(1,b1.getSize());
		 assertEquals(2147483647,b1.getMinGap());
		 assertEquals(1,b1.order(1));
		 assertEquals(-1,b2.order(1));
		 assertEquals("",b2.toString());
		 try{
		 assertEquals("1",b2.inOrder());}
		 catch(Exception e){}

	}

}
