package net.mooctest;
import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;


public class BPlusTree_1509184591864_BPlusTreeTest {

	@Test
	public void test() {
		
		LeafNode  leafNode1 = new LeafNode(1);
		LeafNode  leafNode2 = new LeafNode(2);
		LeafNode  leafNode3 = new LeafNode(3);
		LeafNode leafNode11 = new LeafNode(11,leafNode1);
		LeafNode leafNode111 = new LeafNode(1111,leafNode1);
		
		
		assertEquals(0, leafNode1.getNodeSize());
		//assertEquals(-1, leafNode1.getNext());
		
		
		assertEquals(null, leafNode1.getPrev());
		
		assertEquals(-1, leafNode1.order(2));
		
		assertEquals(null, leafNode1.getValue(1));
		assertEquals(null, leafNode1.getValue(11));
		
		List list = new LinkedList<>();

		list.add(leafNode3);
		list.add(leafNode2);
		
		List list2 = new LinkedList<Integer>();
		list2.add(1);
		list2.add(1);
		list2.add(1);
//		List<Value> list3 = new LinkedList<Value>();
//		LeafNode leafNode22 = new LeafNode(5, list2, list3, list);
		
//		InsertionResult insertionResult = new InsertionResult<Value>(minGap)
		
		leafNode1.insert(2, "2");
		leafNode1.insert(1, "2");
		
//		System.out.println(leafNode1.reverseToString());
		
		assertEquals("1,2", leafNode1.toString());
		
		assertEquals("2,1,", leafNode1.reverseToString());
		leafNode1.toString();
		
		leafNode1.reverseToString();
		
		
		
		LeafNode leafNodea = new LeafNode<String>(10);
		LeafNode leafNodeb = new LeafNode<String>(10);
		LeafNode leafNodec = new LeafNode<String>(10);
		
		List list3 = new LinkedList<LeafNode>();
		list3.add(leafNodea);
		list3.add(leafNodea);
		list3.add(leafNodea);
		InternalNode internalNode22 = new InternalNode<String>(5, list2, list3);
		InternalNode internalNode = new InternalNode<String>(5);
		InternalNode internalNode1 = new InternalNode(1);
		InternalNode internalNode2 = new InternalNode(2);
		
		internalNode.getNodeSize();
		
		internalNode22.insert(1, "");


		internalNode22.toString();
		assertEquals(0, internalNode22.order(1));
		assertEquals(-1, internalNode22.order(2));
		assertEquals(-1, internalNode22.order(0));
		internalNode22.order(1);
		assertEquals(0, internalNode.getNodeSize());
//		assertEquals(null, internalNode.getChildNode(-1));
		assertEquals(0, internalNode.getNodeSize());
		
//		internalNode1.toString();
//		
//		internalNode.insert(1, "0");
//		internalNode.insert(0, "0");
//		internalNode.insert(0, "0");
//		internalNode.insert(0, "0");
		
		
		BPlusTree bPlusTree = new BPlusTree<String>(5);
		BPlusTree bPlusTree22 = new BPlusTree<String>(5);
		BPlusTree bPlusTree2 = new BPlusTree<String>(2, 2);
		
		BPlusTree bPlusTree3 = new BPlusTree<String>(1, 2);
		
		bPlusTree3.insert(4, "1");
		
		bPlusTree2.insert(1, "1");
		bPlusTree2.insert(2, "2");
	
		
		bPlusTree.insert(1, "1");
		bPlusTree.insert(2, "2");
		bPlusTree.insert(3, "3");
		bPlusTree.insert(3, "4");
		
		
		assertEquals("1", bPlusTree.search(1));
		assertEquals("2", bPlusTree.search(2));
		
		assertEquals("2", bPlusTree2.search(2));
		
		assertEquals(null, bPlusTree2.search(3));
		
		
		assertEquals("3,2,1,", bPlusTree.reverseInOrder());
		
		
		assertEquals(3, bPlusTree.order(3));
		assertEquals(-1, bPlusTree.order(4));
		
		assertEquals("1,2,3", bPlusTree.inOrder());
		
		assertEquals("1,2,3", bPlusTree.toString());
		assertEquals("", bPlusTree22.toString());
		
		assertEquals(1, bPlusTree.getMinGap());
		assertEquals(3, bPlusTree.getSize());
		
		

	}

}
