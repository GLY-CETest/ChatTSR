package net.mooctest;
import static org.junit.Assert.*;

import java.awt.List;
import java.util.ArrayList;

import org.junit.Test;


public class BPlusTree_1509184829764_LeafNodeTest {

	@Test
	public void testLeafNodeInt() {
		//fail("Not yet implemented");
		ArrayList<Integer> keylist = new ArrayList<Integer>();
		keylist.add(1);
		keylist.add(2);
		keylist.add(3);
		ArrayList<Integer> valueslist = new ArrayList<Integer>();
		valueslist.add(1);
		valueslist.add(2);
		valueslist.add(3);
		
		LeafNode<Integer> leafNode = new LeafNode<Integer>(1);
		LeafNode< Integer> leafNode2 = new LeafNode<Integer>(2, leafNode);
		LeafNode<Integer> leafNode3 = new LeafNode<Integer>(3, leafNode, keylist, valueslist);
		
		assertEquals(-1, leafNode.order(0));
		assertEquals(-1, leafNode2.order(0));
		assertEquals(1, leafNode3.order(2));
		
		assertNull(leafNode.getValue(0));
		assertNull(leafNode3.getValue(0));
		assertEquals((Integer)2, leafNode3.getValue(2));
		
		ArrayList<Integer> keylist1 = new ArrayList<Integer>();
		//assertEquals(1717922155, leafNode.insert(0, 1).hashCode());
		InsertionResult<Integer> insertionResult = leafNode.insert(0, 1);
		assertEquals("1,2,3", leafNode3.insert(4, 2).getLeftNode().toString());
		assertNull(leafNode3.insert(3, 3));
		//System.out.println(insertionResult.getLeftNode().toString());
		assertNull(leafNode3.insert(1, 1));
		//System.out.println(leafNode3.insert(1, 1));
		//System.out.println(leafNode3.order(2));
		//System.out.println(leafNode.getValue(0));
		
		assertEquals(1, leafNode3.calculateGap(1));
		assertEquals(1, leafNode3.calculateGap(2));
		assertEquals(2147483647, leafNode3.calculateGap(-1));
		assertNotNull(leafNode3.getNext());
		
		assertEquals("3,2,1,", leafNode3.reverseToString());
		assertEquals("1,2,3", leafNode3.toString());
		
		
	}

}
