package net.mooctest;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;


public class BPlusTree_1509184485789_BPlusTreeTest {

	@Test
	public void test() {
		Integer i1=new Integer(5);
		LeafNode left0=new LeafNode(1);
		assertEquals(null,left0.getValue(0));
		LeafNode left1=new LeafNode(4);
		left1.insert(0, 2);
		left1.insert(5, 6);
		
		assertEquals("0,5",left1.toString());
		assertEquals(5,left1.calculateGap(0));
		assertEquals("2",left1.getValue(0).toString());
		assertEquals(0,left1.findLessThanOrEqualToKey(0));
		assertEquals(1,left1.findLessThanOrEqualToKey(1));
		assertEquals(0,left1.order(0));
		assertEquals(-1,left1.order(1));
		assertEquals(2,left1.getNodeSize());
		assertEquals("5,0,",left1.reverseToString().toString());
		assertEquals(null,left1.getNext());
		assertEquals(null,left1.getPrev());
		//assertEquals();
		
		LeafNode right1=new LeafNode(5);
		right1.insert(4, 3);
		right1.insert(10, 8);
		right1.insert(3, 8);
		right1.insert(3, 8);
		right1.insert(6, 8);
		right1.insert(1, 8);
		right1.insert(0, 4);
		//assertEquals("3,4,10",right1.toString());
		LeafNode leftri1=new LeafNode(2,left1);
		LeafNode leftri2=new LeafNode(2,leftri1);
		List<Integer> keys1=new ArrayList<Integer>();
		keys1.add(1);
		keys1.add(2);
		List value1=new ArrayList(){};
		LeafNode leftri3=new LeafNode(2,leftri1,keys1,value1);
		InsertionResult v1= new InsertionResult(i1,left1,right1);
		assertEquals(left1.toString(),v1.getLeftNode().toString());
		assertEquals(right1.toString(),v1.getRightNode().toString());
		assertEquals(0,v1.getMinGap());
		assertEquals("5",v1.getSplitRootKey().toString());
	
		BPlusTree b1=new BPlusTree(5);
		BPlusTree b2= new BPlusTree(2,5);
		b1.insert(0, left1);
		b1.insert(1, right1);
		assertEquals(1,b1.getMinGap());
		assertEquals(2,b1.getSize());
		assertEquals("0,1",b1.inOrder());
		assertEquals(1,b1.order(0));
		//System.out.println(b1.reverseInOrder());
		assertEquals("1,0,",b1.reverseInOrder());
		assertEquals("0,1",b1.toString());
		//InternalNode
		InternalNode int1=new InternalNode(2);
		List<Node> l1=new ArrayList<Node>();
		l1.add(left1);
		l1.add(leftri1);
		
		InternalNode int2=new InternalNode(7,keys1,l1);
		int2.insert(1,left1);
		InternalNode int3=new InternalNode(2,v1);
		assertEquals("0,1,5",((LeafNode)int2.getChildNode(1)).toString());
		assertEquals(2,int2.getMaxChildNode().t);
		assertEquals(3,int2.getNodeSize());
		
		//assertEquals(null,int2.toString());
		assertEquals(0,int2.order(0));
		assertEquals(1,int2.order(1));
		int2.insert(2,left1);
		
		//IntegerBloomFilter
		IntegerBloomFilter ii1=new IntegerBloomFilter(1,2,3);
		//getExpectedFalsePositiveProbability
		assertTrue(0.8579516416223205==ii1.getExpectedFalsePositiveProbability());
		//getFalsePositiveProbability
		assertTrue(0.0==ii1.getFalsePositiveProbability(0));
		//getCurrentFalsePositiveProbability
		assertTrue(0.0==ii1.getCurrentFalsePositiveProbability());
		
		ii1.clear();
		ii1.add(3);
		assertEquals(true,ii1.contains(3));
		//getBitsPerElement
		//System.out.println(ii1.getBitsPerElement());
		assertEquals(1,ii1.getBitsPerElement());
		//getFilterSize
		assertEquals(2,ii1.getFilterSize());
		//getTotalHashFunctions
		assertEquals(3,ii1.getTotalHashFunctions());
		
	}

}
