package net.mooctest;
import static org.junit.Assert.*;

import org.junit.Test;


public class BPlusTree_1509183799251_BPlusTreeTest {

	 @Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(1);
	      Integer integer0 = new Integer(1);
	      Integer.remainderUnsigned(1972, (-1140));
	      bPlusTree0.insert(1, integer0);
	      bPlusTree0.search(46);
	      bPlusTree0.insert(46, (Object) null);
	      bPlusTree0.order(46);
	      // Undeclared exception!
	      try { 
	        bPlusTree0.search(1467);
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(2, 2);
	      Object object0 = new Object();
	      Integer.getInteger((String) null);
	      bPlusTree0.insert(3179, (Object) null);
	      bPlusTree0.reverseInOrder();
	      bPlusTree0.insert(Integer.MAX_VALUE, object0);
	      bPlusTree0.order(2);
	      bPlusTree0.search(Integer.MAX_VALUE);
	      bPlusTree0.insert((-975), "3179,");
	      bPlusTree0.insert((-1), object0);
	      bPlusTree0.inOrder();
	      bPlusTree0.inOrder();
	      BPlusTree<String> bPlusTree1 = new BPlusTree<String>(2446);
	      bPlusTree1.getMinGap();
	      bPlusTree0.getSize();
	      bPlusTree1.getSize();
	      bPlusTree0.reverseInOrder();
	      // Undeclared exception!
	      try { 
	        bPlusTree0.insert(2446, object0);
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(2, 2);
	      Object object0 = new Object();
	      Integer.getInteger((String) null);
	      bPlusTree0.insert(3179, (Object) null);
	      bPlusTree0.reverseInOrder();
	      bPlusTree0.insert(Integer.MAX_VALUE, object0);
	      bPlusTree0.order(2);
	      bPlusTree0.search(Integer.MAX_VALUE);
	      bPlusTree0.insert((-975), "3179,");
	      bPlusTree0.inOrder();
	      bPlusTree0.inOrder();
	      BPlusTree<String> bPlusTree1 = new BPlusTree<String>(2446);
	      bPlusTree1.getMinGap();
	      bPlusTree0.getSize();
	      bPlusTree1.getSize();
	      bPlusTree0.reverseInOrder();
	      bPlusTree0.insert(2446, object0);
	      // Undeclared exception!
	      try { 
	        bPlusTree0.order(Integer.MAX_VALUE);
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(890, 890);
	      bPlusTree0.search(890);
	      assertEquals(Integer.MAX_VALUE, bPlusTree0.getMinGap());
	      
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(4356);
	      insertionResult0.getSplitRootKey();
	      Integer.divideUnsigned(890, 890);
	      bPlusTree0.insert(4356, (Object) null);
	      BPlusTree<Integer> bPlusTree1 = new BPlusTree<Integer>(4356);
	      bPlusTree1.insert((-568), (Integer) null);
	      bPlusTree1.toString();
	      bPlusTree0.inOrder();
	      BPlusTree<String> bPlusTree2 = new BPlusTree<String>(1, 890);
	      bPlusTree2.reverseInOrder();
	      bPlusTree2.insert(890, "");
	      // Undeclared exception!
	      try { 
	        bPlusTree2.insert(890, "-568");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(890);
	      bPlusTree0.search(2);
	      InsertionResult<Object> insertionResult0 = new InsertionResult<Object>(4358);
	      insertionResult0.getSplitRootKey();
	      Integer.divideUnsigned(890, 2);
	      bPlusTree0.insert(4358, (Object) null);
	      BPlusTree<Integer> bPlusTree1 = new BPlusTree<Integer>(890, 890);
	      bPlusTree1.insert(2, (Integer) null);
	      bPlusTree1.insert((-568), (Integer) null);
	      bPlusTree1.toString();
	      bPlusTree0.toString();
	      Integer integer0 = new Integer((-568));
	      BPlusTree<String> bPlusTree2 = new BPlusTree<String>(4358);
	      bPlusTree2.toString();
	      bPlusTree2.insert(2, "");
	      bPlusTree2.insert(890, "-568,2");
	      bPlusTree0.getSize();
	      bPlusTree1.insert(980, (Integer) null);
	      bPlusTree0.reverseInOrder();
	      bPlusTree0.getSize();
	      bPlusTree1.inOrder();
	      assertEquals("-568,2,980", bPlusTree1.toString());
	      
	      int int0 = bPlusTree0.getMinGap();
	      assertEquals("4358", bPlusTree0.toString());
	      assertEquals(Integer.MAX_VALUE, int0);
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(4099, 0);
	      Object object0 = new Object();
	      bPlusTree0.reverseInOrder();
	      // Undeclared exception!
	      try { 
	        bPlusTree0.insert(0, object0);
	      
	      } catch(ArithmeticException e) {
	         //
	         // / by zero
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      BPlusTree<String> bPlusTree0 = new BPlusTree<String>(2632);
	      bPlusTree0.insert(389, "");
	      bPlusTree0.order(2632);
	      bPlusTree0.getSize();
	      assertEquals("389", bPlusTree0.toString());
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(1275, 0);
	      bPlusTree0.getMinGap();
	      // Undeclared exception!
	      try { 
	        bPlusTree0.search(0);
	      
	      } catch(ArithmeticException e) {
	         //
	         // / by zero
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      BPlusTree<String> bPlusTree0 = new BPlusTree<String>(1);
	      bPlusTree0.order(0);
	      bPlusTree0.insert(0, "");
	      BPlusTree<Object> bPlusTree1 = new BPlusTree<Object>(2656);
	      bPlusTree1.insert(2656, "Filter stopped the search.");
	      bPlusTree0.insert(1, "");
	      bPlusTree1.getMinGap();
	      // Undeclared exception!
	      try { 
	        bPlusTree0.toString();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      BPlusTree<String> bPlusTree0 = new BPlusTree<String>(2180);
	      bPlusTree0.search(2180);
	      BPlusTree<Object> bPlusTree1 = null;
	      try {
	        bPlusTree1 = new BPlusTree<Object>(2358, (-81));
	      
	      } catch(NegativeArraySizeException e) {
	         //
	         // nbits < 0: -2349
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
//	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(Integer.MAX_VALUE, Integer.MAX_VALUE);
	  }

	  @Test(timeout = 4000)
	  public void test11()  throws Throwable  {
	//      BPlusTree<Integer> bPlusTree0 = new BPlusTree<Integer>(Integer.MAX_VALUE);
	  }

	  @Test(timeout = 4000)
	  public void test12()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = null;
	      try {
	        bPlusTree0 = new BPlusTree<Object>(0);
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -1
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test13()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = null;
	      try {
	        bPlusTree0 = new BPlusTree<Object>((-1), 1);
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -2
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test14()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(2, 2);
	      Object object0 = new Object();
	      bPlusTree0.reverseInOrder();
	      bPlusTree0.insert(Integer.MAX_VALUE, object0);
	      bPlusTree0.order(2);
	      bPlusTree0.insert(3166, "");
	      bPlusTree0.search(Integer.MAX_VALUE);
	      bPlusTree0.reverseInOrder();
	      assertEquals(2, bPlusTree0.getSize());
	  }

	  @Test(timeout = 4000)
	  public void test15()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(1293, 2);
	      bPlusTree0.reverseInOrder();
	      bPlusTree0.reverseInOrder();
	      BPlusTree<String> bPlusTree1 = new BPlusTree<String>(1445);
	      bPlusTree1.getSize();
	      bPlusTree1.insert(2, "");
	      BPlusTree<Integer> bPlusTree2 = new BPlusTree<Integer>(1293, 1293);
	      bPlusTree0.toString();
	      bPlusTree1.insert(2, "");
	      // Undeclared exception!
	      try { 
	        bPlusTree2.inOrder();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test16()  throws Throwable  {
	      BPlusTree<Object> bPlusTree0 = new BPlusTree<Object>(2);
	      bPlusTree0.toString();
	      bPlusTree0.insert(2, "");
	      bPlusTree0.order(2);
	      bPlusTree0.search(2);
	      bPlusTree0.inOrder();
	      int int0 = (-194);
	      BPlusTree<Integer> bPlusTree1 = new BPlusTree<Integer>(2);
	      // Undeclared exception!
	      try { 
	        bPlusTree1.inOrder();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test17()  throws Throwable  {
	      BPlusTree<String> bPlusTree0 = new BPlusTree<String>(18);
	      bPlusTree0.insert(0, (String) null);
	      bPlusTree0.reverseInOrder();
	      bPlusTree0.insert(1, "0,");
	      bPlusTree0.inOrder();
	      bPlusTree0.getMinGap();
	      bPlusTree0.toString();
	      InternalNode<Object> internalNode0 = null;
	      try {
	        internalNode0 = new InternalNode<Object>(0);
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -1
	         //
	      }
	  }

}
