package net.mooctest;
import static org.junit.Assert.*;

import java.awt.List;
import java.lang.reflect.Array;
import java.util.ArrayList;

import org.junit.Test;


public class BPlusTree_1509184829764_InternalNodeTest {

	@Test
	public void testInternal(){
		ArrayList<Integer> keylist = new ArrayList<Integer>();
		keylist.add(1);
		keylist.add(2);
		keylist.add(3);
		ArrayList<Integer> valueslist = new ArrayList<Integer>();
		valueslist.add(1);
		valueslist.add(2);
		valueslist.add(3);
		
		LeafNode leafNode = new LeafNode(1);
		LeafNode leafNode2 = new LeafNode(2, leafNode);
		LeafNode leafNode3 = new LeafNode(3, leafNode, keylist, valueslist);
		
		ArrayList<Node> nodeList = new ArrayList<Node>();
		nodeList.add(leafNode);
		nodeList.add(leafNode2);
		nodeList.add(leafNode3);
		
		InsertionResult insertionResult = new InsertionResult(0);
		InsertionResult insertionResult2 = new InsertionResult(2, new LeafNode(2), new LeafNode(2));
		InsertionResult insertionResult3 = new InsertionResult(2,leafNode3, leafNode3);
		
		
		//InternalNode internalNode = new InternalNode(0);
		InternalNode internalNode2 = new InternalNode(2, insertionResult3);
		InternalNode internalNode3 = new InternalNode(2, keylist, nodeList);
		
		assertEquals(6, internalNode2.getNodeSize());
		assertEquals(-1, internalNode2.order(0));
		assertEquals(0, internalNode2.order(1));
		assertEquals(1, internalNode2.order(2));
		assertEquals(-1, internalNode3.order(1));
		assertEquals(-1, internalNode3.order(4));
		
		assertNotNull(internalNode3.insert(2, 5));
		assertNotNull(internalNode3.insert(0, 5));
		assertNotNull(internalNode3.insert(5, 5));
		
		assertEquals(leafNode3, internalNode2.getChildNode(0));
		assertEquals(leafNode3, internalNode2.getMaxChildNode());
		assertEquals("1,2,3#1,2,3", internalNode2.toString());
//		System.out.println(internalNode2.toString());
//		for(int j=0; j<5; j++){
//			for (int i = 0; i < 5; i++) {
//			System.out.println(internalNode3.insert(j, i));
//		}
//		}
		
//		System.out.println(internalNode2.order(0));
//		System.out.println(internalNode2.order(0));
		
		
	}
	
	@Test
	public void testInsert() {
		//fail("Not yet implemented");
	}

	@Test
	public void testOrder() {
		//fail("Not yet implemented");
	}

	@Test
	public void testGetNodeSize() {
		////fail("Not yet implemented");
	}

	@Test
	public void testInternalNodeInt() {
		//fail("Not yet implemented");
	}

	@Test
	public void testInternalNodeIntListOfIntegerListOfNodeOfValue() {
		//fail("Not yet implemented");
	}

	@Test
	public void testInternalNodeIntInsertionResultOfValue() {
		//fail("Not yet implemented");
	}

	@Test
	public void testGetChildNode() {
		//fail("Not yet implemented");
	}

	@Test
	public void testGetMaxChildNode() {
		//fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		//fail("Not yet implemented");
	}

}
