package net.mooctest;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class BPlusTree_1509183888457_BPlusTreeTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBPlusTreeInt() {
		
	}

	@Test
	public void testBPlusTreeIntInt() {
	}

	@Test
	public void testSearch() {
		BPlusTree inTree=new BPlusTree(10);
		Integer r=(Integer) inTree.search(0);
		assertNull(r);
		inTree.insert(0, new Integer(0));
		inTree.insert(1, new Integer(1));
		Integer in=(Integer) inTree.search(3);
		assertNull(in);
		
		
	}

	@Test
	public void testInsert() {
		BPlusTree inTree=new BPlusTree(8, 10);
		inTree.insert(1, new Integer(1));
		Integer r=(Integer) inTree.search(1);
		assertEquals(1, r.intValue());
	}

	@Test
	public void testReverseInOrder() {
		BPlusTree inTree=new BPlusTree(8, 10);
		inTree.insert(1, new Integer(1));
		inTree.insert(2, new Integer(2));
		String s=inTree.reverseInOrder();
		assertEquals("2,1,", s);
	}

	@Test
	public void testGetSize() {
		BPlusTree inTree=new BPlusTree(8, 10);
		inTree.insert(1, new Integer(1));
		inTree.insert(2, new Integer(2));
		assertEquals(2, inTree.getSize());
	}

	@Test
	public void testGetMinGap() {
		BPlusTree inTree=new BPlusTree(8, 10);
		inTree.insert(1, new Integer(1));
		inTree.insert(2, new Integer(2));
		assertEquals(1,inTree.getMinGap());
	}

	@Test
	public void testOrder() {
		BPlusTree inTree=new BPlusTree(8, 10);
		inTree.insert(1, new Integer(1));
		inTree.insert(2, new Integer(2));
		int r=inTree.order(2);
		assertEquals(2,r);
		assertEquals(-1, inTree.order(4));
	}

	@Test
	public void testInOrder() {
		BPlusTree inTree=new BPlusTree(8, 10);
		inTree.insert(1, new Integer(1));
		inTree.insert(2, new Integer(2));
		String s=inTree.inOrder();
		assertEquals("1,2",s);
	}

	@Test
	public void testToString() {
		BPlusTree inTree=new BPlusTree(8, 10);
		inTree.insert(1, new Integer(1));
		inTree.insert(2, new Integer(2));
		String s=inTree.toString();
		assertEquals("1,2",s);
		inTree=new BPlusTree(10);
		assertEquals("", inTree.toString());
	}

}
