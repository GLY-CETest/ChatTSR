package net.mooctest;
import static org.junit.Assert.*;

import java.util.LinkedList;

import org.junit.Test;


public class BPlusTree_1509183799251_NodeTest {


	  @Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(4);
	      leafNode0.insert(3, "");
	      leafNode0.insert(4, "");
	      leafNode0.insert(0, "");
	      InsertionResult<String> insertionResult0 = leafNode0.insert(2, "");
	      assertEquals(2, (int)insertionResult0.getSplitRootKey());
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(5);
	      leafNode0.insert(2, "");
	      leafNode0.insert(0, "");
	      leafNode0.insert(3334, "");
	      leafNode0.insert(3, "");
	      InsertionResult<String> insertionResult0 = leafNode0.insert(4, "");
	      assertEquals(3, (int)insertionResult0.getSplitRootKey());
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(4);
	      leafNode0.insert(206, "");
	      leafNode0.insert(207, "");
	      leafNode0.insert(0, "");
	      leafNode0.insert(206, "");
	      assertEquals(3, leafNode0.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      Integer integer0 = new Integer(0);
	      leafNode0.insert(0, integer0);
	      int int0 = leafNode0.order(0);
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(3);
	      Object object0 = new Object();
	      leafNode0.insert(0, object0);
	      Integer integer0 = new Integer(0);
	      leafNode0.insert(1, integer0);
	      int int0 = leafNode0.order(1);
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      int int0 = leafNode0.order(0);
	      assertEquals((-1), int0);
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      Object object0 = new Object();
	      leafNode0.insert(0, object0);
	      int int0 = leafNode0.getNodeSize();
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      leafNode0.insert(0, (String) null);
	      int int0 = leafNode0.findLessThanOrEqualToKey(0);
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      leafNode0.insert(0, "");
	      int int0 = leafNode0.findLessThanOrEqualToKey(1);
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      int int0 = leafNode0.findLessThanOrEqualToKey(0);
	      assertEquals((-1), int0);
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      LinkedList<Node<String>> linkedList1 = new LinkedList<Node<String>>();
	      Integer integer0 = new Integer(1037);
	      linkedList0.add(integer0);
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, linkedList0, linkedList1);
	      // Undeclared exception!
	      try { 
	        internalNode0.order(0);
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 0, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test11()  throws Throwable  {
	      InternalNode<Integer> internalNode0 = new InternalNode<Integer>(1);
	      // Undeclared exception!
	      try { 
	        internalNode0.order(0);
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test12()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      Integer integer0 = new Integer(0);
	      leafNode0.keys = null;
	      // Undeclared exception!
	      try { 
	        leafNode0.insert(0, integer0);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test13()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      leafNode0.t = 0;
	      // Undeclared exception!
	      try { 
	        leafNode0.insert(0, "");
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -1
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test14()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      LinkedList<Node<String>> linkedList1 = new LinkedList<Node<String>>();
	      InternalNode<String> internalNode0 = new InternalNode<String>(1, linkedList0, linkedList1);
	      // Undeclared exception!
	      try { 
	        internalNode0.insert(0, "");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test15()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      leafNode0.keys = null;
	      // Undeclared exception!
	      try { 
	        leafNode0.getNodeSize();
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test16()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      leafNode0.keys = null;
	      // Undeclared exception!
	      try { 
	        leafNode0.findLessThanOrEqualToKey(0);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test17()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(3);
	      leafNode0.insert(0, "");
	      leafNode0.insert(3334, "");
	      InsertionResult<String> insertionResult0 = leafNode0.insert(3334, "");
	      assertNull(insertionResult0);
	  }

	  @Test(timeout = 4000)
	  public void test18()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      Object object0 = new Object();
	      leafNode0.insert(0, object0);
	      Integer integer0 = new Integer(0);
	      // Undeclared exception!
	      try { 
	        leafNode0.insert(1, integer0);
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 0, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test19()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      Object object0 = new Object();
	      leafNode0.insert(0, object0);
	      Integer integer0 = new Integer(0);
	      InsertionResult<Object> insertionResult0 = leafNode0.insert(0, integer0);
	      assertNull(insertionResult0);
	  }

	  @Test(timeout = 4000)
	  public void test20()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      int int0 = leafNode0.getNodeSize();
	      assertEquals(0, int0);
	  }

}
