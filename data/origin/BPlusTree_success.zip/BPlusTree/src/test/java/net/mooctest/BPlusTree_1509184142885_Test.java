package net.mooctest;
import java.util.Random;

import org.junit.Assert;
import org.junit.Test;

public class BPlusTree_1509184142885_Test {

	@Test
	public void test1() {
		BPlusTree<Integer> bt = new BPlusTree<Integer>(2);
		bt.insert(1, 1);
		bt.insert(1, 1);
		bt.insert(2, 2);
		bt.insert(3, 3);
		Assert.assertEquals(3, (int) bt.search(3));
		Assert.assertEquals(2, (int) bt.search(2));
		Assert.assertEquals(null, bt.search(10000000));
		Assert.assertEquals(3, bt.order(3));
		Assert.assertEquals(2, bt.order(2));
		Assert.assertEquals(-1, bt.order(100000));
		Assert.assertEquals("123", bt.inOrder());
		Assert.assertEquals("3,2,1,", bt.reverseInOrder());
		Assert.assertEquals("1#2#3", bt.toString());
	}

	@Test
	public void test2() {
		BPlusTree<Integer> bt = new BPlusTree<Integer>(5, 10);
		bt.insert(1, 1);
		bt.insert(1, 1);
		bt.insert(2, 2);
		bt.insert(2, 2);
		bt.insert(3, 3);
		bt.insert(3, 3);
		bt.insert(3, 3);
		Assert.assertEquals(3, (int) bt.search(3));
		Assert.assertEquals(1, (int) bt.search(1));
		Assert.assertEquals(null, bt.search(0));
		Assert.assertEquals(null, bt.search(-10000));
		Assert.assertEquals(null, bt.search(10000000));
		Assert.assertEquals(3, bt.order(3));
		Assert.assertEquals(1, bt.order(1));
		Assert.assertEquals(-1, bt.order(0));
		Assert.assertEquals(-1, bt.order(-10000));
		Assert.assertEquals(-1, bt.order(10000000));
		Assert.assertEquals("1,2,3", bt.inOrder());
		Assert.assertEquals("3,2,1,", bt.reverseInOrder());
		Assert.assertEquals("1,2,3", bt.toString());
	}

	@Test
	public void test3() {
		BPlusTree<Integer> bt = new BPlusTree<Integer>(5, 10);
		Assert.assertEquals(bt.toString(), "");
		Assert.assertEquals(null, bt.search(10000));
	}

	@Test
	public void test4() {
		{
			int res1 = TestGen(50, 1, 60, 6, 60);
			int res2 = TestGen(50, 5, 60, 8, 100);
			int res3 = TestGen(50, 19, 60, 10, 1);
			int res4 = TestGen(30, 98, 10, 3, 60);
			int res5 = TestGen(30, -1, 10, 5, 100);
			int res6 = TestGen(30, 8, 10, 7, 1);
			String str = res1 + "" + res2 + "" + res3 + "" + res4 + "" + res5
					+ "" + res6;
			Assert.assertEquals(-99572499, str.hashCode());
		}
		// {
		// int res1 = TestGen(50, 1, 60, 6, -1);
		// int res2 = TestGen(50, 5, 60, 8, -1);
		// int res3 = TestGen(50, 19, 60, 10, -1);
		// int res4 = TestGen(30, 98, 10, 3, -1);
		// int res5 = TestGen(30, -1, 10, 5, -1);
		// int res6 = TestGen(30, 8, 10, 7, -1);
		// String str = res1 + "" + res2 + "" + res3 + "" + res4 + "" + res5
		// + "" + res6;
		// Assert.assertEquals(-1954613140, str.hashCode());
		// }
	}

	@Test
	public void test5() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				for (int k = 0; k < 5; k++) {
					for (int m = 0; m < 5; m++) {
						try {
							int res = TestGen(i, j, k, m, 10);
							sb.append(res);
						} catch (Exception e) {
							sb.append("-e:" + e.getClass().toString());
						}
					}
				}
			}
		}
		Assert.assertEquals(332210533, sb.toString().hashCode());	}

	public int TestGen(int key_num, int rand_seed, int rand_bound, int t_para,
			int t_expect) {
		StringBuilder sb = new StringBuilder("");
		int[] keys = new int[key_num];
		Random rnd = new Random(rand_seed);
		for (int i = 0; i < key_num; i++) {
			keys[i] = rnd.nextInt(rand_bound);
		}
		BPlusTree<Integer> bt = null;
		// if (t_expect < 0) {
		// bt = new BPlusTree<Integer>(t_para);
		// } else {
		bt = new BPlusTree<Integer>(t_para, t_expect);
		// }
		for (int key : keys) {
			try {
				bt.insert(key, rnd.nextInt());
			} catch (Exception e) {
				sb.append("-i");
			}
			try {
				sb.append(bt.getMinGap());
			} catch (Exception e) {
				sb.append("-s");
			}
		}
		RandomSwap(keys, rnd);
		for (int key : keys) {
			try {
				int val = bt.search(key);
				sb.append("" + val);
			} catch (Exception e) {
				sb.append("-s");
			}
		}
		try {
			int val = bt.search(rnd.nextInt(100) + rand_bound);
			sb.append("" + val);
		} catch (Exception e) {
			sb.append("-s");
		}
		for (int key : keys) {
			try {
				int val = bt.order(key);
				sb.append("" + val);
			} catch (Exception e) {
				sb.append("-o");
			}
		}
		try {
			int val = bt.order(rnd.nextInt(100) + rand_bound);
			sb.append("" + val);
		} catch (Exception e) {
			sb.append("-s");
		}
		try {
			sb.append(bt.reverseInOrder());
		} catch (Exception e) {
			sb.append("-s");
		}
		try {
			sb.append(bt.getMinGap());
		} catch (Exception e) {
			sb.append("-s");
		}
		try {
			sb.append(bt.getSize());
		} catch (Exception e) {
			sb.append("-s");
		}
		try {
			sb.append(bt.inOrder());
		} catch (Exception e) {
			sb.append("-s");
		}
		try {
			sb.append(bt.toString());
		} catch (Exception e) {
			sb.append("-s");
		}
		return sb.toString().hashCode();
	}

	public void RandomSwap(int[] array, Random rand) {
		int n = array.length;
		for (int i = 0; i < n; ++i) {
			int j = rand.nextInt(n);
			int t = array[i];
			array[i] = array[j];
			array[j] = t;
		}
	}

}
