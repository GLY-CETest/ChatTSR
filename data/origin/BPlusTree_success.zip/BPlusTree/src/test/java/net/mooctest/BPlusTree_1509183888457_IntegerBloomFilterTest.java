package net.mooctest;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class BPlusTree_1509183888457_IntegerBloomFilterTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		IntegerBloomFilter filter=new IntegerBloomFilter(1.0, 8);
		double r=filter.getExpectedFalsePositiveProbability();
		assertEquals(1,(int)r);
		r=filter.getFalsePositiveProbability(2.0);
		assertEquals(1,(int)r);
		r=filter.getCurrentFalsePositiveProbability();
		assertEquals(1,(int)r);
		
		filter.clear();
		filter=new IntegerBloomFilter(0.5, 10);
		filter.add(1);
		filter.add(2);
		filter.add(3);
		assertTrue(filter.contains(2));
		assertFalse(filter.contains(4));
		assertEquals(2,filter.getBitsPerElement());
		assertEquals(20,filter.getFilterSize());
		assertEquals(1,filter.getTotalHashFunctions());
		
	}

}
