package net.mooctest;
import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;


public class BPlusTree_1509183799251_LeafNodeTest {

	@Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(3751);
	      LeafNode<Object> leafNode1 = new LeafNode<Object>(683, leafNode0);
	      LeafNode<Object> leafNode2 = leafNode1.getPrev();
	      leafNode2.keys = null;
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      leafNode1.order((-2943));
	      LinkedList<Object> linkedList1 = new LinkedList<Object>();
	      // Undeclared exception!
	      try { 
	        leafNode2.reverseToString();
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(2);
	      leafNode0.keys = null;
	      // Undeclared exception!
	      try { 
	        leafNode0.calculateGap(649);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(2);
	      leafNode0.t = 2;
	      leafNode0.getValue(2);
	      leafNode0.keys = null;
	      // Undeclared exception!
	      try { 
	        leafNode0.getValue((-865));
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(4429);
	      LeafNode<Object> leafNode1 = new LeafNode<Object>(612, leafNode0);
	      // Undeclared exception!
	      try { 
	        leafNode1.calculateGap(Integer.MAX_VALUE);
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      leafNode0.insert(1, "");
	      leafNode0.t = 2;
	      leafNode0.insert(2, (String) null);
	      leafNode0.getNext();
	      assertEquals(1, leafNode0.getNodeSize());
	      
	      LeafNode<Integer> leafNode1 = new LeafNode<Integer>(1);
	      Integer integer0 = new Integer(2);
	      InsertionResult<Integer> insertionResult0 = leafNode1.insert(39, integer0);
	      assertEquals(39, (int)insertionResult0.getSplitRootKey());
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(638);
	      LeafNode<String> leafNode1 = new LeafNode<String>(638, leafNode0);
	      LeafNode<String> leafNode2 = leafNode1.getPrev();
	      leafNode2.insert(0, "W[mHje)ik");
	      leafNode2.getNext();
	      leafNode1.insert(638, ",");
	      leafNode1.insert(0, ",");
	      LeafNode<Integer> leafNode3 = null;
	      try {
	        leafNode3 = new LeafNode<Integer>((-185));
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -186
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      leafNode0.keys = null;
	      // Undeclared exception!
	      try { 
	        leafNode0.insert(1, "");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(5);
	      leafNode0.reverseToString();
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      leafNode0.keys = (List<Integer>) linkedList0;
	      leafNode0.order(5);
	      leafNode0.order((-38));
	      linkedList0.pollLast();
	      Object object0 = new Object();
	      linkedList0.remove(object0);
	      Integer integer0 = new Integer((-409));
	      Integer.getInteger("", integer0);
	      Integer.toUnsignedString((-409));
	      leafNode0.keys = (List<Integer>) linkedList0;
	      linkedList0.add(integer0);
	      leafNode0.toString();
	      leafNode0.t = 5;
	      leafNode0.getValue(1);
	      leafNode0.t = (-758);
	      linkedList0.add(integer0);
	      leafNode0.order(0);
	      leafNode0.getValue((-753));
	      leafNode0.reverseToString();
	      leafNode0.getValue(594);
	      LeafNode<Integer> leafNode1 = null;
	      try {
	        leafNode1 = new LeafNode<Integer>((-1));
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -2
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      Object object0 = new Object();
	      InsertionResult<Object> insertionResult0 = leafNode0.insert((-1634), object0);
	      assertEquals(Integer.MAX_VALUE, insertionResult0.getMinGap());
	      
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer integer0 = new Integer(0);
	      leafNode0.toString();
	      Integer integer1 = new Integer(1969);
	      Integer.getInteger(",", integer1);
	      int int0 = leafNode0.order((-1634));
	      assertEquals(0, int0);
	      
	      linkedList0.add(integer0);
	      LeafNode<String> leafNode1 = new LeafNode<String>(1380);
	      leafNode1.getNext();
	      String string0 = leafNode0.toString();
	      assertEquals("-1634", string0);
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(931);
	      leafNode0.reverseToString();
	      leafNode0.reverseToString();
	      leafNode0.insert((-1778), "");
	      leafNode0.insert(931, "");
	      leafNode0.calculateGap((-28));
	      leafNode0.order(931);
	      assertEquals(2, leafNode0.getNodeSize());
	      
	      LeafNode<String> leafNode1 = new LeafNode<String>(1);
	      LeafNode<String> leafNode2 = new LeafNode<String>(546, leafNode1);
	      InsertionResult<String> insertionResult0 = leafNode2.insert(1, "684GcxrGg484cB[Tt,");
	      assertEquals(Integer.MAX_VALUE, insertionResult0.getMinGap());
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
	  }

	  @Test(timeout = 4000)
	  public void test11()  throws Throwable  {
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	  }

	  @Test(timeout = 4000)
	  public void test12()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(14);
	      leafNode0.getPrev();
	      List<Integer> list0 = leafNode0.keys;
	      LinkedList<String> linkedList0 = new LinkedList<String>();
	      LeafNode<String> leafNode1 = new LeafNode<String>(14, leafNode0, list0, linkedList0);
	      leafNode0.insert(14, "!iI>'R+K");
	      leafNode1.getPrev();
	      LeafNode<Integer> leafNode2 = null;
	      try {
	        leafNode2 = new LeafNode<Integer>((-402));
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -403
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test13()  throws Throwable  {
	      LeafNode<Integer> leafNode0 = new LeafNode<Integer>(2621);
	      leafNode0.getValue(2621);
	      leafNode0.insert(2621, (Integer) null);
	      Integer integer0 = new Integer(828);
	      leafNode0.insert(828, integer0);
	      Integer integer1 = new Integer(2621);
	      Integer.divideUnsigned(2782, 2);
	      Integer.compareUnsigned(828, 828);
	      leafNode0.insert(95, integer1);
	      leafNode0.getPrev();
	      LeafNode<String> leafNode1 = null;
	      try {
	        leafNode1 = new LeafNode<String>((-1841));
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -1842
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test14()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(5);
	      leafNode0.reverseToString();
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      leafNode0.keys = (List<Integer>) linkedList0;
	      leafNode0.order(5);
	      leafNode0.order(0);
	      linkedList0.pollLast();
	      Integer integer0 = new Integer((-1));
	      Integer.getInteger("", integer0);
	      Integer.toUnsignedString((-1));
	      leafNode0.keys = (List<Integer>) linkedList0;
	      linkedList0.add(integer0);
	      leafNode0.toString();
	      leafNode0.t = 5;
	      leafNode0.getValue(1);
	      leafNode0.t = (-758);
	      linkedList0.add(integer0);
	      leafNode0.order(0);
	      leafNode0.getValue((-753));
	      // Undeclared exception!
	      try { 
	        leafNode0.getValue((-1));
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 0, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test15()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(7);
	      Object object0 = new Object();
	      leafNode0.insert((-21), object0);
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      leafNode0.reverseToString();
	      leafNode0.insert(7, linkedList0);
	      assertEquals(2, leafNode0.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test16()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      leafNode0.t = 1;
	      leafNode0.t = (-399);
	      // Undeclared exception!
	      try { 
	        leafNode0.insert(1, "");
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -400
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test17()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      leafNode0.insert(1, "");
	      LeafNode<Object> leafNode1 = new LeafNode<Object>(1, leafNode0);
	      assertEquals(0, leafNode1.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test18()  throws Throwable  {
	      LeafNode<Integer> leafNode0 = new LeafNode<Integer>(2202);
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      leafNode0.keys = (List<Integer>) linkedList0;
	      leafNode0.keys = (List<Integer>) linkedList0;
	      // Undeclared exception!
	      try { 
	        leafNode0.toString();
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: -1, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test19()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      LeafNode<String> leafNode1 = new LeafNode<String>(1, leafNode0);
	      int int0 = leafNode1.order((-2642));
	      assertEquals((-1), int0);
	  }

	  @Test(timeout = 4000)
	  public void test20()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(26);
	      // Undeclared exception!
	      try { 
	        leafNode0.calculateGap(2340);
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 2339, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test21()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(3252);
	      LeafNode<String> leafNode1 = new LeafNode<String>(220, leafNode0);
	      LeafNode<String> leafNode2 = leafNode1.getPrev();
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      LinkedList<Integer> linkedList1 = new LinkedList<Integer>(linkedList0);
	      LeafNode<String> leafNode3 = null;
	      try {
	        leafNode3 = new LeafNode<String>(3252, leafNode2, linkedList1, (List<String>) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test22()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(2911);
	      leafNode0.getValue((-177));
	      // Undeclared exception!
	      try { 
	        leafNode0.toString();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test23()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      List<Integer> list0 = leafNode0.keys;
	      LinkedList<String> linkedList0 = new LinkedList<String>();
	      LeafNode<String> leafNode1 = new LeafNode<String>(1, leafNode0, list0, linkedList0);
	      leafNode1.getNext();
	      LeafNode<String> leafNode2 = null;
	      try {
	        leafNode2 = new LeafNode<String>(1654, (LeafNode<String>) null);
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test24()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      leafNode0.reverseToString();
	      LeafNode<Object> leafNode1 = new LeafNode<Object>(1, leafNode0);
	      assertEquals(0, leafNode1.getNodeSize());
	  }

	  @Test(timeout = 4000)
	  public void test25()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(395);
	      // Undeclared exception!
	      try { 
	        leafNode0.toString();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test26()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1230);
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      LinkedList<String> linkedList1 = new LinkedList<String>();
	      LeafNode<String> leafNode1 = new LeafNode<String>(1230, leafNode0, linkedList0, linkedList1);
	      assertFalse(leafNode1.equals((Object)leafNode0));
	  }

	  @Test(timeout = 4000)
	  public void test27()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(2);
	      LeafNode<Object> leafNode1 = null;
	      try {
	        leafNode1 = new LeafNode<Object>((-1), leafNode0);
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -2
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test28()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      Integer integer0 = new Integer(0);
	      leafNode0.insert((-229), linkedList0);
	      linkedList0.add(integer0);
	      LinkedList<Object> linkedList1 = new LinkedList<Object>();
	      LeafNode<Object> leafNode1 = null;
	      try {
	        leafNode1 = new LeafNode<Object>(0, leafNode0, linkedList0, linkedList1);
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -1
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test29()  throws Throwable  {
	      LeafNode<Object> leafNode0 = null;
	      try {
	        leafNode0 = new LeafNode<Object>(0);
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // Illegal Capacity: -1
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test30()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(1);
	      leafNode0.insert(1, "");
	      leafNode0.t = 2;
	      leafNode0.insert(2, (String) null);
	      Integer integer0 = new Integer(2);
	      assertEquals(2, (int)integer0);
	  }

	  @Test(timeout = 4000)
	  public void test31()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(637);
	      Object object0 = new Object();
	      leafNode0.insert(637, object0);
	      leafNode0.insert(637, object0);
	      leafNode0.calculateGap((-528));
	      leafNode0.getValue(637);
	      leafNode0.getNext();
	  }

	  @Test(timeout = 4000)
	  public void test32()  throws Throwable  {
	      LeafNode<Integer> leafNode0 = new LeafNode<Integer>(636);
	      leafNode0.getValue(636);
	      Integer.compare(636, 636);
	      leafNode0.insert(0, (Integer) null);
	      leafNode0.insert((-1963), (Integer) null);
	      Integer integer0 = new Integer(0);
	      leafNode0.insert(636, (Integer) null);
	      leafNode0.getPrev();
	      leafNode0.toString();
	      LinkedList<String> linkedList0 = new LinkedList<String>();
	      assertEquals(0, linkedList0.size());
	  }

	  @Test(timeout = 4000)
	  public void test33()  throws Throwable  {
	      LeafNode<Object> leafNode0 = new LeafNode<Object>(1);
	      Object object0 = new Object();
	      leafNode0.insert((-1634), object0);
	      LinkedList<Integer> linkedList0 = new LinkedList<Integer>();
	      leafNode0.reverseToString();
	      // Undeclared exception!
	      try { 
	        leafNode0.insert(1, linkedList0);
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 0, Size: 0
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test34()  throws Throwable  {
	      LeafNode<String> leafNode0 = new LeafNode<String>(615);
	      LeafNode<String> leafNode1 = new LeafNode<String>(615, leafNode0);
	      LeafNode<String> leafNode2 = leafNode0.getNext();
	      leafNode1.insert(615, ",");
	      // Undeclared exception!
	      try { 
	        leafNode2.insert((-184), ",");
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }
}
