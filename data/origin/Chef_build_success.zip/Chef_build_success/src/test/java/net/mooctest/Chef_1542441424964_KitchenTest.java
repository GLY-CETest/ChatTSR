package net.mooctest;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;

public class Chef_1542441424964_KitchenTest {

  @Test(timeout = 4000)
  public void test() throws Exception{
      Recipe recipe = new Recipe("");
      Chef chef = new Chef("./chef");
      Recipe re1 = new Recipe("Egg");
      re1.setIngredients("2 g eggs\n1/4 t salt");
      re1.setMethod("1 Add dry ingredients to the mixing bowl.\n");
//      re1.setMethod("2.Put the eggs into the lightly. mixing bowl \n");
      re1.setMethod("3.Fold the eggs lightly. Add ingredient One.\n");
//      re1.setMethod("6.Pour contents of the bowl into the baking dish.\n");
      re1.setMethod("4.Take the eggs from refrigerator.\n");
      re1.setMethod("5.Clean the ok.\n");
      
      re1.setMethod("Divide the eggs lightly. Add ingredient One.\n");
      
      Recipe re2 = new Recipe("fuck");
      re2.setIngredients("2 g eggs\n1/4 t salt");
      re2.setMethod("1 Take the eggs from refrigerator.\n");
//      re1.setMethod("2.Put the eggs into the lightly. mixing bowl \n");
      re2.setMethod("3.Fold the eggs lightly. Add ingredient One.\n");
//      re1.setMethod("6.Pour contents of the bowl into the baking dish.\n");
      re2.setMethod("4.Add dry ingredients to the mixing bowl.\n");
      re2.setMethod("5.Clean the ok.\n");
      
      re2.setMethod("Divide the eggs lightly. Add ingredient One.\n");
      
      HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
      recipes.put("re1", re1);
//      recipes.put("re2", re2);
      Kitchen k = new Kitchen(recipes, re1);

      
      
      Container c = new Container();
      Container c2 = new Container(c);
      Container c3 = new Container();
      
      Component com1 = new Component(4, Ingredient.State.Liquid);
      Component com2 = new Component(8, Ingredient.State.Dry);
      Component com3 = new Component(8, Ingredient.State.Dry);
      c2.push(com1);
      c2.push(com2);
      c2.combine(c);
      //container
      c2.pop();
      c2.size();
      c2.liquefy();
      c2.peek();
      c2.shuffle();
      c2.serve();
      c2.clean();
      c2.stir(1);
      
      
      Assert.assertEquals(Ingredient.State.Liquid, com1.getState());
      com1.clone();
      com1.setState(Ingredient.State.Dry);
      Assert.assertEquals(Ingredient.State.Dry, com1.getState());
      com1.setValue(3);
      Assert.assertEquals(3, com1.getValue());
      com1.liquefy();
      Assert.assertEquals(Ingredient.State.Liquid, com1.getState());
      
      
      
      Ingredient in = new Ingredient("1/4 t salt");
      Ingredient in2 = new Ingredient("2 g ketchup");
      Ingredient in3 = new Ingredient("2 level ketchup");
      Ingredient in4 = new Ingredient("2 cups ketchup");
      Ingredient in5 = new Ingredient("2 ml ketchup");
      
      
      //反射吧
      java.lang.reflect.Method method = Chef.class.getDeclaredMethod("progressToExpected", int.class);
      method.setAccessible(true);
      method.invoke(chef, 1);
      method.invoke(chef, 2);
      method.invoke(chef, 3);
      method.invoke(chef, 4);
      method.invoke(chef, 5);
      method.invoke(chef, 6);
      method.invoke(chef, 0);
      
      java.lang.reflect.Method method2 = Chef.class.getDeclaredMethod("structHint", int.class);
      method2.setAccessible(true);
      method2.invoke(chef, 3);
      method2.invoke(chef, 2);
      method2.invoke(chef, 4);
      
      Container con1 = new Container();
      
      
      ChefException ex = new ChefException(4, "aaaaa");
      ex.getLocalizedMessage();
//      ex.arrayToString(null, "\n");
//      ex.arrayToString(null ," ");
      
      
      
  }
}
