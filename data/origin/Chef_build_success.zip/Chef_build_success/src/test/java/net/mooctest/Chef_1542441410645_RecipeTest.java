package net.mooctest;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

public class Chef_1542441410645_RecipeTest {

	@Test
	public void test() throws Exception {
		//fail("Not yet implemented");
		Recipe recipe1 = new Recipe("banana fish");
		recipe1.setIngredients("Ingredients.\n3 heaped apples\n3 heaped bananas\n3 heaped oranges\n2 g coffee\n500 ml milk\n2 cups salt\n3 heaped good dishes");
		recipe1.setMethod("Method."
				//+ "Take apples from refrigerator."
				+ "Put apples into the 1st mixing bowl."
				+ "Add dry ingredients to 2nd mixing bowl."
				+ "Add bananas into 1st mixing bowl."
				+ "Liquefy contents of the 2rd mixing bowl."
				+ "Liquefy coffee."
				+ "Stir the mixing bowl for 6 minutes."
				+ "Stir oranges into the 3rd mixing bowl."
				+ "Mix the 4th mixing bowl well."
				+ "Clean 5th mixing bowl."
				+ "Pour contents of the 3rd mixing bowl into the 1st baking dish."
				//+ "Set aside.Refrigerate for 1 hours."
				+ "Suggestion: "
				+ "Serve with dishes."
				//+ "cook the oranges until good."
				//+ "taste the good dishes"
				);
		Container[] contain1 = new Container[5];
		Container[] contain2 = new Container[5];
		Component com1 = new Component(1, Ingredient.State.Dry);
		Component com2 = new Component(1, Ingredient.State.Liquid);
		Component com3 = new Component(1, Ingredient.State.Dry);
		Component com4 = new Component(1, Ingredient.State.Dry);
		Component com5 = new Component(1, Ingredient.State.Dry);
		for(int i=0;i<5;i++){
			contain1[i] = new Container();
			contain2[i] = new Container();
		}
		contain1[0].push(com1);
		contain1[1].push(com2);
		contain1[2].push(com3);
		contain1[3].push(com4);
		contain1[4].push(com5);
		
		contain2[0].push(com1);
		contain2[1].push(com2);
		contain2[2].push(com3);
		contain2[3].push(com4);
		contain2[4].push(com5);
		recipe1.setCookingTime("3 52 18");
		System.out.println(recipe1.getIngredients());
		System.out.println(recipe1.getMethods());
		HashMap<String, Recipe>	recipes = new HashMap<String, Recipe>();
		Kitchen kitchen = new Kitchen(recipes, recipe1, contain1, contain2);
		Container ctest = kitchen.cook();
		System.out.println(ctest.serve());
		System.out.println(ctest.size());
		assertEquals(2, ctest.size());
		assertEquals("1 6 ", ctest.serve());
	}

}
