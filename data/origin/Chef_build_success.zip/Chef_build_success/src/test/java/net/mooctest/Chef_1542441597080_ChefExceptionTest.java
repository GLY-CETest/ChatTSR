package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Chef_1542441597080_ChefExceptionTest {

	@Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      ChefException chefException0 = new ChefException((-1), "");
	      assertEquals("Local error: ", chefException0.getMessage());
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      String[] stringArray0 = new String[2];
	      ChefException chefException0 = null;
	      try {
	        chefException0 = new ChefException(0, stringArray0, "");
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("net.mooctest.ChefException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      ChefException chefException0 = new ChefException(0, "");
	      Object[] objectArray0 = new Object[4];
	      objectArray0[0] = (Object) chefException0;
	      objectArray0[1] = (Object) chefException0;
	      objectArray0[2] = objectArray0[0];
	      objectArray0[3] = (Object) "";
	      String string0 = ChefException.arrayToString(objectArray0, "");
	      assertEquals("net.mooctest.ChefException: Structural error: net.mooctest.ChefException: Structural error: net.mooctest.ChefException: Structural error: ", string0);
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      ChefException chefException0 = null;
	      try {
	        chefException0 = new ChefException(0, (Recipe) null, 0, "", "");
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("net.mooctest.ChefException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      String[] stringArray0 = new String[2];
	      stringArray0[0] = "";
	      stringArray0[1] = "";
	      ChefException chefException0 = new ChefException(0, stringArray0, "");
	      assertEquals("Ingredient wrongly formatted: ' ' ()", chefException0.getMessage());
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      Object[] objectArray0 = new Object[1];
	      objectArray0[0] = (Object) "";
	      String string0 = ChefException.arrayToString(objectArray0, "");
	      assertEquals("", string0);
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      Object[] objectArray0 = new Object[1];
	      // Undeclared exception!
	      try { 
	        ChefException.arrayToString(objectArray0, "");
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("net.mooctest.ChefException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      Object[] objectArray0 = new Object[0];
	      String string0 = ChefException.arrayToString(objectArray0, "");
	      assertEquals("", string0);
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      ChefException chefException0 = new ChefException(1, "");
	      assertEquals("Local error: ", chefException0.getMessage());
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      ChefException chefException0 = new ChefException(0, 0, "", "");
	      assertEquals("net.mooctest.ChefException: Method error, step 1:  ()", chefException0.toString());
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      ChefException chefException0 = new ChefException(0, recipe0, 0, "", "");
	      assertEquals("net.mooctest.ChefException: Method error, recipe , step 1:  ()", chefException0.toString());
	  }
}
