package net.mooctest;
import net.mooctest.Ingredient.State;
import org.junit.Test;
import java.util.HashMap;
public class Chef_1542440611490_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
  }
  
  @Test(timeout = 4000)
  public void test1()  throws Exception{
      //Chef myChef=new Chef("src/linux.txt");
      Ingredient myIngre=new Ingredient("1258 heaped  \r\n" + 
      		"pinches \r\n" + 
      		"l\r\n" + 
      		"cups");
      Integer i = new Integer(1);
      Ingredient myIngre1=new Ingredient(i,State.Dry,"1");
      myIngre1.getAmount();
      myIngre1.getName();
      myIngre1.getstate();
      myIngre1.setAmount(20);
      myIngre1.setState(State.Dry);
      myIngre1.liquefy();
      myIngre1.dry();
      
      Component myComment= new Component(myIngre1);
      myComment.getState();
      myComment.getValue();
      myComment.liquefy();
      myComment.setValue(30);
      myComment.setState(State.Liquid);
      
      Component myComment1=myComment.clone();
      Container myContainer=new Container();
      myContainer.push(myComment1);
      Container myContainer2=new Container(myContainer);
      
      myContainer.peek();
      myContainer.pop();
      myContainer.combine(myContainer2);
      myContainer.liquefy();
      myContainer2.clean();
      myContainer.serve();
      myContainer.shuffle();
      myContainer.stir(2);
      myContainer.size();
      
//      String line="Take nima from refrigerator";
//      Method myMethod = new Method(line, 0);
      
      Recipe myRecipe= new Recipe("zjp");
      myRecipe.setIngredients("Ingredients\r\n" + 
      		"1258\r\n" + 
      		"heaped \r\n" + 
      		"pinches\r\n" + 
      		"l\r\n" + 
      		"cups\r\n"+ 
      		"nima");
      myRecipe.setComments("gousi");
      myRecipe.setCookingTime("123 1 1");
      myRecipe.setMethod("Method.\r\n" + 
      		"Take nima from refrigerator.\r\n" + 
      		"Put nidie into the 123st mixing bowl.\r\n" + 
      		"Add dry ingredients to 123st mixing bowl.");
      myRecipe.setOvenTemp("gas mark 521 12  2 1 1 1 11 1 1 ");
      myRecipe.getIngredients();
      myRecipe.getServes();
      myRecipe.getTitle();
      myRecipe.getMethod(0);
      myRecipe.getMethods();
      myRecipe.getIngredients();
      
      HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
      recipes.put("gousi", myRecipe);
      Kitchen myKitchen=new Kitchen(recipes, myRecipe);
      //myKitchen.cook();
  }




}
