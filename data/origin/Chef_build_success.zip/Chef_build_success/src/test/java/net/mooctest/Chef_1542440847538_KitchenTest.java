package net.mooctest;

import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Chef_1542440847538_KitchenTest {

  @Test(timeout = 4000)
    public void test() {
        Recipe recipe = new Recipe("");
    }

    @Test
    public void testIngredient() {
        String[] ingredientString = new String[]{"1 heaped the cup ", "2 kg meal", "3 ml water", "4 cups water", "meal"};
        try {
            Ingredient ingredient = new Ingredient(ingredientString[0]);
            ingredient = new Ingredient(ingredientString[1]);
            ingredient = new Ingredient(ingredientString[2]);
            ingredient = new Ingredient(ingredientString[3]);
            ingredient = new Ingredient(ingredientString[4]);
        } catch (ChefException e) {
            Assert.fail();
        }
        Ingredient ingredient = new Ingredient(2, Ingredient.State.Dry, "meal");
        Assert.assertEquals(2, ingredient.getAmount());
        Assert.assertEquals(Ingredient.State.Dry, ingredient.getstate());
        Assert.assertEquals("meal", ingredient.getName());
        ingredient.liquefy();
        Assert.assertEquals(Ingredient.State.Liquid, ingredient.getstate());
        ingredient.dry();
        Assert.assertEquals(Ingredient.State.Dry, ingredient.getstate());
    }

    @Test
    public void testOthers() {
        String fileName = "test.txt";
        try {
            FileWriter fileWriter = new FileWriter(fileName);
            fileWriter.write("testRecipe\n\n");
            fileWriter.write("Ingredients.\n1 heaped the test\n2 kg test\n3 ml test\n4 cups test\n\n");
            fileWriter.write("Cooking time 5\n\n");
            fileWriter.write("Pre-heat oven placeholder 3 gas mark placeholder placeholder placeholder\n\n");

            String method =
                    "Put test into the 1st mixing bowl.\n" +
                            "Add dry ingredients to 2nd mixing bowl.\n" +
                            "Add test to 2nd mixing bowl.\n" +
                            "Liquefy contents of the 2nd mixing bowl.\n" +
                            "Liquefy test.\n" +
                            "Stir the 2nd mixing bowl for 5 minutes.\n" +
                            "Stir test into the 2nd mixing bowl.\n" +
                            "Mix the 2nd mixing bowl well.\n" +
                            "Clean 2nd mixing bowl.\n" +
                            "Pour contents of the 2nd mixing bowl into the 2nd baking dish.\n" +
                            "Refrigerate for 1 hours.\n" +
                            "Serve with x.\n" +
                            "Suggestion: .\n" +
                            "test the test until test.\n" +
                            "test the test.\n" ;

            fileWriter.write("Method." + method +
                    "\n\n");
            fileWriter.write("Serves test\n\n");
            fileWriter.close();
        } catch (IOException e) {
            Assert.fail();
        }

        try {
            Chef chef = new Chef(fileName);
            Kitchen kitchen = new Kitchen(chef.recipes, chef.mainrecipe);
            kitchen.cook();
        } catch (Exception e) {
            Assert.fail();
        }

    }
}
