package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Chef_1542441597080_ComponentTest {

	@Test
	public void test() {
		int n=10;
		Ingredient.State state = Ingredient.State.Dry;
		Component c =new Component(n,state);
		assertEquals(c.getState(),state);
		assertEquals(c.getValue(),n);
		
		c.setValue(0);
		c.setState(Ingredient.State.Liquid);
		assertEquals(c.getValue(),0);
		assertEquals(c.getState(),Ingredient.State.Liquid);
	}
	@Test
	public void test02() {
		int n=10;
		Ingredient.State state = Ingredient.State.Dry;
		String name="aa";
		Ingredient a= new Ingredient(n,state,name);
		Component c =new Component(a);
		assertEquals(c.getState(),state);
		assertEquals(c.getValue(),n);
		
		c.liquefy();
		assertEquals(c.getState(),Ingredient.State.Liquid);
		
		Component cc= c.clone();
		assertEquals(c.getState(),cc.getState());
		assertEquals(c.getValue(),cc.getValue());
	}

}
