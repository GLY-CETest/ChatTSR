package net.mooctest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.lang.reflect.Constructor;

import org.junit.Test;
import org.omg.CORBA.PUBLIC_MEMBER;


public class Chef_1542439599216_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
  }
  @Test(expected=Exception.class)
  public void test1() throws Exception {
	  Chef chef = new Chef("dadsa");
  }
  @Test(expected=Exception.class)
  public void test2() throws Exception {
	  Chef chef = new Chef("1.txt");
  }
  
  @Test(timeout = 4000)
  public void test3()  {
	  try {
		Chef chef = new Chef("2.txt");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
  @Test(expected=Exception.class)
  public void test4() throws ChefException {

			Ingredient ingredient = new Ingredient("1 heaped cc");
			Ingredient ingredient2 = new Ingredient("1 heaped qw cc");
			Ingredient ingredient222 = new Ingredient("1 g cc");
			Ingredient ingredient2222 = new Ingredient("1 l cc");
			Ingredient ingredient222w2 = new Ingredient("1 cup cc");

			Ingredient ingredient22 = new Ingredient("1 ml");
	
	}
  
  @Test(timeout=4000)
  public void test5() throws ChefException {

//			Ingredient ingredient = new Ingredient("1 heaped cc");
			Ingredient ingredient = new Ingredient(1,Ingredient.State.Dry,"cc");
			assertEquals(1, ingredient.getAmount());
			ingredient.setAmount(2);
			assertEquals(2, ingredient.getAmount());
			assertEquals(Ingredient.State.Dry, ingredient.getstate());
			ingredient.liquefy();
			ingredient.dry();
			assertEquals("cc", ingredient.getName());
			ingredient.setState(Ingredient.State.Dry);
			Component component = new Component(ingredient);
			assertEquals(2, component.getValue());
			component.setValue(2);
			assertEquals(Ingredient.State.Dry, component.getState());
			component.setState(Ingredient.State.Dry);
			component.liquefy();
			component.clone();
			
			/*=============Container===============*/
			Container container = new Container();
			Container container1 = new Container(container);
			container.push(component);

			container.peek();
			container.combine(container1);

			container.shuffle();
			container.pop();
			container.size();
			container.clean();
			container.push(component);

			container.stir(3);
			container.push(component);
			container.push(component);
			container.push(component);
			container.push(component);
			container.stir(3);
			container.serve();
			container.liquefy();
			
	
	}
   @Test(expected=Exception.class)
   public void test6() throws ChefException {
	   throw new ChefException(1, 1,"dasda","asdad");
   }
   @Test(expected=Exception.class)
   public void test7() throws ChefException {
	      Recipe recipe = new Recipe("");

	   throw new ChefException(1,recipe,1,"dasdad","dasdasda");
   }
   @Test(timeout=4000)
   public void test8() throws ChefException  {
	      Recipe recipe = new Recipe("aa");
	      recipe.setIngredients("\nas\n1 g cc");
	      recipe.setComments("dasda");
	      recipe.setCookingTime("2018 8 8");
	      recipe.getServes();
	      recipe.getIngredients();
	      recipe.setMethod("\\.Take asd from refrigerator");
	      recipe.getMethod(0);
	      recipe.getMethods();
	      recipe.getIngredientValue("cc");
	      recipe.setIngredientValue("cc", 1);
	      recipe.setServes("Serves 132");
	      recipe.setOvenTemp("gas mark 2 2");
	      
	      

   }
   
   @Test(expected=Exception.class)
   public void test9() throws ChefException  {
	  new Method("Set aside", 12);
   }
   
   @Test(expected=Exception.class)
   public void test10() throws ChefException  {
	   
	   Container container = new Container();
	   container.pop();
   }
   @Test(timeout=4000)
   public void test11() throws Exception{
	   Class<?> clazz = Chef.class;
		 Constructor constructor = clazz.getDeclaredConstructor(String.class);
		 constructor.setAccessible(true);
//		 Chef chef = (Chef)constructor.newInstance("")
	   /**
		 Class<?> clazz = MSD.class;
		 Constructor constructor = clazz.getDeclaredConstructor();
		 constructor.setAccessible(true);
		 MSD msd = (MSD)constructor.newInstance();
//		 Method method=clazz.getDeclaredMethod("sort", new Class[]{String[].class});
		 Method method=clazz.getDeclaredMethod("SS", String[].class);
		 method.setAccessible(true);
			String[] a = {"1"};
		
		 method.invoke(msd, new Object[] {a}); 
		 */
   }
   
   
   
   
   
   
   
  }

