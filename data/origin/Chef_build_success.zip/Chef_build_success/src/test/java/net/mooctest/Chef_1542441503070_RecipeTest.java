package net.mooctest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

public class Chef_1542441503070_RecipeTest {

	@Before
	public void setUp() throws Exception {

	}

	/*
	 * @After public void tearDown() throws Exception { }
	 */

	@Test(timeout = 4000)
	public void test000() throws Throwable {
		Recipe recipe = new Recipe("");
		recipe.setIngredients("muling");
		recipe.setComments("mml");
		recipe.setMethod("add\nmod\\.");
		recipe.setCookingTime("30 12 20");
		try {
			recipe.setOvenTemp("mutmll");
		} catch (Exception e) {
			// TODO: handle exception
		}
		recipe.setServes("Serves 8000");
		int int0 = recipe.getServes();
		assertEquals(int0, 800);
	}

	@Test
	public void test001() throws Throwable {
		Recipe recipe = new Recipe("");
		recipe.setIngredients("muling");
		recipe.setComments("mml");
		recipe.setMethod("add\nmod\\.");
		recipe.setCookingTime("30 12 20");
		try {
			recipe.setOvenTemp("mutmll");
		} catch (Exception e) {
		}
		recipe.setServes("Serves 8000");
		recipe.getIngredients();
		try {
			recipe.getIngredientValue("30");
			recipe.getMethod(0);

		} catch (Throwable e) {
		}
		recipe.getMethods();
		recipe.getServes();
		recipe.getTitle();

	}
}
