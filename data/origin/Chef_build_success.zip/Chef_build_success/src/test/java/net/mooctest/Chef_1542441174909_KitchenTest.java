package net.mooctest;

import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

public class Chef_1542441174909_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
      Ingredient ingredient = new Ingredient(1, Ingredient.State.Dry, "hello");
      /*try {
          Ingredient ingredient1 = new Ingredient("");
      }
      catch (ChefException e) {

      }*/
      try {
          Ingredient ingredient1 = new Ingredient("5 heaped kg name");
          Ingredient ingredient2 = new Ingredient("5 ml name");
          Ingredient ingredient3 = new Ingredient("5 cup name");
          ingredient1.getAmount();
          ingredient.setAmount(1);
          ingredient1.getstate();
          ingredient1.getName();
          ingredient1.setState(Ingredient.State.Dry);
          ingredient1.liquefy();
          ingredient1.dry();
      }
      catch (ChefException e) {
        e.printStackTrace();
      }

      Component component1 = new Component(5, Ingredient.State.Dry);
      Component component2 = new Component(ingredient);

      Recipe myRecipe = new Recipe("myRecipe");
      try {
          myRecipe.setIngredients("in" + "\n" + "5 heaped kg name" + "\n" + "5 ml name");
          Method method = new Method("Take name from refrigerator.", 5);
          myRecipe.setMethod("Take name from refrigerator.Put name into 5th mixing bowl." +
                  "Add dry ingredients.Add name.Liquefy contents of the mixing bowl.Liquefy name." +
                  "Stir for 5 minutes.Stir name into the mixing bowl.Mix well.Clean mixing bowl." +
                  "Pour contents of the mixing bowl into the baking dish.Refrigerate." +
                  "Serve with name.Suggestion: .name until name.name the name.");
      }
      catch (ChefException e) {
          e.printStackTrace();
      }
      myRecipe.setComments("comment");
      myRecipe.setCookingTime("a a 4");
      myRecipe.setOvenTemp("a a a 4");
      myRecipe.getServes();
      myRecipe.getTitle();
      myRecipe.getMethod(0);
      myRecipe.getMethods();
      myRecipe.getIngredients();

      try {
          FileWriter fileWriter = new FileWriter(new File("src/temp.txt"));
          fileWriter.write("Ingredients\n5 heaped kg name");
          
      }

      catch (IOException e) {
        e.printStackTrace();
      }
      catch (Exception e) {
        e.printStackTrace();
      }
      HashMap hashMap = new HashMap<String, Recipe>();
      hashMap.put("name", myRecipe);

      Kitchen kitchen = new Kitchen(hashMap, myRecipe);
      try {
          kitchen.cook();
      }
      catch (ChefException e) {
          e.printStackTrace();
      }




  }
}
