package net.mooctest;

import static org.junit.Assert.*;


import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test; 
public class Chef_1542441559128_KitchenTest {

	@Test(timeout = 4000)
	public void testmethod01() throws ChefException{
		Method method = new Method("Take egg from refrigerator1", 3);
		method = new Method("Put egg into mixing bowl2", 3);
		method = new Method("Fold egg into mixing bowl1", 3);
		new Method("Add dry ingredients ", 2);
		new Method("Add eggs ", 4);
		new Method("Remove egg ", 4);
		new Method("Combine egg ", 4);
		new Method("Divide eggs ", 4);
		
//		new Method("Add eggs ( (to|into|from)( (\\d+)(nd|rd|th|st))? mixing bowl)?.$", 4);
//		new Method("Add eggs to 2nd mixing bowl ", 4);
//		new Method("Remove egg ( (to|into|from)( (\\d+)(nd|rd|th|st))? mixing bowl)?.$", 4);
//		new Method("Combine egg ( (to|into|from)( (\\d+)(nd|rd|th|st))? mixing bowl)?.$", 4);
//		new Method("Divide eggs ( (to|into|from)( (\\d+)(nd|rd|th|st))? mixing bowl)?.$", 4);
		
		new Method("Liquefy contents of the mixing bowl2", 5);
		new Method("Liquefy tomatoes", 6);
		new Method("Stir for 1 minutes2", 6);
		new Method("Stir eggs into the mixing bowl1", 3);
		new Method("Mix the 2nd mixing bowl well2", 6);
		
		new Method("Clean 2nd mixing bowl2", 6);
		new Method("Clean mixing bowl4", 6);
		new Method("Pour contents of the mixing bowl into the baking dish1", 6);
		new Method("Pour contents of the mixing bowl into the 1st baking dish2", 6);
		new Method("Pour contents of the 2nd mixing bowl into the baking dish3", 6);
		new Method("Pour contents of the 2nd mixing bowl into the 2nd baking dish4", 6);
		new Method("Add dry ingredients2", 6);
		
		new Method("Set aside8", 6);
		new Method("Refrigerate for 2 hours6", 6);
		new Method("Refrigerate3", 6);
		
		new Method("Serve with agg3", 6);
		new Method("Suggestion: emmm3", 6);
		new Method("Stir until Add2", 6);
		new Method("Eat the eggs2", 6);
//		new Method(, 6);
//		new Method(, 6);
	}
	
	

	
	
	@Test(timeout = 4000)
	public void testme01(){
		try {
			new Method("", 3);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	@Test(timeout = 4000)
	public void testin01() throws ChefException{
		Ingredient ingredient = new Ingredient("heaped");
		
	}
	
	
	@Test(timeout = 4000)
	public void testcon01(){
		try {
			Container container =  new Container();
			container.pop();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
  }
  
  @Test(timeout = 4000)
  public void chefextest00()  throws Throwable  {
      ChefException chefException0 = new ChefException(1, "");
      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void chefextest01()  throws Throwable  {
      Object[] objectArray0 = new Object[8];
      Object object0 = new Object();
      objectArray0[0] = object0;
      objectArray0[1] = objectArray0[0];
      objectArray0[2] = objectArray0[1];
      objectArray0[3] = objectArray0[1];
      objectArray0[4] = objectArray0[1];
      objectArray0[5] = object0;
      objectArray0[6] = objectArray0[5];
      objectArray0[7] = objectArray0[2];
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertNotNull(string0);
  }



  @Test(timeout = 4000)
  public void chefextest03()  throws Throwable  {
      ChefException chefException0 = null;

  }

  @Test(timeout = 4000)
  public void chefextest04()  throws Throwable  {
      String[] stringArray0 = new String[2];
      stringArray0[0] = "";
      stringArray0[1] = "";
      ChefException chefException0 = new ChefException(0, stringArray0, "");
      assertEquals("net.mooctest.ChefException: Ingredient wrongly formatted: ' ' ()", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void chefextest05()  throws Throwable  {
      String[] stringArray0 = new String[2];
      stringArray0[0] = "";
      ChefException chefException0 = null;

  }

  @Test(timeout = 4000)
  public void chefextest06()  throws Throwable  {
      Object[] objectArray0 = new Object[0];
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void chefextest07()  throws Throwable  {
      ChefException chefException0 = new ChefException((-1), "");
      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void chefextest08()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, 0, "", "");
      assertEquals("Method error, step 1:  ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void chefextest09()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "");
      assertEquals("Structural error: ", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void chefextest10()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ChefException chefException0 = new ChefException(0, recipe0, 0, "", "");
      assertEquals("net.mooctest.ChefException: Method error, recipe , step 1:  ()", chefException0.toString());
  }
  
  
  @Test(timeout = 4000)
  public void componenttest00()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(1, ingredient_State0);
      int int0 = component0.getValue();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void componenttest01()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      int int0 = component0.getValue();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void componenttest02()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(1, ingredient_State0);
      Component component1 = component0.clone();
      assertEquals(1, component1.getValue());
      assertEquals(1, component0.getValue());
  }

  @Test(timeout = 4000)
  public void componenttest03()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      Component component1 = component0.clone();
      assertEquals((-1), component1.getValue());
      assertEquals((-1), component0.getValue());
  }

  @Test(timeout = 4000)
  public void componenttest04()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("D");
      Component component0 = null;

  }

  @Test(timeout = 4000)
  public void componenttest05()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      component0.setState(ingredient_State0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void componenttest06()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      int int0 = component0.getValue();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void componenttest07()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
      Component component0 = new Component(ingredient0);
      component0.getState();
  }

  @Test(timeout = 4000)
  public void componenttest08()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      component0.liquefy();
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void componenttest09()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      Component component1 = component0.clone();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void componenttest10()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      component0.setValue(0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void componenttest11()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      component0.getState();
      assertEquals(0, component0.getValue());
  }
  
  @Test(timeout = 4000)
  public void continaertest00()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.push(component0);
      container0.push(component0);
      container0.push(component0);
      container0.stir(1);
      assertEquals(4, container0.size());
  }

  @Test(timeout = 4000)
  public void continaertest01()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.push(component0);
      container0.push(component0);
      container0.stir(2);
      assertEquals(3, container0.size());
  }

  @Test(timeout = 4000)
  public void continaertest02()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.stir(1);
      assertEquals(1, container0.size());
  }

  @Test(timeout = 4000)
  public void continaertest03()  throws Throwable  {
      Container container0 = new Container();
      container0.stir((-1));
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void continaertest04()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.push(component0);
      String string0 = container0.serve();
      assertEquals("\u0000\u0000", string0);
  }

  @Test(timeout = 4000)
  public void continaertest05()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      int int0 = container0.size();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void continaertest06()  throws Throwable  {
      Container container0 = new Container();
      String string0 = container0.serve();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void continaertest07()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.pop();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void continaertest08()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(1, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertEquals(Ingredient.State.Liquid, component1.getState());
  }

  @Test(timeout = 4000)
  public void continaertest09()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void continaertest10()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.peek();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void continaertest11()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      Component component1 = container0.peek();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void continaertest12()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(1, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void continaertest13()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void continaertest14()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      
  }

  @Test(timeout = 4000)
  public void continaertest15()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;

  }

  @Test(timeout = 4000)
  public void continaertest16()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      
  }

  @Test(timeout = 4000)
  public void continaertest17()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      container0.push(component0);
      
  }

  @Test(timeout = 4000)
  public void continaertest18()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      
  }

  @Test(timeout = 4000)
  public void continaertest19()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      
  }

  @Test(timeout = 4000)
  public void continaertest20()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      arrayList0.add((Component) null);
      
  }

  @Test(timeout = 4000)
  public void continaertest21()  throws Throwable  {
      Container container0 = new Container();
      
  }

  @Test(timeout = 4000)
  public void continaertest22()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      Container container1 = null;
    
  }

  @Test(timeout = 4000)
  public void continaertest23()  throws Throwable  {
      Container container0 = new Container();
      container0.stir(1);
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void continaertest24()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      String string0 = container0.serve();
      assertEquals("0 ", string0);
  }

  @Test(timeout = 4000)
  public void continaertest25()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.liquefy();
      assertEquals(1, container0.size());
  }

  @Test(timeout = 4000)
  public void continaertest26()  throws Throwable  {
      Container container0 = new Container();
 
  }

  @Test(timeout = 4000)
  public void continaertest27()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void continaertest28()  throws Throwable  {
      Container container0 = new Container();
      
  }

  @Test(timeout = 4000)
  public void continaertest29()  throws Throwable  {
      Container container0 = new Container();
      int int0 = container0.size();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void continaertest30()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      container1.contents = null;
      
  }

  @Test(timeout = 4000)
  public void continaertest31()  throws Throwable  {
      Container container0 = new Container();
      container0.clean();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void continaertest32()  throws Throwable  {
      Container container0 = new Container();
      container0.shuffle();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void continaertest33()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.pop();
     
  }

  @Test(timeout = 4000)
  public void continaertest34()  throws Throwable  {
      Container container0 = new Container();
      container0.combine(container0);
      assertEquals(0, container0.size());
  }
  
  @Test(timeout = 4000)
  public void ingredienttest00()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, (String) null);
      ingredient0.getstate();
  }

  @Test(timeout = 4000)
  public void ingredienttest01()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient((Integer) null, ingredient_State0, (String) null);
      String string0 = ingredient0.getName();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void ingredienttest02()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      String string0 = ingredient0.getName();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void ingredienttest03()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      int int0 = ingredient0.getAmount();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void ingredienttest04()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("d");
      ingredient0.setAmount(1);
      int int0 = ingredient0.getAmount();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void ingredienttest05()  throws Throwable  {
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      int int0 = ingredient0.getAmount();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void ingredienttest06()  throws Throwable  {
      Ingredient ingredient0 = null;

  }

  @Test(timeout = 4000)
  public void ingredienttest07()  throws Throwable  {
      Ingredient ingredient0 = null;

  }

  @Test(timeout = 4000)
  public void ingredienttest08()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("? 7");
      assertEquals("? 7", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void ingredienttest09()  throws Throwable  {
      Ingredient ingredient0 = null;

  }

  @Test(timeout = 4000)
  public void ingredienttest10()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("0 =");
      assertEquals("=", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void ingredienttest11()  throws Throwable  {
      Ingredient ingredient0 = null;

  }

  @Test(timeout = 4000)
  public void ingredienttest12()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("d");
      ingredient0.liquefy();
      assertEquals("d", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void ingredienttest13()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("d");
      ingredient0.dry();
      assertEquals(Ingredient.State.Dry, ingredient0.getstate());
  }

  @Test(timeout = 4000)
  public void ingredienttest14()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("d");
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      ingredient0.setState(ingredient_State0);
      assertEquals(Ingredient.State.Dry, ingredient0.getstate());
  }

  @Test(timeout = 4000)
  public void ingredienttest15()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient((Integer) null, ingredient_State0, "");
      Ingredient.State ingredient_State1 = ingredient0.getstate();
      assertSame(ingredient_State0, ingredient_State1);
  }

  @Test(timeout = 4000)
  public void ingredienttest16()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("d");
      String string0 = ingredient0.getName();
      assertEquals("d", string0);
  }

  @Test(timeout = 4000)
  public void ingredienttest17()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("d");
      
  }
  
  @Test(timeout = 4000)
  public void kitchentest0()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("e");
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      Container container1 = kitchen0.cook();
      assertSame(container1, container0);
  }

  @Test(timeout = 4000)
  public void kitchentest1()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("S");
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Recipe recipe1 = new Recipe("");
      kitchen0.recipe = recipe1;
     
  }

  @Test(timeout = 4000)
  public void kitchentest2()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("e");
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Container[] containerArray0 = new Container[5];
      Container container0 = new Container();
      containerArray0[0] = container0;
      containerArray0[1] = container0;
      containerArray0[2] = container0;
      containerArray0[3] = container0;
      containerArray0[4] = container0;
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      Container container1 = kitchen0.cook();
      assertNotSame(container1, container0);
  }

  @Test(timeout = 4000)
  public void kitchentest3()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("C");
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Container[] containerArray0 = new Container[5];
      Kitchen kitchen0 = null;
     
  }

  @Test(timeout = 4000)
  public void kitchentest4()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("F");
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container[] containerArray0 = new Container[0];
      kitchen0.mixingbowls = containerArray0;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }

  @Test(timeout = 4000)
  public void kitchentest5()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Kitchen kitchen0 = null;
    
  }
  
  @Test(timeout = 4000)
  public void methodtest0()  throws Throwable  {
      Method method0 = null;
  
  }

  @Test(timeout = 4000)
  public void methodtest1()  throws Throwable  {
      Method method0 = null;

  }
  
  @Test(timeout = 4000)
  public void recipetest00()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("K");
      
  }

  @Test(timeout = 4000)
  public void recipetest01()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      recipe0.setServes(".j.j|p>2e");
      assertEquals(2, recipe0.getServes());
  }

  @Test(timeout = 4000)
  public void recipetest02()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      String string0 = recipe0.getTitle();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void recipetest03()  throws Throwable  {
      Recipe recipe0 = new Recipe("3");
      String string0 = recipe0.getTitle();
      assertEquals("3", string0);
  }

  @Test(timeout = 4000)
  public void recipetest04()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("E");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertEquals(0, arrayList0.size());
  }

  @Test(timeout = 4000)
  public void recipetest05()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients(".");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertEquals(0, hashMap0.size());
  }

  @Test(timeout = 4000)
  public void recipetest06()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest07()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      
  }

  @Test(timeout = 4000)
  public void recipetest08()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      
  }

  @Test(timeout = 4000)
  public void recipetest09()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest10()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest11()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      
  }

  @Test(timeout = 4000)
  public void recipetest12()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest13()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      
  }

  @Test(timeout = 4000)
  public void recipetest14()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest15()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest16()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("S");
      
  }

  @Test(timeout = 4000)
  public void recipetest17()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
    
  }

  @Test(timeout = 4000)
  public void recipetest18()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("E");
      
  }

  @Test(timeout = 4000)
  public void recipetest19()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest20()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest21()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest22()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertNull(hashMap0);
  }

  @Test(timeout = 4000)
  public void recipetest23()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest24()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      int int0 = recipe0.getServes();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void recipetest25()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertNull(arrayList0);
  }

  @Test(timeout = 4000)
  public void recipetest26()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      
  }

  @Test(timeout = 4000)
  public void recipetest27()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      String string0 = recipe0.getTitle();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void recipetest28()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setComments("");
      assertEquals(0, recipe0.getServes());
  }
  
}
