package net.mooctest;

import static org.evosuite.runtime.EvoAssertions.verifyException;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.junit.Test;
import org.junit.rules.ExpectedException;

public class Chef_1542438833100_KitchenTest {
	@org.junit.Rule
    public final ExpectedException thrown = ExpectedException.none();

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
  }
  
  @Test(timeout = 4000)
  public void chef0()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("java.io.File", e);
      }
  }
  
  @Test(timeout = 4000)
  public void self000000000000000()  throws Throwable  {
      Chef chef0 = null;
      Recipe recipe0 = new Recipe("dvd");
      chef0 = new Chef("lll.txt");
        
  }
  
  @Test(timeout = 4000)
  public void self0000000000000001()  throws Throwable  {
      Chef chef0 = null;
      Recipe recipe0 = new Recipe("dvd");
      chef0 = new Chef("lll.txt");
      java.lang.reflect.Method method = null;
      thrown.expect(NullPointerException.class);
      try {
      method = Chef.class.getDeclaredMethod("structHint", new Class[]{});
      } catch (NoSuchMethodException e) {
      } catch (SecurityException e) {
      }
      method.setAccessible(true);
      try {
      method.invoke(2);
      } catch (IllegalAccessException e) {
      } catch (IllegalArgumentException e) {
      } catch (InvocationTargetException e) {
      }
     
        
  }

  @Test(timeout = 4000)
  public void chef1()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef("");
        fail("Expecting exception: FileNotFoundException");
      
      } catch(Throwable e) {
         //
         // 
         //
         verifyException("java.io.FileInputStream", e);
      }
  }
  @Test(timeout = 4000)
  public void chefexception00()  throws Throwable  {
      Object[] objectArray0 = new Object[3];
      Object object0 = new Object();
      objectArray0[0] = object0;
      objectArray0[1] = object0;
      // Undeclared exception!
      try { 
        ChefException.arrayToString(objectArray0, "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.ChefException", e);
      }
  }

  @Test(timeout = 4000)
  public void chefexception01()  throws Throwable  {
      ChefException chefException0 = new ChefException((-1), "");
      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void chefexception02()  throws Throwable  {
      String[] stringArray0 = new String[1];
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, stringArray0, "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.ChefException", e);
      }
  }

  @Test(timeout = 4000)
  public void chefexception03()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, 0, "", "");
      assertEquals("net.mooctest.ChefException: Method error, step 1:  ()", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void chefexception04()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ChefException chefException0 = new ChefException(0, recipe0, 0, "", "");
      assertEquals("Method error, recipe , step 1:  ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void chefexception05()  throws Throwable  {
      String[] stringArray0 = new String[1];
      stringArray0[0] = "";
      ChefException chefException0 = new ChefException(0, stringArray0, "");
      assertEquals("Ingredient wrongly formatted: '' ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void chefexception06()  throws Throwable  {
      Object[] objectArray0 = new Object[2];
      Object object0 = new Object();
      objectArray0[0] = object0;
      objectArray0[1] = objectArray0[0];
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertNotNull(string0);
  }

  @Test(timeout = 4000)
  public void chefexception07()  throws Throwable  {
      Object[] objectArray0 = new Object[0];
      String string0 = ChefException.arrayToString(objectArray0, (String) null);
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void chefexception08()  throws Throwable  {
      ChefException chefException0 = new ChefException(1, "");
      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void chefexception09()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "");
      assertEquals("Structural error: ", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void chefexception10()  throws Throwable  {
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, (Recipe) null, 0, "", "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.ChefException", e);
      }
  }
  
  @Test(timeout = 4000)
  public void componment00()  throws Throwable  {
      Integer integer0 = new Integer(1);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      int int0 = component0.getValue();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void componment01()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      int int0 = component0.getValue();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void componment02()  throws Throwable  {
      Component component0 = new Component(0, (Ingredient.State) null);
      component0.getState();
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void componment03()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(1, ingredient_State0);
      Component component1 = component0.clone();
      assertEquals(1, component1.getValue());
      assertEquals(1, component0.getValue());
  }

  @Test(timeout = 4000)
  public void componment04()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      Component component1 = component0.clone();
      assertEquals((-1), component1.getValue());
      assertEquals((-1), component0.getValue());
  }

  @Test(timeout = 4000)
  public void componment05()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("o");
      Component component0 = null;
      try {
        component0 = new Component(ingredient0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Ingredient", e);
      }
  }

  @Test(timeout = 4000)
  public void componment06()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.setState(ingredient_State0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void componment07()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      int int0 = component0.getValue();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void componment08()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.liquefy();
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void componment09()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      Component component1 = component0.clone();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void componment10()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.setValue(0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void componment11()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.getState();
      assertEquals(0, component0.getValue());
  }
  @Test(timeout = 4000)
  public void container00()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      arrayList0.add((Component) null);
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.addAll((Collection<? extends Component>) container0.contents);
      container0.stir(2);
      assertEquals(4, container0.size());
  }

  @Test(timeout = 4000)
  public void container01()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      arrayList0.add((Component) null);
      container0.stir(1);
      assertEquals(1, container0.size());
  }

  @Test(timeout = 4000)
  public void container02()  throws Throwable  {
      Container container0 = new Container();
      container0.stir((-1));
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void container03()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      arrayList0.add((Component) null);
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void container04()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.addAll((Collection<? extends Component>) container0.contents);
      Component component1 = container0.pop();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void container05()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      int int0 = container0.size();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void container06()  throws Throwable  {
      Container container0 = new Container();
      String string0 = container0.serve();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void container07()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      arrayList0.add((Component) null);
      Component component0 = container0.pop();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void container08()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      arrayList0.add(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void container09()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void container10()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.peek();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void container11()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void container12()  throws Throwable  {
      Container container0 = new Container();
      Ingredient ingredient0 = new Ingredient("i");
      ingredient0.setAmount(1);
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertEquals(Ingredient.State.Dry, component1.getState());
  }

  @Test(timeout = 4000)
  public void container13()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      component0.setValue((-1));
      container0.contents = arrayList0;
      Component component1 = container0.peek();
      assertEquals(Ingredient.State.Liquid, component1.getState());
  }

  @Test(timeout = 4000)
  public void container14()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      // Undeclared exception!
      try { 
        container1.size();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void container15()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.shuffle();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("java.util.Collections", e);
      }
  }

  @Test(timeout = 4000)
  public void container16()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      ingredient0.liquefy();
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("java.lang.Character", e);
      }
  }

  @Test(timeout = 4000)
  public void container17()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.push((Component) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void container18()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.pop();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void container19()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      // Undeclared exception!
      try { 
        container1.peek();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void container20()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.combine((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void container21()  throws Throwable  {
      Container container0 = null;
      try {
        container0 = new Container((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void container22()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.addAll((Collection<? extends Component>) container0.contents);
      container0.stir(1);
      assertEquals(2, container0.size());
  }

  @Test(timeout = 4000)
  public void container23()  throws Throwable  {
      Container container0 = new Container();
      container0.stir(1);
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void container24()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      String string0 = container0.serve();
      assertEquals("0 ", string0);
  }

  @Test(timeout = 4000)
  public void container25()  throws Throwable  {
      Container container0 = new Container();
      try { 
        container0.pop();
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         //
         // Local error: Folded from empty container
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void container26()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.peek();
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void container27()  throws Throwable  {
      Container container0 = new Container();
      int int0 = container0.size();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void container28()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      // Undeclared exception!
      try { 
        container1.liquefy();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void container29()  throws Throwable  {
      Container container0 = new Container();
      container0.clean();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void container30()  throws Throwable  {
      Container container0 = new Container();
      container0.shuffle();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void container31()  throws Throwable  {
      Container container0 = new Container();
      Ingredient ingredient0 = new Ingredient("i");
      ingredient0.setAmount(0);
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      container0.liquefy();
      String string0 = container0.serve();
      assertEquals("\u0000", string0);
  }

  @Test(timeout = 4000)
  public void container32()  throws Throwable  {
      Container container0 = new Container();
      container0.combine(container0);
      assertEquals(0, container0.size());
  }
  @Test(timeout = 4000)
  public void ingredient00()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient((Integer) null, ingredient_State0, (String) null);
      String string0 = ingredient0.getName();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void ingredient01()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      String string0 = ingredient0.getName();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void ingredient02()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      int int0 = ingredient0.getAmount();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void ingredient03()  throws Throwable  {
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      int int0 = ingredient0.getAmount();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void ingredient04()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Ingredient", e);
      }
  }

  @Test(timeout = 4000)
  public void ingredient05()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient(" ");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 0
         //
         verifyException("net.mooctest.Ingredient", e);
      }
  }

  @Test(timeout = 4000)
  public void ingredient06()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("Q g");
      assertEquals("Q g", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void ingredient07()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("5 l");
        fail("Expecting exception: ChefException");
      
      } catch(Throwable e) {
         //
         // Ingredient wrongly formatted: '5 l' (ingredient name missing)
         //
         verifyException("net.mooctest.Ingredient", e);
      }
  }

  @Test(timeout = 4000)
  public void ingredient08()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("5 c");
      ingredient0.getAmount();
      assertEquals("c", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void ingredient09()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"\"
         //
         verifyException("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void ingredient10()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient((Integer) null, (Ingredient.State) null, (String) null);
      ingredient0.getstate();
  }

  @Test(timeout = 4000)
  public void ingredient11()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      ingredient0.liquefy();
      assertEquals(Ingredient.State.Liquid, ingredient0.getstate());
  }

  @Test(timeout = 4000)
  public void ingredient12()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      ingredient0.dry();
      assertEquals(Ingredient.State.Dry, ingredient0.getstate());
  }

  @Test(timeout = 4000)
  public void ingredient13()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      ingredient0.setAmount(0);
      assertEquals(0, ingredient0.getAmount());
  }

  @Test(timeout = 4000)
  public void ingredient14()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      Ingredient.State ingredient_State0 = ingredient0.getstate();
      ingredient0.setState(ingredient_State0);
      assertEquals("c", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void ingredient15()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      String string0 = ingredient0.getName();
      assertEquals("c", string0);
  }

  @Test(timeout = 4000)
  public void ingredient16()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      // Undeclared exception!
      try { 
        ingredient0.getAmount();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Ingredient", e);
      }
  }
  
  @Test(timeout = 4000)
  public void kitchen0()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("S");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      container0.push((Component) null);
      Container container1 = kitchen0.cook();
      assertSame(container1, container0);
  }
  
  @Test(timeout = 4000)
  public void kself0000000()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("Take");
      
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      container0.push((Component) null);
      Container container1 = kitchen0.cook();
      assertSame(container1, container0);
  }
  
  @Test(timeout = 4000)
  public void self00000000000()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("S");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      container0.push((Component) null);
      Container container1 = kitchen0.cook();
      assertSame(container1, container0);
  }

  @Test(timeout = 4000)
  public void kitchen1()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("x");
      Container[] containerArray0 = new Container[0];
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      kitchen0.recipe = null;
      // Undeclared exception!
      try { 
        kitchen0.cook();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Kitchen", e);
      }
  }

  @Test(timeout = 4000)
  public void kitchen2()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod(">");
      Container[] containerArray0 = new Container[0];
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.mixingbowls = containerArray0;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }
  
  @Test(timeout = 4000)
  public void self2()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod(">");
      recipe0.setCookingTime("0 1 1 1");
      recipe0.setOvenTemp("0 1 1 1");
      Container[] containerArray0 = new Container[0];
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.mixingbowls = containerArray0;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }

  @Test(timeout = 4000)
  public void selff2()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod(">");
      recipe0.setCookingTime("0 1 1 1");
      recipe0.setOvenTemp("gas mark 1 2 1 1 1 2b 3 3 3 3");
      Container[] containerArray0 = new Container[0];
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.mixingbowls = containerArray0;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }

  @Test(timeout = 4000)
  public void kitchen3()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Container[] containerArray0 = new Container[1];
      Container container0 = new Container();
      recipe0.setMethod("MethodTakePut");
      containerArray0[0] = container0;
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      Container container1 = kitchen0.cook();
      assertFalse(container1.equals((Object)container0));
  }

  @Test(timeout = 4000)
  public void kitchen4()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Container[] containerArray0 = new Container[1];
      recipe0.setMethod("X");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void kitchen5()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Kitchen", e);
      }
  }
  @Test(timeout = 4000)
  public void method0()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method((String) null, 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Method", e);
      }
  }

  @Test(timeout = 4000)
  public void method1()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method("", 0);
        fail("Expecting exception: ChefException");
      
      } catch(Throwable e) {
         //
         // Method error, step 1:  (Unsupported method found!)
         //
         verifyException("net.mooctest.Method", e);
      }
  }
  
  @Test(timeout = 4000)
  public void recipe00()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("J");
      // Undeclared exception!
      try { 
        recipe0.setIngredientValue("", 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe01()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setServes("!:/]TVa5/");
      assertEquals("", recipe0.getTitle());
  }

  @Test(timeout = 4000)
  public void recipe02()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      String string0 = recipe0.getTitle();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void recipe03()  throws Throwable  {
      Recipe recipe0 = new Recipe("T");
      String string0 = recipe0.getTitle();
      assertEquals("T", string0);
  }

  @Test(timeout = 4000)
  public void recipe04()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("=");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertTrue(arrayList0.isEmpty());
  }

  @Test(timeout = 4000)
  public void recipe05()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("s");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertTrue(hashMap0.isEmpty());
  }

  @Test(timeout = 4000)
  public void recipe06()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes("GDjdskvb");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"\"
         //
         verifyException("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe07()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setServes((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe08()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("   f");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"f\"
         //
         verifyException("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe09()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe10()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 3
         //
         verifyException("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe11()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setMethod("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("java.util.Scanner", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe12()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setMethod((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe13()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setIngredients("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("java.util.Scanner", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe14()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setIngredients((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("java.io.StringReader", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe15()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("  (");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"(\"
         //
         verifyException("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe16()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 2
         //
         verifyException("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe17()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("D");
      // Undeclared exception!
      try { 
        recipe0.getMethod((-1));
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void recipe18()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("Y");
      // Undeclared exception!
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: IndexOutOfBoundsException");
      
      } catch(IndexOutOfBoundsException e) {
         //
         // Index: 0, Size: 0
         //
         verifyException("java.util.ArrayList", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe19()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setMethod("^.$");
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         //
         // Method error, step 1: $. (Unsupported method found!)
         //
         verifyException("net.mooctest.Method", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe20()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe21()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe22()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertNull(hashMap0);
  }

  @Test(timeout = 4000)
  public void recipe23()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes("");
        fail("Expecting exception: StringIndexOutOfBoundsException");
      
      } catch(StringIndexOutOfBoundsException e) {
      }
  }

  @Test(timeout = 4000)
  public void recipe24()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      int int0 = recipe0.getServes();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void recipe25()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertNull(arrayList0);
  }

  @Test(timeout = 4000)
  public void recipe26()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getIngredientValue("");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void recipe27()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      String string0 = recipe0.getTitle();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void recipe28()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setComments("");
      assertEquals(0, recipe0.getServes());
  }
}
