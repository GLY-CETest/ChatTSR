package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Chef_1542441597080_IngredientTest {
	
	@Test
	public void test01(){
        Integer n = new Integer(1);
        Ingredient.State state = Ingredient.State.Dry;
        String name="a";
        Ingredient ingredient = new Ingredient(n,state,name);
        assertEquals(ingredient.getAmount() ,n.intValue());
        assertEquals(ingredient.getstate(),state);
        assertEquals(ingredient.getName(),name);
        
        ingredient.setAmount(0);
        ingredient.setState(Ingredient.State.Liquid);
        assertEquals(ingredient.getAmount(),0);
        assertEquals(ingredient.getstate(),Ingredient.State.Liquid);
        
        ingredient.dry();
        assertEquals(ingredient.getstate(),Ingredient.State.Dry);
        ingredient.liquefy();
        assertEquals(ingredient.getstate(),Ingredient.State.Liquid);
        
    }
	@Test 
	public void test02() throws ChefException {
		
		Ingredient a= new Ingredient("12 ml dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Liquid);
		assertEquals(a.getName(),"dsaf");
		a= new Ingredient("12 l dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Liquid);
		assertEquals(a.getName(),"dsaf");
		a= new Ingredient("12 dashes dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Liquid);
		assertEquals(a.getName(),"dsaf");
		a= new Ingredient("12 dash dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Liquid);
		assertEquals(a.getName(),"dsaf");
		
		a= new Ingredient("12 heaped dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		
		a= new Ingredient("12 level dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		
		a= new Ingredient("12 g dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		
		a= new Ingredient("12 kg dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		
		a= new Ingredient("12 pinches dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		a= new Ingredient("12 pinch dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		
		a= new Ingredient("12 cups dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		a= new Ingredient("12 cup dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		
		a= new Ingredient("12 teaspoons dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		a= new Ingredient("12 teaspoon dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		
		a= new Ingredient("12 tablespoons dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		a= new Ingredient("12 tablespoon dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"dsaf");
		
		a= new Ingredient("12 afkal dsaf");
		assertEquals(a.getAmount(),12);
		assertEquals(a.getstate(),Ingredient.State.Dry);
		assertEquals(a.getName(),"afkal dsaf");
	}
	
	@Test
	public void test03() throws ChefException {
		Ingredient a= new Ingredient("fa");
	}
	

}
