package net.mooctest;

import org.junit.Assert;
import org.junit.Test;

import java.io.*;

import static org.junit.Assert.assertEquals;

public class Chef_1542441197284_KitchenTest {

    @Test(timeout = 4000)
    public void test(){
        Recipe recipe = new Recipe("");
    }

    @Test
    public void testChef() throws Exception {
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        String s = new String("food\n" +
                "\n" +
                "Ingredients\n" +
                "ddd heaped\n" +
                "1 heaped heaped\n" +
                "2 kg kg\n" +
                "3 ml milk\n" +
                "4 teaspoon teaspoon\n" +
                "5 pinch pinch\n" +
                "\n" +
                "Cooking time 7\n" +
                "\n" +
                "Pre-heat oven oventemp 3 gas mark 1 2 3zzzzmark\n" +
                "\n" +
                "Method.\n" +
                "Take heaped from refrigerator.\n" +
                "Put teaspoon into 6rd mixing bowl.\n" +
                "\n" +
                "Serves 562548565");
        fileWriter.write(s);
        fileWriter.close(); // 关闭数据流
            Chef chef = new Chef("src/main/resources/demo.txt");
        InputStream inputStream = System.in;
        ByteArrayInputStream is = new ByteArrayInputStream("3".getBytes());
        System.setIn(is);
        chef.bake();
        System.setIn(inputStream);
        is.close();
    }
    @Test
    public void testempty(){
        try{
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
            fileWriter = new FileWriter(file);
            fileWriter.write("");
            fileWriter.close(); // 关闭数据流
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (Exception e){
            Assert.assertEquals(e.getMessage(),"Structural error: Recipe empty or title missing!");
            return;
        }
        Assert.fail();
    }
    @Test
    public void testrank() throws Exception {

        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        try{
            fileWriter = new FileWriter(file);
            fileWriter.write("food\n" +
                    "\n" +
                    "Cooking time 7\n" +
                    "\n" +
                    "Ingredients\n" +
                    "ddd heaped\n" +
                    "1 heaped heaped\n" +
                    "2 kg kg");
            fileWriter.close(); // 关闭数据流
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (ChefException e){
            Assert.assertEquals(e.getMessage(),"Structural error: Read unexpected ingredient list. Expecting oven temperature");
            // 比较异常代码
            return;
        }
        Assert.fail();
    }
    @Test
    public void testnull() throws Exception {
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);

        try{
            fileWriter = new FileWriter(file);
            fileWriter.write("Ingredients\n" +
                    "ddd heaped");
            fileWriter.close(); // 关闭数据流
            Chef chef = new Chef("src/main/resources/demo.txt");
        } catch (NullPointerException e) {
            return;
        }
        Assert.fail();
    }

    @Test
    public void test12() throws Exception {
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        String s = new String("food\n" +
                "\n" +
                "Ingredients\n" +
                "ddd heaped\n" +
                "1 heaped heaped\n" +
                "2 kg kg\n" +
                "3 ml milk\n" +
                "4 teaspoon teaspoon\n" +
                "5 pinch pinch\n" +
                "\n" +
                "Cooking time 7\n" +
                "\n" +
                "Pre-heat oven oventemp 3 gas mark 1 2 3zzzzmark\n" +
                "\n" +
                "Method.\n" +
                "Take a from refrigerator.\n" +
                "Add dry ingredients mixing bowl.\n" +
                "Put f into 6rd mixing bowl.\n" +
                "Divide z from 2nd mixing bowl.\n" +
                "Liquefy contents of the 8st mixing bowl.\n" +
                "Liquefy Z.\n" +
                "Stir for 9 minutes.\n" +
                "Stir f into the 9st mixing bowl.\n" +
                "Mix the 8th mixing bowl well.\n" +
                "Clean 2rd mixing bowl.\n" +
                "Pour contents of the mixing bowl into the baking dish.\n" +
                "Set aside.\n" +
                "Refrigerate.\n" +
                "Serve with w.\n" +
                "Suggestion: .\n" +
                "q until s.\n" +
                "w the w.\n" +
                "\n" +
                "Serves 562548565");
        fileWriter.write(s);
        fileWriter.close(); // 关闭数据流
        try{
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (ChefException e){
            Assert.fail();
        }
    }

    @Test
    public void testrank2() throws Exception {

        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        try{
            fileWriter = new FileWriter(file);
            fileWriter.write("food\n" +
                    "\n" +
                    "Cooking time 7\n" +
                    "\n" +
                    "Insa");
            fileWriter.close(); // 关闭数据流
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (ChefException e){
            Assert.assertEquals(e.getMessage(),"Structural error: Read unexpected comments/title. Expecting oven temperature Hint:no hint available");
            // 比较异常代码
            return;
        }
        Assert.fail();
    }

    @Test
    public void testChef2() throws Exception {
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        String s = new String("food\n" +
                "\n" +
                "Ingssredients\n");
        fileWriter.write(s);
        fileWriter.close();
        try{
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (ChefException e){
            Assert.fail();
        }
    }
    @Test
    public void testChef3() throws Exception {
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        String s = new String("food\n" +
                "\n" +
                "Ingredients\n" +
                "ddd heaped\n" +
                "1 heaped heaped\n" +
                "2 kg kg\n\naa");
        fileWriter.write(s);
        fileWriter.close();
        try{
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (ChefException e){
            return;
        }
        Assert.fail();
    }
    @Test
    public void testChef4() throws Exception {
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        String s = new String("food\n" +
                "\n" +
                "Cooking time 7\n\nIngredients");
        fileWriter.write(s);
        fileWriter.close();
        try{
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (ChefException e){
            return;
        }
        Assert.fail();
    }
    @Test
    public void testChef5() throws Exception {
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        String s = new String("food\n" +
                "\n" +
                "Pre-heat oven oventemp 3 gas mark 1 2 3zzzzmark\n" +
                "\n" +
                "Ingredients");
        fileWriter.write(s);
        fileWriter.close();
        try{
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (ChefException e){
            return;
        }
        Assert.fail();
    }
    @Test
    public void testChef6() throws Exception {
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        String s = new String("food\n" +
                "\n" +
                "Method.\n" +
                "Take a from refrigerator.\n" +
                "Add dry ingredients mixing bowl.\n" +
                "\n" +
                "Ingredients");
        fileWriter.write(s);
        fileWriter.close();
        try{
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (ChefException e){
            return;
        }
        Assert.fail();
    }
    @Test
    public void testChef7() throws Exception {
        File file = new File("src/main/resources/demo.txt");
        if (!file.getParentFile().exists()){
            file.getParentFile().createNewFile();
        }
        if (!file.exists()){
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file);
        String s = new String("food\n" +
                "\n" +
                "Serves 562548565\n" +
                "\n" +
                "Ingredients");
        fileWriter.write(s);
        fileWriter.close();
        try{
            Chef chef = new Chef("src/main/resources/demo.txt");
        }catch (ChefException e){
            return;
        }
        Assert.fail();
    }
}
