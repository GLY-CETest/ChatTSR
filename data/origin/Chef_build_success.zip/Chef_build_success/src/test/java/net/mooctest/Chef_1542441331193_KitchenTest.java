package net.mooctest;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

import net.mooctest.Ingredient.State;

public class Chef_1542441331193_KitchenTest {
	String fp = "src/main/resources/demo.txt";
	@Test(timeout = 4000)
	public void test() {
		Recipe recipe = new Recipe("test");
		a(recipe.getTitle(), "test");
		try {
			Chef chef = new Chef(fp);
		} catch (Exception e) {
			e.printStackTrace();
			//a(e.getClass(), ChefException.class);
			//a(e.getMessage(), "Structural error: Recipe empty or title missing!");
		}
		
		recipe.setComments("this is a comment");
		recipe.setCookingTime("1 2 20");
		try {
			recipe.setIngredients("2 heaped kg\ndd\ncc\n");
		} catch (ChefException e) {
			e.printStackTrace();
		}
		recipe.setOvenTemp("gas mark 22 333 444 555 666 777 888");
		recipe.setServes("13432424134");
		try {
			recipe.setMethod("Take f from refrigerator\\. Take f from refrigerator\\. ");
		} catch (ChefException e) {
			a(e.getMessage(), "Method error, step 1: Take f from refrigerator\\. (Unsupported method found!)");
		}
		
		
	}
	
	@Test(timeout=4000)
	public void testM() {
		// component
		Component component = new Component(3, Ingredient.State.Dry);
		Component component2 = component.clone();
		a(component.getState(), Ingredient.State.Dry);
		a(component.getValue(), 3);
		component.setState(Ingredient.State.Liquid);
		component.setValue(8);
		a(component.getState(), Ingredient.State.Liquid);
		a(component.getValue(), 8);
		a(component2.getState(), Ingredient.State.Dry);
		a(component2.getValue(), 3);
		component2.liquefy();
		a(component2.getState(), Ingredient.State.Liquid);
		
		//ingredient
		Ingredient ingredient = new Ingredient(10, Ingredient.State.Dry, "salt");
		a(ingredient.getAmount(), 10);
		a(ingredient.getName(), "salt");
		a(ingredient.getstate(), Ingredient.State.Dry);
		ingredient.liquefy();
		a(ingredient.getstate(), Ingredient.State.Liquid);
		ingredient.dry();
		a(ingredient.getstate(), Ingredient.State.Dry);
		ingredient.setAmount(6);
		ingredient.setState(Ingredient.State.Liquid);
		a(ingredient.getstate(), Ingredient.State.Liquid);
		
		try {
			Ingredient ingredient2 = new Ingredient("5 heaped kg salt");
			a(ingredient2.getAmount(), 5);
			a(ingredient2.getName(), "salt");
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			Ingredient ingredient2 = new Ingredient("5 heaped ml salt");
			a(ingredient2.getAmount(), 5);
			a(ingredient2.getName(), "salt");
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//method
		try {
			Method method = new Method("Take salt from refrigerator.", 2);
			Method method2 = new Method("Put salt into mixing bowl.", 10);
			Method method3 = new Method("Add dry ingredients.", 2);
			Method method4 = new Method("Remove salt from mixing bow.", 1);
			Method method5 = new Method("Liquefy contents of the mixing bowl.", 2);
			Method method6 = new Method("Liquefy salt.", 1);
			Method method7 = new Method("Stir for 5 minutes.", 2);
			Method method8 = new Method("Stir salt into the mixing bowl.", 2);
			Method method9 = new Method("Mix well.", 2);
			Method method10 = new Method("Clean mixing bowl.", 2);
			Method method11 = new Method("Pour contents of the 2nd mixing bowl into the 2nd baking dish.", 2);
			Method method12 = new Method("Set aside.", 2);
			Method method13 = new Method("Refrigerate for 5 hours.", 2);
			Method method14 = new Method("Serve with salt.", 2);
			Method method15 = new Method("Suggestion: no.", 2);
			Method method16 = new Method("salt until salt.", 2);
			Method method17 = new Method("test the salt.", 2);
			
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Container container = new Container();
		component.setState(State.Dry);
		try {
			container.pop();
		} catch (ChefException e) {
			a(e.getMessage(), "Local error: Folded from empty container");
		}
		container.push(component);
		container.push(component2);
		a(container.size(), 2);
		container.push(component2);
		a(container.size(), 3);
		container.peek();
		a(container.size(), 3);
		try {
			container.pop();
			a(container.size(), 2);
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Container container2 = new Container();
		container2.push(component);
		container.combine(container2);
		a(container.size(), 3);
		container.liquefy();
		container2.clean();
		a(container2.size(), 0);
		container.serve();
		container.shuffle();
		container.stir(30);
		Container container3 = new Container(container);
		a(container3.size(), 3);
		
		Recipe recipe = new Recipe("test");
		recipe.setComments("this is a comment");
		recipe.setCookingTime("1 2 20");
		try {
			recipe.setIngredients("5 heaped kg salt");
		} catch (ChefException e) {
			e.printStackTrace();
		}
		recipe.setOvenTemp("gas mark 22 333 444 555 666 777 888");
		recipe.setServes("13432424134");
		try {
			recipe.setMethod("Take f from refrigerator\\. Take f from refrigerator\\. ");
		} catch (ChefException e) {
			a(e.getMessage(), "Method error, step 1: Take f from refrigerator\\. (Unsupported method found!)");
		}
		try {
			recipe.setMethod("Take salt from refrigerator.");
		} catch (ChefException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		Recipe recipe2 = new Recipe("test2");
		recipe2.setComments("this is a comment2");
		recipe2.setCookingTime("1 2 20");
		try {
			recipe2.setIngredients("5 heaped kg salt");
		} catch (ChefException e) {
			e.printStackTrace();
		}
		recipe2.setOvenTemp("gas mark 22 333 444 555 666 777 888");
		recipe2.setServes("13432424134");
		try {
			recipe2.setMethod("Take f from refrigerator\\. Take f from refrigerator\\. ");
		} catch (ChefException e) {
			a(e.getMessage(), "Method error, step 1: Take f from refrigerator\\. (Unsupported method found!)");
		}
		try {
			recipe2.setMethod("Take salt from refrigerator.");
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HashMap<String, Recipe> rs = new HashMap<String, Recipe>();
		rs.put("test", recipe);
		rs.put("test2", recipe2);
		
		Kitchen kitchen = new Kitchen(rs, recipe);
		try {
			kitchen.cook();
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private <T> void a(T a, T b) {
		assertEquals(a, b);
	}

	private <T> void p(T x) {
		System.out.println(x);
	}
}
