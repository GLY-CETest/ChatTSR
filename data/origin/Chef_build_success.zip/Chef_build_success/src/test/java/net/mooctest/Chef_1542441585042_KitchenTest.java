package net.mooctest;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class Chef_1542441585042_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
      try {
		Method method = new Method("Take level from refrigerator.", 1);
		method = new Method("Put level into the 123nd mixing bowl.", 1);
		method = new Method("Fold level into the 123nd mixing bowl.", 1);
		method = new Method("Add dry ingredients to 11st mixing bowl.", 1);
		method = new Method("Add level to 123nd mixing bowl.", 1);
		method = new Method("Liquefy contents of the 123nd mixing bowl.", 1);
		method = new Method("Liquefy level.", 1);
		method = new Method("Stir the 123nd mixing bowl for 3 minutes.", 1);
		method = new Method("Stir level into the 123nd mixing bowl.", 1);
		method = new Method("Mix the 123nd mixing bowl well.", 1);
		method = new Method("Clean 123nd mixing bowl.", 1);
		method = new Method("Pour contents of the 123nd mixing bowl into the 123nd baking dish.", 1);
		method = new Method("Set aside.", 1);
		method = new Method("Refrigerate for 3 hours.", 1);
		method = new Method("Serve with level.", 1);
		method = new Method("Suggestion: ...", 1);
		method = new Method("level the level until level.", 1);
		method = new Method("level the level.", 1);
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      
      try {
		Method method = new Method("sdf", 1);
	} catch (ChefException e) {
		assertEquals(ChefException.class, e.getClass());
	}
      
    recipe = new Recipe("ttt");
    try {
		recipe.setMethod("Take level from refrigerator.\nPut level into the 123nd mixing bowl.Fold level into the 123nd mixing bowl.Add dry ingredients to 11st mixing bowl."
				+ "Liquefy contents of the 123nd mixing bowl.Liquefy level.Stir the 123nd mixing bowl for 3 minutes."
				+ "Stir level into the 123nd mixing bowl.Mix the 123nd mixing bowl well.Clean 123nd mixing bowl.Pour contents of the 123nd mixing bowl into the 123nd baking dish."
				+ "Refrigerate for 3 hours.Serve with level.level the level until level.level the level.");
		recipe.setIngredients("\n12 level aaa\n13 level level");
		recipe.setCookingTime("1 12 3");
		recipe.setIngredientValue("level", 4);
		recipe.setServes("serves 123");
		assertEquals(4, recipe.getIngredientValue("level"));
		assertEquals("ttt", recipe.getTitle());
		assertEquals(12, recipe.getServes());
		assertEquals(1, recipe.getIngredients().size());
		assertEquals(14, recipe.getMethods().size());
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
    Ingredient ingredient = new Ingredient(3, Ingredient.State.Dry, "dry");
    try {
		ingredient = new Ingredient("!");
	} catch (ChefException e1) {
		// TODO Auto-generated catch block
		assertEquals(ChefException.class, e1.getClass());
	}
    Container container = new Container();
    try {
		container.pop();
	} catch (ChefException e1) {
		// TODO Auto-generated catch block
		assertEquals(ChefException.class, e1.getClass());
	}
    container = new Container(container);
    try {
		ingredient = new Ingredient("12 heaped aaa");
		container.push(new Component(ingredient));
		container.push(new Component(new Ingredient("12 level aaa")));
		container.push(new Component(new Ingredient("12 pinches aaa")));
		container.push(new Component(new Ingredient("12 dashes aaa")));
		container.push(new Component(new Ingredient("12 cups aaa")));
		assertEquals(12, ingredient.getAmount());
		assertEquals("aaa", ingredient.getName());
		assertEquals(5, container.size());
		assertEquals("12 12 12 12 ", container.serve());
		
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
    Map<String, Recipe> reMap = new HashMap<String, Recipe>();
    Recipe recipe2 = new Recipe("eee");
    
    try {
		recipe2.setIngredients("\n12 level aaa\n13 level level");
	} catch (ChefException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
    reMap.put("level", recipe2);
    reMap.put("le", recipe);
    Kitchen kitchen = new Kitchen((HashMap<String, Recipe>) reMap, recipe);
    try {
		kitchen.cook();
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		assertEquals(ChefException.class, e.getClass());
	}
    kitchen = new Kitchen((HashMap<String, Recipe>)reMap, recipe, new Container[]{container}, new Container[]{container});
   
    try {
		kitchen.cook();
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
}

