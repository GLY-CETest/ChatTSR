package net.mooctest;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertFalse;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import net.mooctest.Ingredient.State;

public class Chef_1542441511445_KitchenTest {

	@Test(timeout = 4000)
	public void test1() throws Exception {
		try {
			Ingredient ingredient = new Ingredient("");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Ingredient ingredient1 = new Ingredient("^\\d*$");
		try {
			Component component = new Component(ingredient1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Ingredient ingredient2 = new Ingredient(0, ingredient1.getstate(), "");

		Component component2 = new Component(ingredient2);

		Container container = new Container();
		container.contents = new ArrayList<Component>();
		container.size();
		container.combine(container);
		container.liquefy();
		container.serve();
		container.stir(0);
		try {
			container.pop();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Container container2 = new Container(container);
		container2.contents = new ArrayList<Component>();
		container2.combine(container);
		container2.liquefy();
		container2.stir(1);

		Ingredient ingredient3 = new Ingredient(6, ingredient1.getstate(), "^\\d345*S");
		Component component3 = new Component(ingredient3);

		Container container3 = new Container();
		container3.contents = new ArrayList<Component>();
		container3.combine(container);
		container3.liquefy();
		container3.serve();
		container3.stir(3);

		Container container4 = new Container();
		container4.contents = new ArrayList<Component>();
		container4.combine(container3);
		container4.liquefy();
		container4.serve();
		container4.stir(5);
		try {
			container4.pop();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(timeout = 4000)
	public void test2() throws Exception {
		try {
			Method method = new Method("", 0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Method method1 = new Method("Add", 3);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// Method method1 = new Method("Take" + "Put" + "Fold" + "Add" + "Remove" +
		// "Combine" + "Divide", 3);
	}

	@Test(timeout = 4000)
	public void test3() throws Exception {
		Recipe recipe = new Recipe("");
		try {
			recipe.setIngredients("");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		recipe.setIngredients("1");
		recipe.setIngredients("Add");
		try {
			recipe.setIngredientValue("gasmark", 6);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			recipe.setMethod("");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		recipe.setMethod("recipe");
		recipe.getMethods();
		// recipe.setMethod("recipe.getMethod");

		try {
			recipe.setOvenTemp("");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			recipe.setOvenTemp("20180101");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(timeout = 4000)
	public void test4() throws Exception {
		File file = new File("demo.txt");
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		bw.write("Add");
		bw.write("hello\n");
		try {
			Chef chef = new Chef("");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Chef chef = new Chef("demo.txt");
			BufferedWriter b = new BufferedWriter(new FileWriter(file));
			b.write("da");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ChefException cException = new ChefException(0, "");
		Object[] a = {};
		try {
			cException.arrayToString(null, "");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cException.arrayToString(a, "");
		Object[] a1 = { "abc", "aaa" };
		cException.arrayToString(a1, "abc");
		ChefException cException1 = new ChefException(1, "");
	}

	@Test(timeout = 4000)
	public void test5() throws Exception {
		try {
			Kitchen kitchen = new Kitchen(null, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Recipe recipe = new Recipe("Add");
		HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
		try {
			Kitchen kitchen = new Kitchen(recipes, recipe);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		recipe.setIngredients("1 Add 3\n");
		recipe.setComments("a");
		recipe.setMethod("Add");
		Kitchen kitchen = new Kitchen(recipes, recipe);
		kitchen.cook();

		recipe.setIngredients("1 Add 3\n1 Add 3\n1 Add 3");
		recipe.setComments("Add");
		recipe.setMethod("Add");
		Kitchen kitchen1 = new Kitchen(recipes, recipe);
		kitchen1.cook();
	}
}
