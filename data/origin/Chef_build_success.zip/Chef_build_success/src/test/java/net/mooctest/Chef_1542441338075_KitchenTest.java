package net.mooctest;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.util.HashMap;

import static org.junit.Assert.*;

public class Chef_1542441338075_KitchenTest {

  @Test()
  public void test() throws Throwable {
      Recipe recipe = new Recipe("1");
      try {

      }catch (Exception e) {

      }
      try {
          recipe.setIngredients("1\n2 heaped g\n3");
          fail();
      }catch (Exception e) {

      }
      recipe.setIngredients("1\n2 heaped g chef1 name\n3 heaped ml chef2\n4 cup chef3\nnao\n5 chef3");

      recipe.setComments("comment");
      try {
          recipe.setMethod("method\\\\.Take a from refrigerator.");
          recipe.setMethod("hh\\\\.Put a into the 1st mixing bowl.");
      }catch (Exception e) {
          fail();
      }

      recipe.setCookingTime("1 2 3");
      recipe.setOvenTemp("1 2 3 4 5 6 7 8 9 gas mark");
      recipe.setServes("Serves 12");
      a(recipe.getServes(), 1);
      a(recipe.getTitle(), "1");
      a(recipe.getIngredientValue("chef1 name"), 2);
      a(recipe.getIngredientValue("chef2"), 3);
      recipe.setIngredientValue("chef3", 4);
      a(recipe.getIngredientValue("chef3"), 4);
      a(recipe.getMethod(0).type.toString(), "Put");
      at(recipe.getMethods() != null);
      at(recipe.getIngredients() != null);


  }

    @Test(timeout = 4000)
    public void test1() throws Throwable {
        Ingredient ingredient = new Ingredient(2, Ingredient.State.Dry, "2");
        a(ingredient.getAmount(), 2);
        a(ingredient.getstate(), Ingredient.State.Dry);
        a(ingredient.getName(), "2");
        ingredient.liquefy();
        a(ingredient.getstate(), Ingredient.State.Liquid);
        ingredient.dry();
        a(ingredient.getstate(), Ingredient.State.Dry);
        ingredient.setState(Ingredient.State.Liquid);
        a(ingredient.getstate(), Ingredient.State.Liquid);
    }

    @Test(timeout = 4000)
    public void test2() throws Throwable {
        Component component = new Component(1, Ingredient.State.Dry);
        a(component.getValue(), 1);
        a(component.getState(), Ingredient.State.Dry);
        component.setValue(2);
        component.setState(Ingredient.State.Liquid);
        a(component.getValue(), 2);
        a(component.getState(), Ingredient.State.Liquid);
        at(component.clone() != null);
        component.setState(Ingredient.State.Dry);
        component.liquefy();
        a(component.getState(), Ingredient.State.Liquid);

        Container container = new Container();
        at(container.contents != null);
        container = new Container();
        container.push(component);
        component = new Component(new Ingredient(20, Ingredient.State.Dry, "chef"));
        container.push(component);
        a(container.peek().getValue(), 20);
        a(container.size(), 2);
        Container container1 = new Container(container);
        container1.push(new Component(new Ingredient(10, Ingredient.State.Liquid, "chef1")));
        container.combine(container1);
        a(container.size(), 5);
        a(container.serve(), "\n" +
                "20 \u000220 \u0002");
        a(container1.serve(),"\n" +
                "20 \u0002");

        container.shuffle();
        container.liquefy();
        for(Component c : container.contents) {
            a(c.getState(), Ingredient.State.Liquid);
        }
        container.clean();
        a(container.size(), 0);



        container = new Container();
        container.push(new Component(new Ingredient(2, Ingredient.State.Liquid, "chef1")));
        container.push(new Component(new Ingredient(20, Ingredient.State.Liquid, "chef1")));


        try {
            a(container.pop().getValue(), 20);
        }catch (Exception e) {
            fail();
        }
        try {
            a(container.pop().getValue(), 2);
        }catch (Exception e) {
            fail();
        }

        try {
            container.pop();
        }catch (Exception e) {
        }

        container = new Container();
        container.push(new Component(new Ingredient(2, Ingredient.State.Liquid, "chef1")));
        container.push(new Component(new Ingredient(20, Ingredient.State.Liquid, "chef1")));

        container.stir(1);
        a(container.peek().getValue(), 2);

    }

    private void cookM(String met) throws Throwable {
      try {
          HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
          Recipe recipe = new Recipe("1");
          recipe.setIngredients("1\n2 heaped g chef1 name\n3 heaped ml chef2\n4 cup chef3");

          recipe.setComments("comment");
          recipe.setMethod("method\\\\." + met);

          recipe.setCookingTime("1 2 3");
          recipe.setOvenTemp("1 2 3 4 5 6 7 8 9 gas mark");
          recipe.setServes("Serves 12");
          recipe.setIngredientValue("chef3", 4);

          Recipe recipe1 = new Recipe("2");
          recipe1.setIngredients("1\n2 heaped g chef1 name\n3 heaped ml chef2\n4 cup chef3\nnao\n5 chef3");

          recipe1.setComments("comment");
          recipe1.setMethod("method\\\\.Take a from refrigerator.");
          recipe1.setMethod("hh\\\\.Put a into the 1st mixing bowl.");

          recipe1.setCookingTime("1 2 3");
          recipe1.setOvenTemp("1 2 3 4 5 6 7 8 9 gas mark");
          recipe1.setServes("Serves 12");
          recipe1.setIngredientValue("chef3", 4);

          Recipe recipe2 = new Recipe("3");
          recipe2.setIngredients("1\n2 heaped g chef1 name\n3 heaped ml chef2\n4 cup chef3\nnao\n5 chef3");

          recipe2.setComments("comment");
          recipe2.setMethod("method\\\\.Take a from refrigerator.");
          recipe2.setMethod("hh\\\\.Put a into the 1st mixing bowl.");

          recipe2.setCookingTime("1 2 3");
          recipe2.setOvenTemp("1 2 3 4 5 6 7 8 9 gas mark");
          recipe2.setServes("Serves 12");
          recipe2.setIngredientValue("chef3", 4);

          recipes.put("1", recipe1);
          recipes.put("2", recipe2);

          Kitchen kitchen = new Kitchen(recipes, recipe);
          kitchen.cook();
      }catch (Exception e) {

      }

    }

    @Test()
    public void test5() throws Throwable {
      String[] strs = new String[] {
              "Fold a into the mixing bowl.",
              "Add dry ingredients to 1nd mixing bowl.",
              "Add dry ingredients.",
              "Add a to 1st mixing bowl.",
              "Remove a to 1st mixing bowl.",
              "Combine a to 1st mixing bowl.",
              "Divide a to 1st mixing bowl.",
              "Remove a to",
              "Liquefy contents of the 1st mixing bowl.",
              "Liquefy contents of the mixing bowl.",
              "Liquefy a.",
              "Stir the 1st mixing bowl for 1 minutes.",
              "Stir for 1 minutes.",
              "Stir a into the mixing bowl.",
              "Stir a into the 1st mixing bowl.",
              "Mix well.",
              "Mix the 1st mixing bowl well.",
              "Clean mixing bowl.",
              "Clean 1st mixing bowl.",
              "Pour contents of the mixing bowl into the baking dish.",
              "Pour contents of the 1st mixing bowl into the 1st baking dish.",
              "Set aside.",
              "Refrigerate.",
              "Refrigerate for 1 hours.",
              "Serve with a.",
              "Suggestion: .",
              "a until b.",
              "b the a."
      };
      for(int i = 0;i < strs.length; ++i) {
          p(i);
          cookM(strs[i]);
      }
    }

    @Test(timeout = 4000)
    public void test3() throws Throwable {
        HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
        Recipe recipe = new Recipe("1");
        recipe.setIngredients("1\n2 heaped g chef1 name\n3 heaped ml chef2\n4 cup chef3");

        recipe.setComments("comment");
        recipe.setMethod("method\\\\.Add dry ingredients.");
        p(recipe.getMethod(0).type);

        recipe.setCookingTime("1 2 3");
        recipe.setOvenTemp("1 2 3 4 5 6 7 8 9 gas mark");
        recipe.setServes("Serves 12");
        recipe.setIngredientValue("chef3", 4);

        Recipe recipe1 = new Recipe("2");
        recipe1.setIngredients("1\n2 heaped g chef1 name\n3 heaped ml chef2\n4 cup chef3\nnao\n5 chef3");

        recipe1.setComments("comment");
        recipe1.setMethod("method\\\\.Take a from refrigerator.");
        recipe1.setMethod("hh\\\\.Put a into the 1st mixing bowl.");

        recipe1.setCookingTime("1 2 3");
        recipe1.setOvenTemp("1 2 3 4 5 6 7 8 9 gas mark");
        recipe1.setServes("Serves 12");
        recipe1.setIngredientValue("chef3", 4);

        Recipe recipe2 = new Recipe("3");
        recipe2.setIngredients("1\n2 heaped g chef1 name\n3 heaped ml chef2\n4 cup chef3\nnao\n5 chef3");

        recipe2.setComments("comment");
        recipe2.setMethod("method\\\\.Take a from refrigerator.");
        recipe2.setMethod("hh\\\\.Put a into the 1st mixing bowl.");

        recipe2.setCookingTime("1 2 3");
        recipe2.setOvenTemp("1 2 3 4 5 6 7 8 9 gas mark");
        recipe2.setServes("Serves 12");
        recipe2.setIngredientValue("chef3", 4);

        recipes.put("1", recipe1);
        recipes.put("2", recipe2);

        Kitchen kitchen = new Kitchen(recipes, recipe);
        a(kitchen.cook().peek().getValue(), 6);
    }

    @Test(timeout = 4000)
    public void test4() throws Throwable {
      try {
          Method m = new Method("Fold a into the mixing bowl.", 1);
          m = new Method("Add dry ingredients to 1nd mixing bowl.", 1);
          m = new Method("Add dry ingredients.", 1);
          m = new Method("Add a to 1st mixing bowl.", 1);
          m = new Method("Remove a to 1st mixing bowl.", 1);
          m = new Method("Combine a to 1st mixing bowl.", 1);
          m = new Method("Divide a to 1st mixing bowl.", 1);
          m = new Method("Remove a to", 1);
          m = new Method("Liquefy contents of the 1st mixing bowl.", 1);
          m = new Method("Liquefy contents of the mixing bowl.", 1);
          m = new Method("Liquefy a.", 1);
          m = new Method("Stir the 1st mixing bowl for 1 minutes.", 1);
          m = new Method("Stir for 1 minutes.", 1);
          m = new Method("Stir a into the mixing bowl.", 1);
          m = new Method("Stir a into the 1st mixing bowl.", 1);
          m = new Method("Mix well.", 1);
          m = new Method("Mix the 1st mixing bowl well.", 1);
          m = new Method("Clean mixing bowl.", 1);
          m = new Method("Clean 1st mixing bowl.", 1);
          m = new Method("Pour contents of the mixing bowl into the baking dish.", 1);
          m = new Method("Pour contents of the 1st mixing bowl into the 1st baking dish.", 1);
          m = new Method("Set aside.", 1);
          m = new Method("Refrigerate.", 1);
          m = new Method("Refrigerate for 1 hours.", 1);
          m = new Method("Serve with a.", 1);
          m = new Method("Suggestion: .", 1);
          m = new Method("Suggestion: ..", 1);
          m = new Method("a until b.", 1);
          m = new Method("b the a.", 1);
      }catch (Exception e) {
          fail();
      }
      try {
          Method m = new Method("dfs", 1);
      }catch (Exception e) {

      }




    }


    private Field getField(Class c, String name) throws Throwable {
        Field field = c.getDeclaredField(name);
        field.setAccessible(true);
        return field;
    }

    private <T> void a(T a, T b) {
        assertEquals(a, b);
    }

    private <T> void at(T a) {
        assertTrue((Boolean) a);
    }

    private <T> void af(T a) {
        assertFalse((Boolean) a);
    }

    private <T> void p(T x) {
        System.out.println(x);
    }
}
