package net.mooctest;
	
	import static org.junit.Assert.assertEquals;
	import static org.junit.Assert.fail;
	
	import java.io.File;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.lang.reflect.InvocationTargetException;
	import java.util.HashMap;
	
	import org.junit.Rule;
	import org.junit.Test;
	import org.junit.rules.TemporaryFolder;
	
	
	public class Chef_1542441581672_KitchenTest {
	
		@Rule
		  public TemporaryFolder temporaryFolder=new TemporaryFolder();
		  
		
	  @Test()
	  public void test() throws ChefException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException{
	      Recipe mainrecipe = new Recipe("maindemo");
	      Recipe recipe = new Recipe("demo");
	      mainrecipe.setComments("recipe");
	      mainrecipe.setIngredients("recipe\ndemo");
	      mainrecipe.setCookingTime("21 23 12");
	      mainrecipe.setOvenTemp("21 gas mark 12 23");
	      mainrecipe.setServes("Serves 12");
	      assertEquals(1,mainrecipe.getServes());
	      mainrecipe.setMethod("Take a from refrigerator.Take b from refrigerator.Take a from refrigerator.Take b from refrigerator."
	      		+ "Add dry ingredients to second mixing bowl");
	      try {
	      recipe.setMethod("recipe.demo.Stir");
		  fail();
	      }catch(ChefException e) {
	    	  assertEquals(true,e.toString().contains("Unsupported method found!"));
	      }
	      Recipe recipe1 = new Recipe("demo1");
	      Recipe recipe2 = new Recipe("demo2");
	      HashMap<String, Recipe> recipes=new HashMap<String, Recipe>();
	      recipes.put("demo", recipe);recipes.put("demo1", recipe1);recipes.put("demo2", recipe2);
	      Kitchen kitchen1=new Kitchen(recipes,mainrecipe);
	      try {
	      kitchen1.cook();
		  fail();
	      }catch(ChefException e) {
	    	  assertEquals(true,e.toString().contains("Ingredient not found:"));
	      }
			Class<Kitchen> clazz = Kitchen.class;
		    java.lang.reflect.Method method = clazz.getDeclaredMethod("sameVerb", new Class[] {String.class,String.class});
			method.setAccessible(true);
			Object result = method.invoke(kitchen1, new Object[] {"demo","next"});
			assertEquals(true,method.invoke(kitchen1, new Object[] {"demo","demo"}));
			assertEquals(true,method.invoke(kitchen1, new Object[] {"demo","demon"}));
			assertEquals(true,method.invoke(kitchen1, new Object[] {"demo","demod"}));
			assertEquals(true,method.invoke(kitchen1, new Object[] {"demo","demoed"}));
			assertEquals(true,method.invoke(kitchen1, new Object[] {"demo","demooed"}));
			assertEquals(true,method.invoke(kitchen1, new Object[] {"demy","demied"}));
			assertEquals(false,method.invoke(kitchen1, new Object[] {null,"demied"}));
			assertEquals(false,method.invoke(kitchen1, new Object[] {"demy",null}));
			assertEquals(false,method.invoke(kitchen1, new Object[] {"demy","demieed"}));
		    //java.lang.reflect.Method method1 = clazz.getDeclaredMethod("server", new Class[] {Integer.class});
			//method1.invoke(kitchen1, new Object[] {2});
	  }
	  
	  @Test
	  public void testContaoner() throws ChefException {
		  Component component=new Component(2,Ingredient.State.Dry);
		  component.setValue(2);
		  component.setState(Ingredient.State.Dry);
		  assertEquals(2,component.getValue());
		  assertEquals(Ingredient.State.Dry,component.getState());
		  Component component1=component.clone();
		  component.liquefy();
		  Container container=new Container();
		  Container container2=new Container();
	
		  Container container1=new Container(container);
		  container.push(component);
	
		  assertEquals("",container.serve());
		  container.liquefy();
		  container.shuffle();
		  container.push(component1);
		  container.stir(2);
		  assertEquals(component,container.peek());
		  assertEquals(component,container.pop());
		  try {
			  container1.pop();
			  fail();
		  }catch(ChefException e) {
			  
		  }
		  assertEquals(1,container.size());
		  container2.combine(container);
		  container2.clean();
	  }
	  
	  @Test
	  public void testIngredient() throws ChefException {
		  Ingredient ingredient2=new Ingredient(3,Ingredient.State.Dry,"demo");
		  assertEquals(3,ingredient2.getAmount());
		  assertEquals(Ingredient.State.Dry,ingredient2.getstate());
		  ingredient2.setAmount(2);
		  ingredient2.setState(Ingredient.State.Dry);
		  ingredient2.liquefy();
		  ingredient2.dry();
		  Ingredient ingredient=new Ingredient("3 ml 4 teaspoon demo");
		  Ingredient ingredient1=new Ingredient("3 heaped g demo");
		  Component component=new Component(ingredient1);
	  }
	  
	  @Test
	  public void testChef() throws Exception {
		  File output=temporaryFolder.newFile("demo.txt");
		  FileOutputStream filein=new FileOutputStream(output);
		  byte[] input=new String("demo\n\nIngredients recipe\ndemo\n\n").getBytes();
		  byte[] input1=new String("Cooking time 21\n\nPre-heat oven 21 12 23\n\nMethod.Take a from refrigerator\n\n"
		  		+ "Serves 12\n\n").getBytes();
		  filein.write(input);
		  filein.write(input1);
		  byte[] input2=new String("Ingredients recipe\\ndemo\\n\\n").getBytes();
		  filein.write(input2);
		  Chef chef=new Chef(output.getPath());
		  Class<Chef> clazz = Chef.class;
		    java.lang.reflect.Method method = clazz.getDeclaredMethod("progressToExpected", new Class[] {int.class});
			method.setAccessible(true);
			assertEquals("title",method.invoke(chef, new Object[] {0}));
			assertEquals("comments",method.invoke(chef, new Object[] {1}));
			assertEquals("ingredient list",method.invoke(chef, new Object[] {2}));
			assertEquals("cooking time",method.invoke(chef, new Object[] {3}));
			assertEquals("oven temperature",method.invoke(chef, new Object[] {4}));
			assertEquals("methods",method.invoke(chef, new Object[] {5}));
			assertEquals("serve amount",method.invoke(chef, new Object[] {6}));
			assertEquals(null,method.invoke(chef, new Object[] {7}));
		    java.lang.reflect.Method method1 = clazz.getDeclaredMethod("structHint", new Class[] {int.class});
			method1.setAccessible(true);
			assertEquals(true,method1.invoke(chef, new Object[] {2}).toString().contains("did"));
			assertEquals("did you specify 'Methods.' above the methods?",method1.invoke(chef, new Object[] {3}));
			assertEquals("no hint available",method1.invoke(chef, new Object[] {1}));
		  //chef.bake();
	  }
	  
	  @Test
	  public void testChefException() throws Exception {
		  File output=temporaryFolder.newFile("demo.txt");
		  FileOutputStream filein=new FileOutputStream(output);
		  byte[] input=new String("demo\n\ndemo\n\nIngredients recipe\ndemo\n\n").getBytes();
		  byte[] input1=new String("Cooking time 21\n\nIngredients recipe\ndemo\n\nPre-heat oven 21 12 23\n\nCooking time 21\n\nMethod.Take a from refrigerator\n\n"
		  		+ "Serves 12\n\n").getBytes();
		  filein.write(input);
		  filein.write(input1);
		  byte[] input2=new String("Ingredients recipe\\ndemo\\n\\n").getBytes();
		  filein.write(input2);
		  try {
		  Chef chef=new Chef(output.getPath());
		  fail();
		  }catch(ChefException e) {
			  assertEquals(true,e.toString().contains("Read unexpected"));
		  }
		  File output1=temporaryFolder.newFile("demo1.txt");
		  FileOutputStream filein1=new FileOutputStream(output1);
		  byte[] input3=new String("demo\n\nPre-heat oven 21 12 23\n\nCooking time 21\n\n").getBytes();
		  filein1.write(input3);
		  try {
			  Chef chef=new Chef(output1.getPath());
			  fail();
			  }catch(ChefException e) {
				  assertEquals(true,e.toString().contains("Read unexpected"));
			  }
		  File output2=temporaryFolder.newFile("demo2.txt");
		  FileOutputStream filein2=new FileOutputStream(output2);
		  byte[] input4=new String("demo\n\nMethod.Take a from refrigerator\n\nPre-heat oven 21 12 23\n\n").getBytes();
		  filein2.write(input4);
		  try {
			  Chef chef=new Chef(output2.getPath());
			  fail();
			  }catch(ChefException e) {
				  assertEquals(true,e.toString().contains("Read unexpected"));
			  }
		  File output3=temporaryFolder.newFile("demo3.txt");
		  FileOutputStream filein3=new FileOutputStream(output3);
		  byte[] input5=new String("demo\n\nServes 12\n\nMethod.Take a from refrigerator\n\n").getBytes();
		  filein3.write(input5);
		  try {
			  Chef chef=new Chef(output3.getPath());
			  fail();
			  }catch(ChefException e) {
				  assertEquals(true,e.toString().contains("Read unexpected"));
			  }
		  File output4=temporaryFolder.newFile("demo4.txt");
		  try {
			  Chef chef=new Chef(output4.getPath());
			  fail();
			  }catch(ChefException e) {
				  assertEquals(true,e.toString().contains("Recipe empty or title missing!"));
			  }

		  String[] str = {"1","2","3"}; 
		  String[] str1 = {}; 

		  assertEquals("1eed2eed3",ChefException.arrayToString(str,"eed"));
		  assertEquals("",ChefException.arrayToString(str1,"eed"));
	  }
	}