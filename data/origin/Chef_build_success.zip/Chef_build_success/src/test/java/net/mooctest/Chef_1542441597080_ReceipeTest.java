package net.mooctest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.junit.Test;

public class Chef_1542441597080_ReceipeTest {

	@Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setIngredients("I");
	      // Undeclared exception!
	      try { 
	        recipe0.setIngredientValue("", 0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("net.mooctest.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setServes(":Y#|4'\"0i");
	      assertEquals(0, recipe0.getServes());
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      String string0 = recipe0.getTitle();
	      assertNull(string0);
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      Recipe recipe0 = new Recipe("0");
	      String string0 = recipe0.getTitle();
	      assertEquals("0", string0);
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setIngredients("I");
	      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
	      assertEquals(0, hashMap0.size());
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setServes("R?|6a</i");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"\"
	         //
//	         verifyException("java.lang.NumberFormatException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setOvenTemp("   i");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"i\"
	         //
//	         verifyException("java.lang.NumberFormatException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setOvenTemp((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("net.mooctest.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setOvenTemp("");
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // 3
	         //
//	         verifyException("net.mooctest.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setMethod("");
	        fail("Expecting exception: NoSuchElementException");
	      
	      } catch(NoSuchElementException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("java.util.Scanner", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setMethod((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("net.mooctest.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test11()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setIngredients("");
	        fail("Expecting exception: NoSuchElementException");
	      
	      } catch(NoSuchElementException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("java.util.Scanner", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test12()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setIngredients((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("java.io.StringReader", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test13()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setCookingTime("  ]");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"]\"
	         //
//	         verifyException("java.lang.NumberFormatException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test14()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setCookingTime((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("net.mooctest.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test15()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("Y");
	      // Undeclared exception!
	      try { 
	        recipe0.getMethod(0);
	        fail("Expecting exception: IndexOutOfBoundsException");
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 0, Size: 0
	         //
//	         verifyException("java.util.ArrayList", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test16()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("2");
	      // Undeclared exception!
	      try { 
	        recipe0.getMethod((-1));
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test17()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("!");
	      ArrayList<Method> arrayList0 = recipe0.getMethods();
	      assertEquals(0, arrayList0.size());
	  }

	  @Test(timeout = 4000)
	  public void test18()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      try { 
	        recipe0.setMethod("(.w");
	        fail("Expecting exception: ChefException");
	      
	      } catch(ChefException e) {
	         //
	         // Method error, step 1: w. (Unsupported method found!)
	         //
//	         verifyException("net.mooctest.Method", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test19()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.getMethod(0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("net.mooctest.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test20()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setCookingTime("");
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // 2
	         //
//	         verifyException("net.mooctest.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test21()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
	      assertNull(hashMap0);
	  }

	  @Test(timeout = 4000)
	  public void test22()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setServes("");
	        fail("Expecting exception: StringIndexOutOfBoundsException");
	      
	      } catch(StringIndexOutOfBoundsException e) {
	      }
	  }

	  @Test(timeout = 4000)
	  public void test23()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      int int0 = recipe0.getServes();
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void test24()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      ArrayList<Method> arrayList0 = recipe0.getMethods();
	      assertNull(arrayList0);
	  }

	  @Test(timeout = 4000)
	  public void test25()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.getIngredientValue("");
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
//	         verifyException("net.mooctest.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test26()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      String string0 = recipe0.getTitle();
	      assertEquals("", string0);
	  }

	  @Test(timeout = 4000)
	  public void test27()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setComments("");
	      assertEquals("", recipe0.getTitle());
	  }

}
