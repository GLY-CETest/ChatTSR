package net.mooctest;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.io.File;
import java.util.HashMap;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import org.junit.Test;
import net.mooctest.*;
public class Chef_1542441647551_KitchenTest {
//  Scanner scanner = new  Scanner(System.in);
  @Test(timeout = 4000)
  public void test_recipe_1() throws ChefException{  
      Recipe recipe = new Recipe("");
      Recipe recipe1 = new Recipe("aasdasd111");
     
      assertEquals("", recipe.getTitle());
      assertEquals("aasdasd111", recipe1.getTitle());
      recipe.setServes("Serve 121");	
      assertEquals(2, recipe.getServes());
      recipe.setServes("Serves 01");
      assertEquals(0, recipe.getServes());
  }
  
  @Test(timeout = 4000)
  public void test_recipe_2() throws ChefException{
      Recipe recipe = new Recipe("");
      String cookingtime = "cookingtime cookingtime 1";
      String cookingtime1 = "1 1 -3";
      
      recipe.setCookingTime(cookingtime);
      recipe.setCookingTime(cookingtime1);

	  String ingredients = "aaaaaaa\\naaaa";
	  String ingredients1 = "aaaaaaa\\n"
	      		+ "\\n暗示你打算打算";
	  
      recipe.setComments(ingredients);
      
	  recipe.setIngredients(ingredients);
      assertEquals(null, recipe.getIngredients().get(0));
      assertEquals(null, recipe.getIngredients().get(1));
	  recipe.setIngredients(ingredients1);
      assertEquals(null, recipe.getIngredients().get(0));
      assertEquals(null, recipe.getIngredients().get(1));
      
  }

  
  @Test(timeout = 4000)
  public void test_recipe_3() throws ChefException{
      Recipe recipe = new Recipe("");
      String method = "aaaaa aaaa aaa";
      recipe.setMethod(method);
      assertEquals("[]", recipe.getMethods().toString());
  }
  
  @Test(timeout = 4000)
  public void test_Component_1() throws Exception{
	  Component component = new Component(1,Ingredient.State.Dry);
	  assertEquals(1, component.getValue());
	  assertEquals(Ingredient.State.Dry, component.getState());
	  
	  Component component1 = new Component(-1,Ingredient.State.Liquid);
	  assertEquals(-1, component1.getValue());
	  assertEquals(Ingredient.State.Liquid, component1.getState());
	  component1.setValue(0);
	  component1.setState(Ingredient.State.Dry);;
	  assertEquals(0, component1.getValue());
	  assertEquals(Ingredient.State.Dry, component1.getState());
	  component1.liquefy();
	  assertEquals(Ingredient.State.Liquid, component1.getState());
  }
  
  @Test(timeout = 4000)
  public void test_Component_2() throws Exception{
	  Ingredient ingredient = new Ingredient(0,Ingredient.State.Dry,"Dry");
	  Component component = new Component(ingredient);
	  assertEquals(0, component.getValue());
	  assertEquals(Ingredient.State.Dry, component.getState());
	  
	  
	  Component component1 = component.clone();
	  assertEquals(0, component.getValue());
	  assertEquals(Ingredient.State.Dry, component.getState());
  }
  
   @Test(timeout = 4000)
  public void test_ChefE_0()  throws Throwable  {
      ChefException chefException0 = new ChefException(1, "");
      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void test_ChefE_1()  throws Throwable  {
      String[] stringArray0 = new String[2];
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, stringArray0, "");
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
   @Test(timeout = 4000)
  public void test_ChefE_2()  throws Throwable  {
      String[] stringArray0 = new String[2];
      stringArray0[0] = "";
      stringArray0[1] = "";
      ChefException chefException0 = new ChefException(0, stringArray0, "");
      assertEquals("net.mooctest.ChefException: Ingredient wrongly formatted: ' ' ()", chefException0.toString());
  }
   @Test(timeout = 4000)
  public void test_ChefE_3()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, 0, "", "");
      Object[] objectArray0 = new Object[6];
      objectArray0[0] = (Object) "";
      objectArray0[1] = (Object) chefException0;
      objectArray0[2] = (Object) "";
      objectArray0[3] = (Object) "";
      objectArray0[4] = objectArray0[2];
      objectArray0[5] = (Object) "";
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertEquals("net.mooctest.ChefException: Method error, step 1:  ()", string0);
  }
  
    @Test(timeout = 4000)
  public void test_ChefE_4()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "");
      assertEquals("Structural error: ", chefException0.getMessage());
  }
  @Test(timeout = 4000)
  public void test_Ingredient_1() throws Exception{
	  Ingredient ingredient = new Ingredient(0,Ingredient.State.Dry,"Dry");
	  ingredient.setAmount(1);
	  ingredient.liquefy();
	  ingredient.dry();
	  ingredient.setState(Ingredient.State.Liquid);
	  
	  assertEquals("Dry", ingredient.getName());
  }
  
  @Test(timeout = 4000)
  public void test_Ingredient_2() throws Exception{
	  Ingredient ingredient = new Ingredient("Dry");
	  Ingredient ingredient1 = new Ingredient("^\\\\d*$");
  }
  
    @Test(timeout = 4000)
  public void test_Ingredient_3()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("i");
      ingredient0.setAmount((-1));
      int int0 = ingredient0.getAmount();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void test_Ingredient_4()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient((String) null);
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test_Ingredient_5()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("7");
      } catch(ArrayIndexOutOfBoundsException e) {
        e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test_Ingredient_6()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("; p");
      assertEquals("; p", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void test_Ingredient_7()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("8 (");
      assertEquals("(", ingredient0.getName());
  }

  
  @Test(timeout = 4000)
  public void test_Kitchen_0()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("R");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.recipe = null;
      try { 
        kitchen0.cook();  
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test_Kitchen_1()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      recipe0.setMethod("i");
      Kitchen kitchen0 = new Kitchen((HashMap<String, Recipe>) null, recipe0);
      Container container0 = kitchen0.cook();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test_Kitchen_2()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      recipe0.setMethod("i");
      Container[] containerArray0 = new Container[9];
      Container container0 = new Container();
      containerArray0[0] = container0;
      containerArray0[1] = container0;
      containerArray0[2] = container0;
      containerArray0[3] = container0;
      containerArray0[4] = container0;
      containerArray0[5] = containerArray0[1];
      containerArray0[6] = container0;
      containerArray0[7] = containerArray0[1];
      containerArray0[8] = containerArray0[5];
      Kitchen kitchen0 = new Kitchen((HashMap<String, Recipe>) null, recipe0, containerArray0, containerArray0);
  }

  @Test(timeout = 4000)
  public void test_Kitchen_3()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      recipe0.setMethod("i");
      Container[] containerArray0 = new Container[9];
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen((HashMap<String, Recipe>) null, recipe0, containerArray0, containerArray0);
      } catch(NullPointerException e) {
     }
  }

  @Test(timeout = 4000)
  public void test_Kitchen_4()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("8");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container[] containerArray0 = new Container[0];
      kitchen0.mixingbowls = containerArray0;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }

  @Test(timeout = 4000)
  public void test_Kitchen_5()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, (Recipe) null);
      } catch(NullPointerException e) {
           e.printStackTrace();
      }
  }
	@Test
	public void type() throws Exception {
		assertThat(Kitchen.class, notNullValue());
	}
    
      @Test(timeout = 4000)
      public void test_Container_01()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      container1.contents = arrayList0;
      container0.combine(container1);
      container0.stir(1);
      assertEquals(1, container0.size());
  }
  @Test(timeout = 4000)
  public void test_Container_02()  throws Throwable  {
      Container container0 = new Container();
      container0.stir((-1));
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test_Container_03()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      container1.contents = arrayList0;
      container0.combine(container1);
      container1.combine(container0);
      String string0 = container1.serve();
      assertEquals(1, container0.size());
      assertEquals("0 0 ", string0);
  }

  @Test(timeout = 4000)
  public void test_Container_04()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test_Container_05()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      int int0 = container0.size();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void test_Container_06()  throws Throwable  {
      Container container0 = new Container();
      String string0 = container0.serve();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test_Container_07()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.pop();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void test_Container_08()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      arrayList0.add(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void test_Container_09()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertEquals(Ingredient.State.Dry, component1.getState());
  }
    @Test(timeout = 4000)
  public void test_Container_10()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      container0.push(component0);
      try { 
        container0.serve();
    
      } catch(IllegalArgumentException e) {
       
      }
  }
 @Test(timeout = 4000)
  public void test_Container_11()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      container1.contents = arrayList0;
      container0.combine(container1);
      container1.combine(container0);
      container1.stir(1);
      assertEquals(1, container0.size());
  }
  
  
  @Test(timeout = 4000)
  public void test_Method_1()  throws Throwable  {
      Method method0 = new Method("Suggestion: (", 0);
      assertEquals(0, method0.n);
  }

  @Test(timeout = 4000)
  public void test_Method_2()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method("", 0);
      } catch(Throwable e) {
          e.printStackTrace();
      }
  }

}
