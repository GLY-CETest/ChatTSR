package net.mooctest;

import java.util.HashMap;

import org.junit.Test;

public class Chef_1542440435476_KitchenTest {

  @Test(timeout = 4000)
  public void test() throws ChefException{
	  String[] ings = {"rice","dry rice","haha","sin","kin","ben","water","Dry rice"};
	  String[] methods = {"Put rice into the 1st mixing bowl.",
			  			  "Fold rice into the 1st mixing bowl.",
			  			  //"Add dry rice to 1st mixing bowl.",
			  			  //"Remove rice from 1st mixing bowl.",
			  			  "Combine rice from 1st mixing bowl.",
			  			  "Add rice into 1st mixing bowl.",
			  			  "Divide rice from 1st mixing bowl.",
			  			  "Liquefy contents of the 1st mixing bowl.",
			  			  "Liquefy rice.",
			  			  "Stir the 122nd mixing bowl for 1234 minutes.",
			  			  "Stir rice into the 1st mixing bowl.",
			  			  "Mix the 233rd mixing bowl well.",
			  			  "Clean 1st mixing bowl.",
			  			  "Pour contents of the 1st mixing bowl into the 2nd baking dish.",
			  			  //"Set aside.",
			  			  "Refrigerate for 3 hours.",
			  			  "Serve with sinkinben.",
			  			  "Suggestion: hahaha.",
			  			  "eat the rice until tonight.",
			  			  "dir the rice.",
			  			 };
	  
	  String ing = "Ingredients.\n";
	  String method = "Methods.";
	  for(int i=0;i<ings.length;i++)
		  ing=ing+ings[i]+"\n";
	  for(int i=0;i<methods.length;i++)
		  method=method+methods[i];
	  
      Recipe recipe = new Recipe("recipe");
      recipe.setComments("this is sinkinben's recipe");
      recipe.setIngredients(ing);
      recipe.setCookingTime("0 1 2");
      recipe.setOvenTemp("gasmark 2 3 4 5 6 7 8");
      recipe.setIngredientValue("rice", 123);
      recipe.setMethod(method);
      recipe.setServes("Serves 9527");
      recipe.getClass();
      recipe.getIngredients();
      recipe.getIngredientValue("rice");
      recipe.getMethod(3);
      recipe.getMethods();
      recipe.getServes();
      recipe.getTitle();
      
      //test ingredient
      Ingredient ingre1 = new Ingredient("233 level kg dry rice");
      Ingredient ingre2 = new Ingredient("233 ml water");
      Ingredient ingre3 = new Ingredient("233 cups dry rice");
      Ingredient ingre4 = new Ingredient("233 dry rice");
      Ingredient ingre5 = new Ingredient(new Integer(233),Ingredient.State.Dry, "ing name");
      ingre5.getAmount();
      ingre5.getName();
      ingre5.getstate();
      ingre5.liquefy();
      ingre5.dry();
      ingre5.setState(Ingredient.State.Liquid);
      
      //test component and container
      Component com1 = new Component(5,Ingredient.State.Dry);
      Component com2 = new Component(5,Ingredient.State.Liquid);
      Container[] dishes = new Container[5];
      Container[] bowls  = new Container[5];
      for(int i=0;i<5;i++) {
    	  dishes[i] = new Container();
    	  dishes[i].push(com1);
    	  dishes[i].push(com2);
    	  dishes[i].push(com2);
    	  bowls[i] = new Container();
    	  bowls[i].push(com1);
    	  bowls[i].push(com2);
    	  bowls[i].push(com2);
      }
      
      
      //test kitchen
      HashMap<String,Recipe> h = new HashMap<String,Recipe>();
      h.put("sin recipe", recipe);
      Kitchen kit1 = new Kitchen(h,recipe);
      Kitchen kit2 = new Kitchen(h,recipe,dishes,bowls);
      kit2.cook();
      
      
  }
  
  
}
