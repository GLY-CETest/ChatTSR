package net.mooctest;

import static org.junit.Assert.*;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;

import org.junit.Test;

public class Chef_1542440639807_KitchenTest {
	


  @Test(timeout = 4000)
  public void test() throws ChefException{
      Recipe recipe = new Recipe("test");
      recipe.setIngredients("DRY");
      recipe.setCookingTime("1 2 3");
      recipe.setMethod("Method.");
      assertEquals(recipe.getTitle(),"test");
      recipe.setServes("Serves 111");

      assertEquals(Integer.parseInt("Serves 111".substring(("Serves ").length(), "Serves 111".length()-1)),11);
      recipe.setOvenTemp("1 2 3 4");
      assertEquals(recipe.getMethods().size(),0);
      
      recipe.setMethod("Method.Take a from refrigerator.Put b into mixing bowl.Add dry ingredients to 2rd mixing bowl."
	  		+ "Liquefy contents of the 3th mixing bowl.");
     
      assertEquals(recipe.getMethods().size(),4);
      
     
  }
  
  @Test 
  public void testChef() throws Exception{
	  
	  File file = new File("./test.txt");
	  file.createNewFile();
	  BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
	  bos.write(("GOODFOOD\n\n"
	        +"VERY NICE \n\n"
            +"Ingredients\n35 heaped kg meat\n\n"
	  		+ "Cooking time 1234\n\n"
	  		+ "Pre-heat oven tt 1234\n\n"
	  		+ "Method.Take a from refrigerator.Put b into mixing bowl.Add dry ingredients to 2rd mixing bowl."
	  		+ "Liquefy contents of the 3th mixing bowl."
	  		+ "Stir the 4st mixing bowl for 50 minutes."
	  		+ "Liquefy BB."
	  		+ "Stir the 3th mixing bowl for 12 minutes."
	  		+ "Stir a into the 3th mixing bowl."
	  		+ "Mix the 3th mixing bowl well."
	  		+ "Clean 2th mixing bowl."
	  		+ "Pour contents of the 1th mixing bowl into the 2th baking dish."
	  		+ "Set aside."
	  		+ "Refrigerate for 2 hours."
	  		+ "Suggestion: GOOOD MORNING."
	  		+ "abc the edg until hij."
	  		+ "abc the edg.\n\n"
	  		+ "Serves 123\n\n").getBytes());
	  bos.close();
	  
	  Chef chef = new Chef("./test.txt");
	  
	  try{
		  java.lang.reflect.Method m = Chef.class.getDeclaredMethod("progressToExpected", int.class);
		  m.setAccessible(true);
		  assertEquals(m.invoke(chef, 0),"title");
		  assertEquals(m.invoke(chef, 1),"comments");
		  assertEquals(m.invoke(chef, 2),"ingredient list");
		  assertEquals(m.invoke(chef, 3),"cooking time");
		  assertEquals(m.invoke(chef, 4),"oven temperature");
		  assertEquals(m.invoke(chef, 5),"methods");
		  assertEquals(m.invoke(chef, 6),"serve amount");
		  assertNull(m.invoke(chef, -1));
		  assertNull(m.invoke(chef, 7));
		  
		  java.lang.reflect.Method  mm = Chef.class.getDeclaredMethod("structHint", int.class);
		  mm.setAccessible(true);
		  assertEquals(mm.invoke(chef, 2),"did you specify 'Ingredients.' above the ingredient list?");
		  assertEquals(mm.invoke(chef,3),"did you specify 'Methods.' above the methods?");
		  assertNotNull(mm.invoke(chef, 9));
		  assertEquals("no hint available",mm.invoke(chef, 9));
		  
	  }catch(Exception e){
		  fail();
	  }

	  
	  try{
		  chef.bake();
		  fail();
	  }catch(Exception e){
		  
	  }
	
  }

  @Test
  public void reflect() {
	new ChefException(1,"GG");
	new ChefException(55,"GTT");
	new ChefException(1,2, "GG", "EE");
	new ChefException(24, new String[]{"a","B"}, "TTT");
	new Ingredient(123,Ingredient.State.Dry,"SAFSFASDSA");
	try {
		Ingredient in = new Ingredient("35 heaped kg meat");
		assertEquals(in.getstate(),Ingredient.State.Dry);
		in.liquefy();
		assertEquals(in.getstate(),Ingredient.State.Liquid);
		in.dry();
		assertEquals(in.getstate(),Ingredient.State.Dry);
		in.setState(Ingredient.State.Liquid);
		assertEquals(in.getstate(),Ingredient.State.Liquid);
		in.setAmount(123123);
		assertEquals(in.getAmount(),123123);
		new Component(in);
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		fail("GG");
	}
	Component a = new Component(1,Ingredient.State.Dry);
	Component b = new Component(1123,Ingredient.State.Liquid);
	assertEquals(a.getState(),Ingredient.State.Dry);
	assertEquals(b.getState(),Ingredient.State.Liquid);
	assertEquals(a.getValue(),1);
	assertEquals(b.getValue(),1123);
	b.setValue(12344444);
	assertEquals(b.getValue(),12344444);
	b.setState(Ingredient.State.Dry);
	assertEquals(b.getState(),Ingredient.State.Dry);
	a.liquefy();
	assertEquals(a.getState(),Ingredient.State.Liquid);
	
	Component aa = a.clone();
	assertEquals(aa.getState(),a.getState());
	assertEquals(aa.getValue(),a.getValue());
  }
  
  @Test(timeout = 4000)
  public void test0()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("2");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container[] containerArray0 = new Container[8];
      Container container0 = kitchen0.cook();
      containerArray0[0] = container0;
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      containerArray0[0].push(component0);
      Container container1 = kitchen0.cook();
      assertEquals(1, container1.size());
  }



}
