package net.mooctest;



import static org.junit.Assert.assertEquals;
//import static org.evosuite.runtime.EvoAssertions.//;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.junit.Test;


public class Chef_1542441010073_KitchenTest {
	String fp = "src/main/resources/demo.txt";
	@Test(timeout = 4000)
	  public void test_8()  throws Throwable  {
	      Recipe recipe0 = new Recipe("hhh");
	      recipe0.setMethod("Pour contents of the mixing bowl into the baking dish.");
	      recipe0.setMethod("Put b into 15th mixing bowl.");
	      recipe0.setMethod("Add dry ingredients to 1st mixing bowl.");
	      recipe0.setMethod("Take a from refrigerator.");
	      recipe0.setMethod("Pour contents of the mixing bowl into the baking dish.");
	      Container[] containerArray0 = new Container[1];
	      Container container0 = new Container();
	      containerArray0[0] = container0;
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
	      Container container1 = kitchen0.cook();
	      assertFalse(container1.equals((Object)container0));
//	      String data = "abcde";
//	      InputStream inputStream = new ByteArrayInputStream(data.getBytes("UTF-8"));
//	      System.setIn(inputStream);
	      
	  }
	@Test(timeout = 4000)
	  public void test_6() throws ChefException{
	      Recipe recipe = new Recipe("");
	      Ingredient in  = new Ingredient("15 heaped 15kg");
	      Ingredient i1  = new Ingredient("15 15kges");
	      Ingredient i2  = new Ingredient("15 hhhkg");
	      i1.liquefy();
	      i1.setAmount(2);
	      i1.dry();
	      i1.setState(Ingredient.State.Dry);
	  }
	@Test(timeout = 4000)
	  public void test_5() throws ChefException{
	      Recipe recipe = new Recipe("");
	      Method method = new Method("Pour contents of the mixing bowl into the baking dish.",1);
	      Method m1 = new Method("Pour contents of the 14th mixing bowl into the 15th baking dish.",1);
	      Method m2 = new Method("Take abc from refrigerator.",1);
	      //(Put|Fold) ([a-zA-Z ]+) into( the)?( (\\d+)(nd|rd|th|st))? mixing bowl.
	      Method m3 = new Method("Put ab into the 14th mixing bowl.",1);
	      //Add dry ingredients( to( (\\d+)(nd|rd|th|st))? mixing bowl)?.
	      Method m4 = new Method("Add dry ingredients to 14th mixing bowl.",1);
	      Method m5 = new Method("Add dry ingredients to mixing bowl.",1);
	      //(Add|Remove|Combine|Divide) ([a-zA-Z ]+)( (to|into|from)( (\\d+)(nd|rd|th|st))? mixing bowl)?.
	      Method m6 = new Method("Add ab to 14th mixing bowl.",1);
	      Method m7 = new Method("Remove ab to 14th mixing bowl.",1);
	      Method m8 = new Method("Combine ab to 14th mixing bowl.",1);
	      Method m9 = new Method("Divide ab to 14th mixing bowl.",1);
	      Method m10 = new Method("Divide ab mixing bowl.",1);
	      //Liquefy contents of the( (\\d+)(nd|rd|th|st))? mixing bowl.
	      Method m11 = new Method("Liquefy contents of the 14th mixing bowl.",1);
	      Method m12 = new Method("Liquefy contents of the mixing bowl.",1);
	      //Liquefy ([a-zA-Z ]+).
	      Method m13 = new Method("Liquefy ab.",1);
	      //Stir( the( (\\d+)(nd|rd|th|st))? mixing bowl)? for (\\d+) minutes.
	      Method m14 = new Method("Stir the 14th mixing bowl for 14 minutes.",1);
	      Method m15 = new Method("Stir the mixing bowl for 14 minutes.",1);
	      //Stir ([a-zA-Z ]+) into the( (\\d+)(nd|rd|th|st))? mixing bowl.
	      Method m16 = new Method("Stir ab into the 14th mixing bowl.",1);
	      Method m17 = new Method("Stir ab into the mixing bowl.",1);
	      //Mix( the( (\\d+)(nd|rd|th|st))? mixing bowl)? well.
	      Method m18 = new Method("Mix the 14th mixing bowl well.",1);
	      Method m19 = new Method("Mix the mixing bowl well.",1);
	      //Clean( (\\d+)(nd|rd|th|st))? mixing bowl.
	      Method m20 = new Method("Clean 14th mixing bowl.",1);
	      Method m21 = new Method("Clean mixing bowl.",1);
	      Method m22 = new Method("Set aside.",1);
	      //Refrigerate( for (\\d+) hours)?.
	      Method m23 = new Method("Refrigerate for 14 hours.",1);
	      Method m24 = new Method("Refrigerate.",1);
	      //Serve with ([a-zA-Z ]+).
	      Method m25 = new Method("Serve with ab.",1);
	      //Suggestion: (.*).
	      Method m26 = new Method("Suggestion: (hh).",1);
	      //([a-zA-Z]+)( the ([a-zA-Z ]+))? until ([a-zA-Z]+).
	      Method m27 = new Method("ab the ab until ab.",1);
	      Method m28 = new Method("ab the ab.",1);
	  }
	@Test(timeout = 4000)
	  public void test_7() throws ChefException{
	      Recipe recipe = new Recipe("");
	      
	  }
  @Test(timeout = 4000)
  public void test() throws ChefException{
      Recipe recipe = new Recipe("");
      recipe.setComments("");
      recipe.setIngredients("String\nString");
      recipe.setMethod("Take a b from refrigerator.\nPut b into mixing bowl.\nFold b into mixing bowl.");
      recipe.setMethod("Put b into 15th mixing bowl.");
      recipe.setMethod("Add dry ingredients to 1st mixing bowl.");
      recipe.setMethod("Take a from refrigerator.");
      recipe.setMethod("Pour contents of the mixing bowl into the baking dish.");
      recipe.setCookingTime("2018 9 10");
      recipe.setOvenTemp("18 9 10 3 1 2 3 4 5 6");
//      recipe.getIngredientValue("");
//      recipe.setServes("Serves hh");
  }
  
  @Test(timeout = 4000)
  public void test_2() throws Exception{
	  try{
		  File file = new File(fp);
			FileWriter w = new FileWriter(file);
			w.write("\nIngredients\n\nIngredients\n\nCooking time");
			w.close();
		}catch(Exception e){
			  System.out.println(e.getMessage());
		  }
	  try{
		  Chef chef = new Chef(fp);
	  }catch(Exception e){
		  System.out.println(e.getMessage());
	  }
	 
  }
  @Test(timeout = 4000)
  public void test_3() throws Exception{
	  try{
		  File file = new File(fp);
			FileWriter w = new FileWriter(file);
			w.write("\n\nCooking time\nCooking time.");
			w.close();
		}catch(Exception e){
			  System.out.println(e.getMessage());
		  }
	  try{
		  Chef chef = new Chef(fp);
	  }catch(Exception e){
		  System.out.println(e.getMessage());
	  }
	 
  }
  @Test(timeout = 4000)
  public void test_4() throws Exception{
	 
  }
  
  @Test(timeout = 4000)
  public void test_1() throws ChefException{
      Recipe recipe = new Recipe("");
      Ingredient in = new Ingredient(15 ,Ingredient.State.Dry,"pota");
      Ingredient in2 = new Ingredient("15 heaped hh");
      
  }
  
  @Test(timeout = 4000)
  public void test0()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("d");
      recipe0.setMethod("Put b into 15th mixing bowl.");
      recipe0.setMethod("Add dry ingredients to 1st mixing bowl.");
      recipe0.setMethod("Take a from refrigerator.");
      recipe0.setMethod("Pour contents of the mixing bowl into the baking dish.");
      Container[] containerArray0 = new Container[1];
      Container container0 = new Container();
      containerArray0[0] = container0;
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      Container container1 = kitchen0.cook();
      assertFalse(container1.equals((Object)container0));
      String data = "abcde";
      InputStream inputStream = new ByteArrayInputStream(data.getBytes("UTF-8"));
      System.setIn(inputStream);
      
  }

  @Test(timeout = 4000)
  public void test1()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("5");
      Container[] containerArray0 = new Container[0];
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.mixingbowls = containerArray0;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }

  @Test(timeout = 4000)
  public void test2()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod(" ");
      Container[] containerArray0 = new Container[1];
      Container container0 = new Container();
      containerArray0[0] = container0;
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      Container container1 = kitchen0.cook();
      assertFalse(container1.equals((Object)container0));
  }

  @Test(timeout = 4000)
  public void test3()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod(" ");
      Container[] containerArray0 = new Container[1];
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test4()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("U");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.mixingbowls = null;
      // Undeclared exception!
      try { 
        kitchen0.cook();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Kitchen", e);
      }
  }

  @Test(timeout = 4000)
  public void test5()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Kitchen", e);
      }
  }
  
  @Test(timeout = 4000)
  public void test00()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("t");
      // Undeclared exception!
      try { 
        recipe0.setIngredientValue("", 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void test01()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setServes("}}:d6Ja6t");
      assertEquals("", recipe0.getTitle());
  }

  @Test(timeout = 4000)
  public void test02()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      String string0 = recipe0.getTitle();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void test03()  throws Throwable  {
      Recipe recipe0 = new Recipe("E");
      String string0 = recipe0.getTitle();
      assertEquals("E", string0);
  }



  @Test(timeout = 4000)
  public void test05()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes("");
        fail("Expecting exception: StringIndexOutOfBoundsException");
      
      } catch(StringIndexOutOfBoundsException e) {
      }
  }

  @Test(timeout = 4000)
  public void test06()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes("bWw1rCNf");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"\"
         //
         //("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void test07()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("   t");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"t\"
         //
         //("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void test08()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void test09()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 3
         //
         //("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void test10()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setMethod("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("java.util.Scanner", e);
      }
  }

  @Test(timeout = 4000)
  public void test11()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setMethod((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void test12()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setIngredients("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("java.util.Scanner", e);
      }
  }

  @Test(timeout = 4000)
  public void test13()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setIngredients((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("java.io.StringReader", e);
      }
  }

  @Test(timeout = 4000)
  public void test14()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("  m");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"m\"
         //
         //("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void test15()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setCookingTime((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void test16()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("L");
      // Undeclared exception!
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: IndexOutOfBoundsException");
      
      } catch(IndexOutOfBoundsException e) {
         //
         // Index: 0, Size: 0
         //
         //("java.util.ArrayList", e);
      }
  }

  @Test(timeout = 4000)
  public void test17()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("S");
      // Undeclared exception!
      try { 
        recipe0.getMethod((-1));
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test18()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setMethod("A.:");
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         //
         // Method error, step 1: :. (Unsupported method found!)
         //
         //("net.mooctest.Method", e);
      }
  }

  @Test(timeout = 4000)
  public void test19()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("N");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertEquals(0, hashMap0.size());
  }

  @Test(timeout = 4000)
  public void test20()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void test21()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 2
         //
         //("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void test22()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertNull(hashMap0);
  }

  @Test(timeout = 4000)
  public void test23()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setServes((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void test24()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      int int0 = recipe0.getServes();
      assertEquals(0, int0);
  }


  @Test(timeout = 4000)
  public void test26()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getIngredientValue("");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void test27()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      String string0 = recipe0.getTitle();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test28()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setComments("");
      assertEquals(0, recipe0.getServes());
  }
  
  @Test(timeout = 4000)
  public void test100()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>(0);
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      container0.contents = arrayList0;
      arrayList0.addAll((Collection<? extends Component>) container0.contents);
      container0.stir(1);
      assertEquals(4, container0.size());
  }

  @Test(timeout = 4000)
  public void test101()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>(0);
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      container0.contents = arrayList0;
      arrayList0.add(component0);
      container0.stir(2);
      assertEquals(3, container0.size());
  }

  @Test(timeout = 4000)
  public void test102()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      ArrayList<Component> arrayList0 = new ArrayList<Component>(0);
      container1.contents = arrayList0;
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      container1.stir(1);
      assertNotSame(container0, container1);
  }

  @Test(timeout = 4000)
  public void test103()  throws Throwable  {
      Container container0 = new Container();
      container0.stir((-1));
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test104()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>(0);
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      container0.contents = arrayList0;
      String string0 = container0.serve();
      assertEquals("\u0000\u0000", string0);
  }

  @Test(timeout = 4000)
  public void test105()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      ArrayList<Component> arrayList0 = new ArrayList<Component>(0);
      container1.contents = arrayList0;
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      Component component1 = container1.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void test106()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      int int0 = container0.size();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void test107()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.pop();
      String string0 = container0.serve();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test108()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.pop();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void test109()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertEquals(Ingredient.State.Dry, component1.getState());
  }

  @Test(timeout = 4000)
  public void test110()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      ArrayList<Component> arrayList0 = new ArrayList<Component>(0);
      container1.contents = arrayList0;
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      Component component1 = container1.pop();
      assertEquals(Ingredient.State.Liquid, component1.getState());
  }

  @Test(timeout = 4000)
  public void test111()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.peek();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void test112()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertEquals(Ingredient.State.Liquid, component1.getState());
  }

  @Test(timeout = 4000)
  public void test113()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertEquals(1, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test114()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      ArrayList<Component> arrayList0 = new ArrayList<Component>(0);
      container1.contents = arrayList0;
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      Component component1 = container1.peek();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void test115()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      container0.contents = arrayList0;
      container0.contents = arrayList0;
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.size();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test116()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test117()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>(0);
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      container0.contents = arrayList0;
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("java.lang.Character", e);
      }
  }

  @Test(timeout = 4000)
  public void test118()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      // Undeclared exception!
      try { 
        container0.push(component0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test119()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.pop();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test120()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.peek();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test121()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.combine((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test122()  throws Throwable  {
      Container container0 = null;
      try {
        container0 = new Container((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test123()  throws Throwable  {
      Container container0 = new Container();
      container0.stir(1);
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test124()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      String string0 = container0.serve();
      assertEquals("0 ", string0);
  }

  @Test(timeout = 4000)
  public void test125()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = Integer.valueOf(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      container0.liquefy();
      assertEquals(1, container0.size());
  }

  @Test(timeout = 4000)
  public void test126()  throws Throwable  {
      Container container0 = new Container();
      try { 
        container0.pop();
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         //
         // Local error: Folded from empty container
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test127()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.peek();
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test128()  throws Throwable  {
      Container container0 = new Container();
      int int0 = container0.size();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test129()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      // Undeclared exception!
      try { 
        container1.shuffle();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("java.util.Collections", e);
      }
  }

  @Test(timeout = 4000)
  public void test130()  throws Throwable  {
      Container container0 = new Container();
      container0.clean();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test131()  throws Throwable  {
      Container container0 = new Container();
      container0.shuffle();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test132()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      // Undeclared exception!
      try { 
        container0.liquefy();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void test133()  throws Throwable  {
      Container container0 = new Container();
      container0.combine(container0);
      assertEquals(0, container0.size());
  }
  @Test(timeout = 4000)
  public void test200()  throws Throwable  {
      Integer integer0 = new Integer(1);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      int int0 = component0.getValue();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void test201()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      int int0 = component0.getValue();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void test202()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      component0.setState((Ingredient.State) null);
      component0.getState();
  }

  @Test(timeout = 4000)
  public void test203()  throws Throwable  {
      Integer integer0 = new Integer(1);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      Component component1 = component0.clone();
      assertEquals(1, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test04()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      Component component1 = component0.clone();
      assertEquals((-1), component1.getValue());
      assertEquals((-1), component0.getValue());
  }

  @Test(timeout = 4000)
  public void test205()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("O");
      Component component0 = null;
      try {
        component0 = new Component(ingredient0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.mooctest.Ingredient", e);
      }
  }

  @Test(timeout = 4000)
  public void test206()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      int int0 = component0.getValue();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test207()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      component0.liquefy();
      assertEquals(Ingredient.State.Liquid, component0.getState());
  }

  @Test(timeout = 4000)
  public void test208()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      Component component1 = component0.clone();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test209()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      component0.setValue(0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void test210()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      Ingredient.State ingredient_State1 = component0.getState();
      assertEquals(Ingredient.State.Liquid, ingredient_State1);
  }
  
}
