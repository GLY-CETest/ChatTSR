package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Chef_1542441597080_MethodTest {
	
	@Test
	public void test() {
		String line = "";
		int n=10;
		try {
			Method method = new Method(line,n);
			
		} catch (ChefException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}
	
	@Test
	public void test02() {
		String line = "Take abcd from refrigerator.";
		int n=10;
		try {
			Method method = new Method(line,n);
			assertEquals(method.ingredient,"abcd");
			assertEquals(method.type,Method.Type.Take);
			assertEquals(method.n,n);
		} catch (ChefException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}
	@Test
	public void test03() {
		String line = "Put abcd into 34st mixing bowl.";
		int n=10;
		try {
			Method method = new Method(line,n);
			assertEquals(method.ingredient,"abcd");
			assertEquals(method.type,Method.Type.Put);
			assertEquals(method.mixingbowl.intValue(),33);
		} catch (ChefException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}
	
	@Test
	public void test04() {
		String line = "Fold abcd into the mixing bowl.";
		int n=10;
		try {
			Method method = new Method(line,n);
			assertEquals(method.ingredient,"abcd");
			assertEquals(method.type,Method.Type.Fold);
			assertEquals(method.mixingbowl.intValue(),0);
		} catch (ChefException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}
	
	@Test
	public void test05() {
		String line = "Add dry ingredients 2st mixing bowl)?.";
		int n=10;
		try {
			Method method = new Method(line,n);
			assertEquals(method.type,Method.Type.AddDry);
			assertEquals(method.mixingbowl.intValue(),1);
			
			line = "Add abcd to 12st mixing bowl.";
			assertEquals(method.ingredient,"abcd");
			assertEquals(method.type,Method.Type.Add);
			assertEquals(method.mixingbowl.intValue(),11);
			
			line ="Liquefy contents of the 23nd mixing bowl.";
			assertEquals(method.type,Method.Type.LiquefyBowl);
			assertEquals(method.mixingbowl.intValue(),22);
			
			line = "Liquefy afa.";
			assertEquals(method.type,Method.Type.Liquefy);
			assertEquals(method.ingredient,"afa");
			
			line = "Stir the 23nd mixing bowl for 23 minutes.";
			assertEquals(method.time.intValue(),22);
			assertEquals(method.mixingbowl.intValue(),22);
			assertEquals(method.type,Method.Type.Stir);
			
            line = "Set aside.";
			assertEquals(method.type,Method.Type.SetAside);

			
		} catch (ChefException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}

}
