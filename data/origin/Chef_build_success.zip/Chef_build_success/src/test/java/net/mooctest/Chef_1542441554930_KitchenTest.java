package net.mooctest;

import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;

public class Chef_1542441554930_KitchenTest {

    @Test(timeout = 4000)
    public void test(){
        Recipe recipe = new Recipe("");
        try {
            recipe.setIngredients("0 heaped g\n0 heaped g");
            Assert.fail();
        } catch (Exception e){
            Assert.assertEquals(ChefException.class, e.getClass());
            Assert.assertTrue(e.getMessage().equals("Ingredient wrongly formatted: '0 heaped g' (ingredient name missing)"));
        }
    }

    @Test(timeout = 4000)
    public void test1(){
        Recipe recipe = new Recipe("");
        try {
            recipe.setIngredients("header\n1 heaped g abc");
            Assert.assertEquals(1 , recipe.getIngredients().size());
            Assert.assertTrue(recipe.getIngredients().keySet().contains("abc"));
            Assert.assertEquals(1, recipe.getIngredientValue("abc"));
            Assert.assertEquals(Ingredient.State.Dry, recipe.getIngredients().get("abc").getstate());
        } catch (Exception e){

        }
    }

    @Test(timeout = 4000)
    public void test2(){
        Recipe recipe = new Recipe("");
        try {
            recipe.setIngredients("header\n1 level l aaa");
            Assert.assertEquals(1 , recipe.getIngredients().size());
            Assert.assertTrue(recipe.getIngredients().keySet().contains("aaa"));
            Assert.assertEquals(1, recipe.getIngredientValue("aaa"));
            Assert.assertEquals(Ingredient.State.Liquid, recipe.getIngredients().get("aaa").getstate());

            recipe.setIngredients("header\n2 level tablespoons aaa");
            Assert.assertEquals(1 , recipe.getIngredients().size());
            Assert.assertTrue(recipe.getIngredients().keySet().contains("aaa"));
            Assert.assertEquals(2, recipe.getIngredientValue("aaa"));
            Assert.assertEquals(Ingredient.State.Dry, recipe.getIngredients().get("aaa").getstate());
        } catch (Exception e){

        }
    }

    @Test
    public void test3(){
        Recipe recipe = new Recipe("");
        try {
            recipe.setMethod("header\\.asdasdad.");
            Assert.fail();
        } catch (Exception e){
            Assert.assertEquals(ChefException.class, e.getClass());
            Assert.assertTrue(e.getMessage().equals("Method error, step 1: asdasdad. (Unsupported method found!)"));
        }
    }

    @Test
    public void test4(){
        Recipe recipe = new Recipe("");
        try {
            recipe.setMethod("header\\.Take a \nfrom refrigerator.");
            Assert.assertEquals(1, recipe.getMethods().size());
            Assert.assertEquals(Method.Type.Take, recipe.getMethod(0).type);
            Assert.assertTrue(recipe.getMethod(0).ingredient.equals("a"));
        } catch (Exception e){

        }
    }

    @Test
    public void test5(){
        Recipe recipe = new Recipe("");
        try {
            String method = "header\\.Put b into mixing bowl." +
                    "Fold c into mixing bowl.Add dry ingredients." +
                    "Add d.Remove e.Combine f.Divide g." +
                    "Liquefy contents of the mixing bowl." +
                    "Liquefy h." +
                    "Stir for 1 minutes." +
                    "Stir i into the mixing bowl." +
                    "Mix well." +
                    "Clean mixing bowl." +
                    "Pour contents of the mixing bowl into the baking dish." +
                    "Set aside." +
                    "Refrigerate." +
                    "Serve with j." +
                    "k until l." +
                    "m the n.";
            recipe.setMethod(method);
            Assert.assertEquals(19, recipe.getMethods().size());

            Assert.assertEquals(Method.Type.Put, recipe.getMethod(0).type);
            Assert.assertTrue(recipe.getMethod(0).ingredient.equals("b"));
            Assert.assertEquals(0, recipe.getMethod(0).mixingbowl.intValue());

            Assert.assertEquals(Method.Type.Fold, recipe.getMethod(1).type);
            Assert.assertTrue(recipe.getMethod(1).ingredient.equals("c"));
            Assert.assertEquals(0, recipe.getMethod(1).mixingbowl.intValue());

            Assert.assertEquals(Method.Type.AddDry, recipe.getMethod(2).type);
            Assert.assertEquals(0, recipe.getMethod(2).mixingbowl.intValue());

            Assert.assertEquals(Method.Type.Add, recipe.getMethod(3).type);
            Assert.assertTrue(recipe.getMethod(3).ingredient.equals("d"));

            Assert.assertEquals(Method.Type.Remove, recipe.getMethod(4).type);
            Assert.assertTrue(recipe.getMethod(4).ingredient.equals("e"));

            Assert.assertEquals(Method.Type.Combine, recipe.getMethod(5).type);
            Assert.assertTrue(recipe.getMethod(5).ingredient.equals("f"));

            Assert.assertEquals(Method.Type.Divide, recipe.getMethod(6).type);
            Assert.assertTrue(recipe.getMethod(6).ingredient.equals("g"));
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void test6(){
        Recipe recipe = new Recipe("");
        try {
            recipe.setOvenTemp("0 1 2 3 gas mark 6 7 8a");
            recipe.setOvenTemp("0 1 2 3 6 7 8a");
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void test7(){
        Recipe recipe = new Recipe("");
        try {
            recipe.setMethod("header\\.Take a \nfrom refrigerator.");
            HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
            recipes.put("recipe",recipe);
            Kitchen kitchen = new Kitchen(recipes, recipe);
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void test8(){
        try {
            Chef chef = new Chef("demo.txt");
            Assert.fail();
        } catch (Exception e){
            Assert.assertEquals(ChefException.class, e.getClass());
            Assert.assertTrue(e.getMessage().equals("Structural error: Recipe empty or title missing!"));
        }
    }

    @Test
    public void test9(){
        try {
            Chef chef = new Chef("demo1.txt");

        } catch (Exception e){

        }
    }
}
