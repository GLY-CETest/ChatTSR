package net.mooctest;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.List;

import org.junit.Test;

public class Chef_1542441093580_KitchenTest {

	@Test(timeout = 4000)
	public void test() throws ChefException {
		Recipe recipe = new Recipe("test Title");
		recipe.setIngredients(
				"\n1222 pinch oven\n123 ml this is a name\n12321 cup oven\n2333 heaped cup cupcake\n1222 pinch pork\n123 abc beef\n300 everything");
		String title = recipe.getTitle();
		assertEquals("test Title", title);
		String comment = "Nice";
		recipe.setComments(comment);
		String cookingtime = "00 00 02";
		recipe.setCookingTime(cookingtime);
		HashMap<String, Ingredient> ingre = recipe.getIngredients();
		int iv = recipe.getIngredientValue("this is a name");
		assertEquals(123, iv);
		recipe.setIngredientValue("oven", 2333);
		iv = recipe.getIngredientValue("oven");
		assertEquals(2333, iv);
		String method = "method\\\\.heat the oven. Stop until five. Set aside. Put meat into the 2nd mixing bowl. Liquefy contents of the 2nd mixing bowl.";
		recipe.setMethod(method);
		List<Method> me = recipe.getMethods();
		assertEquals(5, me.size());
		Recipe recipe2 = new Recipe("no2");
		method = "method\\\\.Stir the 1st mixing bowl for 4 minutes. Take everything from refrigerator. Pour contents of the 2nd mixing bowl into the 1st baking dish. Add dry ingredients to 1st mixing bowl. Liquefy contents of the mixing bowl. Mix well.";
		recipe2.setMethod(method);
		method = "method\\\\.Stir pork into the 2nd mixing bowl. Stir for 5 minutes. Clean mixing bowl. Take everything from refrigerator. Add dry ingredients. Add pork to 3rd mixing bowl. Add beef to mixing bowl. Liquefy chicken. Mix the 2nd mixing bowl well.";
		Recipe recipe3 = new Recipe("no3");
		recipe3.setMethod(method);
		method = "method\\\\.Refrigerate for 4 hours. Serve with chips. Stir pork into the 2nd mixing bowl. Stir for 5 minutes. Clean 2nd mixing bowl. Pour contents of the mixing bowl into the baking dish. Suggestion: put everything together.";
		Recipe recipe4 = new Recipe("no4");
		recipe4.setMethod(method);
		method = "method\\\\.";
		Recipe recipe5 = new Recipe("no5");
		recipe5.setMethod(method);
		
		HashMap<String, Recipe> rec = new HashMap<String, Recipe>();

		rec.put("no5", recipe5);
		
		HashMap<String, Recipe> re2 = new HashMap<String, Recipe>();

		rec.put("no1", recipe);
		rec.put("no2", recipe2);
		rec.put("no3", recipe3);
		Kitchen kit = new Kitchen(rec, recipe5);
		Kitchen kit2 = new Kitchen(re2, recipe3);
		Component com = new Component(1, Ingredient.State.Dry);
		Ingredient ingre1 = new Ingredient(1, Ingredient.State.Dry, "abc");
		ingre1.liquefy();
		ingre1.dry();
		ingre1.setState(Ingredient.State.Dry);
		Component com1 = new Component(ingre1);
		kit.cook();
	}
}
