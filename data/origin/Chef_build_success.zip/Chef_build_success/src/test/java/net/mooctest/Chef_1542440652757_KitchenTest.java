package net.mooctest;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import java.util.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

import static org.junit.Assert.*;
import static net.mooctest.Ingredient.State.Dry;
import static net.mooctest.Ingredient.State.Liquid;


public class Chef_1542440652757_KitchenTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test(timeout = 4000)
    public void test(){
        Recipe recipe = new Recipe("");
    }
    @Test(timeout = 4000)
    public void test2() throws ChefException {
        Ingredient in=new Ingredient(78,Liquid,"1");
        assertEquals(78,in.getAmount());
        in.setAmount(78);
        assertEquals(Liquid,in.getstate());
        in.setState(Liquid);
        in.liquefy();
        in.dry();
        assertEquals("1",in.getName());
        Ingredient in2=new Ingredient("48 heaped g 78 9 1");
        Ingredient in4=new Ingredient("48 heaped ml 78 9 1");
        Ingredient in5=new Ingredient("48 heaped cup 78 9 1");
        Ingredient in3=new Ingredient("kg 48 78 9 1");
    }
    
    @Test(timeout = 4000)
    public void test6(){
        ChefException CE=new ChefException(1,"dd");
        String[] ll=new String[]{"aa","kk"};
        ChefException CE2=new ChefException(1,ll,"error");
        ChefException CE3=new ChefException(1,2,"78","error");
        Recipe r=new Recipe("1");
        ChefException CE4=new ChefException(1,r,2,"78","error");
    }
        @Test(timeout = 4000)
    public void test7(){
        Component co=new Component(1,Liquid);
        Ingredient in=new Ingredient(78,Liquid,"1");
        Component co2=new Component(in);
        assertEquals(1,co.getValue());
        co.setValue(78);
        assertEquals(Liquid,co.getState());
        co.setState(Dry);
        Component coo=co.clone();
        Component coo2=co2.clone();
        assertEquals(co.getValue(),coo.getValue());
        assertEquals(co.getState(),coo.getState());
        assertEquals(co2.getValue(),coo2.getValue());
        assertEquals(co2.getState(),coo2.getState());
        co.liquefy();
    }
        @Test(timeout = 4000)
    public void test8() throws ChefException {
        Container c=new Container();
        Component co=new Component(1,Liquid);
        Container c2=new Container(c);
        c2.push(co);
        Component co2=c2.peek();
        assertEquals(co.getValue(),co2.getValue());
        assertEquals(co.getState(),co2.getState());
        co2=c2.pop();
        assertEquals(co.getValue(),co2.getValue());
        assertEquals(co.getState(),co2.getState());
        c2.push(co);
        assertEquals(1,c2.size());
        c2.combine(c);
        c2.liquefy();
        assertEquals("\u0001",c2.serve());
        c2.shuffle();
        c2.push(co);
        c2.push(co);
        c2.push(co);
        c2.stir(800);
        c2.clean();
    }
    @Test(timeout = 4000)
public void test10() throws ChefException {
    Recipe r=new Recipe("1");
    r.setComments("dadd");
    r.setCookingTime("das 8 7");
    r.setOvenTemp("gas mark 7 8");
    r.setServes("Serves 11");
    r.setIngredients("11");
    assertEquals(1,r.getServes());
    assertEquals("1",r.getTitle());
}
    @Test(timeout = 4000)
    public void test9() throws ChefException {
        HashMap<String,Recipe> aa=new HashMap<String, Recipe>();
        Recipe r=new Recipe("1");
        Recipe r2=new Recipe("14444");
        r2.setMethod("dasdsa");
        aa.put("1",r);
        Kitchen ki=new Kitchen(aa,r2);
    }
    }