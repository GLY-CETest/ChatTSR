package net.mooctest;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

public class Chef_1542440913226_KitchenTest {

  @Test(timeout = 4000)
  public void ChefTest() throws Exception{
//	  
      Recipe recipe = new Recipe("");
      recipe.setIngredients("Ingredients\n9 heaped perk\n9 kg root\n9 l oil\n9 cups tea");
      recipe.setComments("used");
      recipe.setMethod("Take (9 heaped perk) from refrigerator.Set aside.Set aside.Set aside.");
      recipe.setCookingTime("10 20 20");
      recipe.setOvenTemp("10 10 10 10");
      recipe.setServes("Serves 10");
      recipe.getServes();
      recipe.getTitle();
      recipe.getIngredientValue("root");
      recipe.setIngredientValue("root", 10);
      Method md = recipe.getMethod(1);
      ArrayList<Method> mda = recipe.getMethods();
      HashMap<String,Ingredient> mdm = recipe.getIngredients();
  }

  @Test(timeout = 4000)
  public void IngTest() throws ChefException{
//	  Chef chef = new Chef("/Chef/src/test/resources/Test.txt");
//	  
      Recipe recipe = new Recipe("");
	  Ingredient Ing0 = new Ingredient("9 heaped perk");
	  Ingredient Ing1 = new Ingredient("9 kg root");
	  Ingredient Ing2 = new Ingredient("9 l oil");
	  Ingredient Ing3 = new Ingredient("9 cups tea");
	  Ingredient Ing111 = new Ingredient("Ingredients\n9 heaped perk\n9 kg root");
	  try {
		  String ingredient = "9 cups ";
		  Ingredient Ing4 = new Ingredient(ingredient);
	  }catch(ChefException e) {
		  
	  }
	  Ingredient Ing00 = new Ingredient(9,Ingredient.State.Dry, "perk");
	  Ing0.getAmount();
	  Ing0.dry();
	  Ing0.setAmount(8);
	  Ing0.getstate();
	  Ing0.liquefy();
	  Ing0.getName();
	  Ing0.setState(Ingredient.State.Dry);
  }
  
  @Test(timeout = 4000)
  public void ConTest() throws Exception{
	  Ingredient Ing0 = new Ingredient("9 heaped perk");
	  Component com1 = new Component(10, Ingredient.State.Dry);
	  Component com2 = new Component(Ing0);
	  com2.getState();
	  com2.setValue(10);
	  com2.getValue();
	  com2.setState(Ingredient.State.Liquid);
	  Component com3 = com2.clone();
	  com3.liquefy();
	  Container con0 = new Container();
	  Container con1 = new Container(con0);
	  con1.push(com1);
	  try {
		  Chef chef = new Chef("src/test/java/net/mooctest/Test.txt");
	  }catch(Exception e){}
  }

}
