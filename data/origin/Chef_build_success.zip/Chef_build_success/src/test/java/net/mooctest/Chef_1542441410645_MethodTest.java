package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Chef_1542441410645_MethodTest {

	@Test
	public void testContrust () throws Exception {
		//fail("Not yet implemented");
		Method method1 = new Method("Take apples from refrigerator.", 1);
		Method method2 = new Method("Put apples into the 1st mixing bowl.", 2);
		Method method3 = new Method("Add dry ingredients to 2nd mixing bowl.", 3);
		Method method4 = new Method("Add bananas into 1st mixing bowl.", 4);
		Method method5 = new Method("Liquefy contents of the 2rd mixing bowl.", 5);
		Method method6 = new Method("Liquefy coffee.", 6);
		Method method7 = new Method("Stir the mixing bowl for 6 minutes.", 7);
		Method method8 = new Method("Stir oranges into the 3rd mixing bowl.", 8);
		Method method9 = new Method("Mix the 4th mixing bowl well.", 9);
		Method method10 = new Method("Clean 5th mixing bowl.", 10);
		Method method11 = new Method("Pour contents of the 3rd mixing bowl into the 1st baking dish.", 11);
		Method method12 = new Method("Set aside.", 12);
		Method method13 = new Method("Refrigerate for 1 hours.", 13);
		Method method14 = new Method("Suggestion: ....", 14);
		Method method15 = new Method("Serve with dishes.", 15);
		Method method16 = new Method("cook the oranges until good.", 16);
		Method method17 = new Method("taste the good dishes.", 17);
		try{
			Method methodfail = new Method("etfigjtlyijf 567 jd945ks ///", 18);
		}catch(Exception ex){
			assertTrue(ex.getMessage().contains("Unsupported method found!"));
		}
		
		
		
	}

}
