package net.mooctest;

import static org.junit.Assert.*;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.junit.BeforeClass;
import org.junit.Test;

public class Chef_1542440929814_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      
      Recipe r1 = new Recipe("tomatoAndEgg");
      
      try {
		r1.setIngredients("Ingredients.\n4 heaped kg tomato\n3 cup egg\n500 ml egg");
	} catch (ChefException e) {
		e.printStackTrace();
	}
      r1.setComments("hello");
      try {
		r1.setMethod("Method."
//				+ "Take egg from refrigerator."
				+ "Put tomato into the 1st mixing bowl."
				+ "Fold tomato into the 1st mixing bowl."
				+ "Add dry ingredients."
				+ "Add tomato."
				+ "Liquefy contents of the mixing bowl."
				+ "Liquefy tomato."
				+ "Stir for 1 minutes."
				+ "Stir egg into the 1st mixing bowl."
				+ "Mix the 1st mixing bowl well."
				+ "Clean 1st mixing bowl."
				+ "Pour contents of the 1st mixing bowl into the baking dish."
//				+ "Set aside."
				+ "Refrigerate for 1 hours."
				+ "Serve with tomato."
				+ "Suggestion: whats this."
				+ "beat the egg until killed."
				+ "DIY the egg."
				);
	} catch (ChefException e) {
		e.printStackTrace();
	}
      
      r1.setCookingTime("1 1 1");
      r1.setOvenTemp("1 1 1 1");
      
      HashMap<String, Recipe> hm = new HashMap<String, Recipe>();
      hm.put("tomatoAndEgg", r1);
      Kitchen k = new Kitchen(hm, r1);
      Container c = null;
      try {
		 c = k.cook();
	} catch (ChefException e) {
		e.printStackTrace();
	}
      
      
      // ---------------------------------
      Recipe r2 = new Recipe("tomatoAndEgg");
      try {
		r2.setIngredients("Ingredients.\n4 heaped kg tomato\n3 cup egg\n500 ml egg");
	} catch (ChefException e) {
		e.printStackTrace();
	}
      r2.setComments("hello");
      try {
		r2.setMethod("Method."
				+ "Take egg from refrigerator."
				+ "Put tomato into the 1st mixing bowl."
				+ "Fold tomato into the 1st mixing bowl."
				+ "Add dry ingredients."
				+ "Add tomato."
				+ "Liquefy contents of the mixing bowl."
				+ "Liquefy tomato."
				+ "Stir for 1 minutes."
				+ "Stir egg into the 1st mixing bowl."
				+ "Mix the 1st mixing bowl well."
				+ "Clean 1st mixing bowl."
				+ "Pour contents of the 1st mixing bowl into the baking dish."
				+ "Set aside."
				+ "Refrigerate for 1 hours."
				+ "Serve with tomato."
				+ "Suggestion: whats this."
				+ "beat the egg until killed."
				+ "DIY the egg."
				);
	} catch (ChefException e) {
		e.printStackTrace();
	}
  }
}
