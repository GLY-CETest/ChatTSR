package net.mooctest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.junit.Test;

public class Chef_1542441592791_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
  }
  
  @Test(timeout = 4000)
  public void test00()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("Z");
      try { 
        recipe0.setIngredientValue("", 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test01()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      String string0 = recipe0.getTitle();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void test02()  throws Throwable  {
      Recipe recipe0 = new Recipe("z");
      String string0 = recipe0.getTitle();
      assertEquals("z", string0);
  }

  @Test(timeout = 4000)
  public void test03()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setServes(",v123as26");
      int int0 = recipe0.getServes();
      assertEquals(2, int0);
  }

  @Test(timeout = 4000)
  public void test04()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("a");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertTrue(hashMap0.isEmpty());
  }
  
  @Test(timeout = 4000)
  public void test05()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setServes("mzhLJuIH");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test06()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setServes((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test07()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setOvenTemp("   (");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test08()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      try { 
        recipe0.setOvenTemp((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test09()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setOvenTemp("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test10()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setMethod("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test11()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setMethod((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test12()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setIngredients("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test13()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setIngredients((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test14()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setCookingTime("  (");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test15()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setCookingTime((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test16()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("L");
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: IndexOutOfBoundsException");
      
      } catch(IndexOutOfBoundsException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test17()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("4");
      try { 
        recipe0.getMethod((-1));
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test18()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("k");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertTrue(arrayList0.isEmpty());
  }
  
  @Test(timeout = 4000)
  public void test19()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setMethod("e.>");
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test20()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test21()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setCookingTime("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test22()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertNull(hashMap0);
  }
  
  @Test(timeout = 4000)
  public void test23()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setServes("");
        fail("Expecting exception: StringIndexOutOfBoundsException");
      
      } catch(StringIndexOutOfBoundsException e) {
    	  e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test24()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      int int0 = recipe0.getServes();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test25()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertNull(arrayList0);
  }
  
  @Test(timeout = 4000)
  public void test26()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.getIngredientValue("");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test27()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      String string0 = recipe0.getTitle();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test28()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setComments("");
      assertEquals(0, recipe0.getServes());
  }
  
  public void test29()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method((String) null, 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test30()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method("", 0);
        fail("Expecting exception: ChefException");
      
      } catch(Throwable e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test31()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("1");
      Recipe recipe1 = hashMap0.put((String) null, recipe0);
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.recipe = recipe1;
      // Undeclared exception!
      try { 
        kitchen0.cook();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test32()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("2");
      Container[] containerArray0 = new Container[0];
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.mixingbowls = containerArray0;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }

  @Test(timeout = 4000)
  public void test33()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("N");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test34()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("N");
      Container[] containerArray0 = new Container[5];
      Container container0 = new Container();
      containerArray0[0] = container0;
      containerArray0[1] = container0;
      containerArray0[2] = containerArray0[0];
      containerArray0[3] = containerArray0[2];
      containerArray0[4] = container0;
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
  }
  
  @Test(timeout = 4000)
  public void test35()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("M");
      Container[] containerArray0 = new Container[5];
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test37()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("1");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      Container container1 = kitchen0.cook();
      assertSame(container1, container0);
  }
  
  @Test(timeout = 4000)
  public void test38()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
    	  e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test39()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("2");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test40()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("L");
      Ingredient.State ingredient_State0 = ingredient0.getstate();
      assertEquals(Ingredient.State.Dry, ingredient_State0);
  }

  @Test(timeout = 4000)
  public void test41()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
      String string0 = ingredient0.getName();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void test42()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient(":");
      String string0 = ingredient0.getName();
      assertEquals(":", string0);
  }

  @Test(timeout = 4000)
  public void test43()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient((Integer) null, ingredient_State0, "");
      ingredient0.setAmount(1);
      int int0 = ingredient0.getAmount();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void test44()  throws Throwable  {
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      int int0 = ingredient0.getAmount();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void test45()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient((Integer) null, ingredient_State0, "");
      // Undeclared exception!
      try { 
        ingredient0.getAmount();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test46()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test47()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("M e");
      assertEquals("M e", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void test48()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test49()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient(":");
      ingredient0.liquefy();
      assertEquals(":", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void test50()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
      ingredient0.dry();
      assertEquals(Ingredient.State.Dry, ingredient0.getstate());
  }

  @Test(timeout = 4000)
  public void test51()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
      Ingredient.State ingredient_State0 = ingredient0.getstate();
      ingredient0.setState(ingredient_State0);
      assertEquals("", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void test52()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient((Integer) null, ingredient_State0, "");
      String string0 = ingredient0.getName();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test53()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
      int int0 = ingredient0.getAmount();
      assertEquals(0, int0);
  }
  
  @Test(timeout = 4000)
  public void test54()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      arrayList0.add(component0);
      container0.combine(container0);
      container0.stir(2);
      assertEquals(4, container0.size());
  }

  @Test(timeout = 4000)
  public void test55()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.stir(1);
      assertEquals(1, container0.size());
  }

  @Test(timeout = 4000)
  public void test56()  throws Throwable  {
      Container container0 = new Container();
      container0.stir((-1));
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test57()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      arrayList0.add(component0);
      String string0 = container0.serve();
      assertEquals("\u0000\u0000", string0);
  }

  @Test(timeout = 4000)
  public void test58()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      container0.push(component0);
      arrayList0.add(component0);
      Component component1 = container0.pop();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test59()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      int int0 = container0.size();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void test60()  throws Throwable  {
      Container container0 = new Container();
      String string0 = container0.serve();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test61()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.pop();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void test62()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer(1);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void test63()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void test64()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.peek();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void test65()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      component0.setValue(0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertEquals(Ingredient.State.Dry, component1.getState());
  }

  @Test(timeout = 4000)
  public void test66()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(1, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertEquals(1, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test67()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      ingredient0.setAmount((-1));
      Component component0 = new Component(ingredient0);
      arrayList0.add(component0);
      Component component1 = container0.peek();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void test68()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      try { 
        container1.stir(1);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test69()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      try { 
        container1.size();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test70()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      try { 
        container0.shuffle();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test71()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      try { 
        container0.serve();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test72()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      component0.setValue((-1));
      try { 
        container0.serve();
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test73()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      container1.contents = null;
      Component component0 = new Component(0, ingredient_State0);
      try { 
        container1.push(component0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test74()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      try { 
        container1.pop();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test75()  throws Throwable  {
      Container container0 = new Container();
      try { 
        container0.combine((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test76()  throws Throwable  {
      Container container0 = null;
      try {
        container0 = new Container((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test77()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      container0.combine(container0);
      container0.stir(1);
      assertEquals(2, container0.size());
  }

  @Test(timeout = 4000)
  public void test78()  throws Throwable  {
      Container container0 = new Container();
      container0.stir(1);
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test79()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      String string0 = container0.serve();
      assertEquals("0 ", string0);
  }

  @Test(timeout = 4000)
  public void test80()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.liquefy();
      assertEquals(1, container0.size());
  }

  @Test(timeout = 4000)
  public void test81()  throws Throwable  {
      Container container0 = new Container();
      try { 
        container0.pop();
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test82()  throws Throwable  {
      Container container0 = new Container();
      try { 
        container0.peek();
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test83()  throws Throwable  {
      Container container0 = new Container();
      int int0 = container0.size();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test84()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      try { 
        container1.peek();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test85()  throws Throwable  {
      Container container0 = new Container();
      container0.clean();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test86()  throws Throwable  {
      Container container0 = new Container();
      container0.shuffle();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test87()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      try { 
        container0.liquefy();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test88()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      int int0 = component0.getValue();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void test89()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      int int0 = component0.getValue();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void test90()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      component0.setState((Ingredient.State) null);
      component0.getState();
  }

  @Test(timeout = 4000)
  public void test91()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      Component component1 = component0.clone();
      assertEquals(1, component0.getValue());
      assertEquals(1, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test92()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      Component component1 = component0.clone();
      assertEquals((-1), component0.getValue());
      assertEquals((-1), component1.getValue());
  }

  @Test(timeout = 4000)
  public void test93()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("y");
      Component component0 = null;
      try {
        component0 = new Component(ingredient0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test94()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      int int0 = component0.getValue();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test95()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      component0.liquefy();
      assertEquals(Ingredient.State.Liquid, component0.getState());
  }

  @Test(timeout = 4000)
  public void test96()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      Component component1 = component0.clone();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test97()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      component0.setValue(0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void test98()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      Ingredient.State ingredient_State1 = component0.getState();
      assertSame(ingredient_State1, ingredient_State0);
  }
  
  @Test(timeout = 4000)
  public void test99()  throws Throwable  {
      ChefException chefException0 = new ChefException(1, "");
      assertEquals("Local error: ", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test100()  throws Throwable  {
      String[] stringArray0 = new String[1];
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, stringArray0, "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test101()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      ChefException chefException0 = new ChefException(0, recipe0, 0, (String) null, (String) null);
      assertEquals("net.mooctest.ChefException: Method error, recipe null, step 1: null (null)", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void test102()  throws Throwable  {
      String[] stringArray0 = new String[1];
      stringArray0[0] = "";
      ChefException chefException0 = new ChefException(0, stringArray0, "");
      assertEquals("Ingredient wrongly formatted: '' ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test103()  throws Throwable  {
      Object[] objectArray0 = new Object[4];
      Object object0 = new Object();
      objectArray0[0] = object0;
      objectArray0[1] = object0;
      objectArray0[2] = object0;
      objectArray0[3] = object0;
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertNotNull(string0);
  }

  @Test(timeout = 4000)
  public void test104()  throws Throwable  {
      Object[] objectArray0 = new Object[4];
      Object object0 = new Object();
      objectArray0[0] = object0;
      // Undeclared exception!
      try { 
        ChefException.arrayToString(objectArray0, "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test105()  throws Throwable  {
      Object[] objectArray0 = new Object[0];
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test106()  throws Throwable  {
      ChefException chefException0 = new ChefException((-1), "");
      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void test107()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, 0, "", "");
      assertEquals("net.mooctest.ChefException: Method error, step 1:  ()", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void test108()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "");
      assertEquals("Structural error: ", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test109()  throws Throwable  {
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, (Recipe) null, 0, "", "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }
  
  @Test(timeout = 4000)
  public void test110()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test111()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef("");
        fail("Expecting exception: FileNotFoundException");
      
      } catch(Throwable e) {
         e.printStackTrace();
      }
  }
}
