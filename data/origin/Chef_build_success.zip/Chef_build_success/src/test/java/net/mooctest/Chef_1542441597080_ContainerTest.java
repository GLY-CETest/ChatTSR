package net.mooctest;

import static org.junit.Assert.*;

import java.util.Collections;

import org.junit.Test;

public class Chef_1542441597080_ContainerTest {

	@Test
	public void test() throws ChefException {
		int n=10;
		Ingredient.State state = Ingredient.State.Dry;
		Component co1 =new Component(n,state);
		
		int n2=10;
		Ingredient.State state2 = Ingredient.State.Liquid;
		Component co2 =new Component(n2,state2);
		
		Container c = new Container();
		assertEquals(c.size(),0);
		c.push(co1);
		c.push(co2);
		
		Container c2 = new Container(c);
		
		Component co3=c.peek();
		assertEquals(co3.getValue(),co2.getValue());
		
		co3=c.pop();
		assertEquals(co3.getValue(),co2.getValue());
		
		c.combine(c2);
		assertEquals(c.size(),3);
		
		c2.clean();
		assertEquals(c2.size(),0);
		
		c.liquefy();
		for (Component con : c.contents)
			assertEquals(con.getState(),Ingredient.State.Liquid);
		
		c2=new Container(c);
		c.shuffle();
		Collections.shuffle(c2.contents);
		for(int i=0;i<c2.size();i++)
			assertEquals(c.contents.get(i).getValue(),c2.contents.get(i).getValue());
	}
	@Test
	public void test03() {
		int n=10;
		Ingredient.State state = Ingredient.State.Dry;
		Component co1 =new Component(n,state);
		
		int n2=12;
		Ingredient.State state2 = Ingredient.State.Dry;
		Component co2 =new Component(n2,state2);
		
		Container c = new Container();
		c.push(co1);
		c.push(co2);
		String result=c.serve();
		assertEquals(result,"12 10 ");
	}
	
	@Test
	public void test02() {
		int n=10;
		Ingredient.State state = Ingredient.State.Dry;
		Component co1 =new Component(n,state);
		
		int n2=12;
		Ingredient.State state2 = Ingredient.State.Liquid;
		Component co2 =new Component(n2,state2);
		
		Container c = new Container();
		c.push(co1);
		c.push(co2);
		String result=c.serve();
		String exp=""+Character.toChars((int) (c.contents.get(1).getValue() % 1112064))[0]+10+" ";
		assertEquals(result,exp);
	}
	@Test
	public void test04(){
		int n=10;
		Ingredient.State state = Ingredient.State.Dry;
		Component co1 =new Component(n,state);
		
		int n2=12;
		Ingredient.State state2 = Ingredient.State.Liquid;
		Component co2 =new Component(n2,state2);
		
		int n3=1;
		Ingredient.State state3 = Ingredient.State.Dry;
		Component co3 =new Component(n3,state3);
		
		Container c = new Container();
		c.push(co1);
		c.push(co2);
		c.push(co3);
		Container c2=new Container(c);
		
		int time=2;
		for (int i = 0; i < time && i + 1< c2.contents.size(); i++) {
			Collections.swap(c2.contents, c2.contents.size()-i-1,c2. contents.size()-i-2);
		}
		c.stir(time);
		for(int i=0;i<c.size();i++) {
			assertEquals(c.contents.get(i).getValue(),c2.contents.get(i).getValue());
		}
		c2.clean();
		try {
			c2.pop();
		} catch (ChefException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
		
	}

}
