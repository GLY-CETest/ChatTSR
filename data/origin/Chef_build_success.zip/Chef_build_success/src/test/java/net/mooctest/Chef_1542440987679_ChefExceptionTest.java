package net.mooctest;

import org.junit.Test;

import static org.junit.Assert.*;

public class Chef_1542440987679_ChefExceptionTest {
    @Test
    public void test0() throws Throwable {
        ChefException chefException0 = new ChefException(0, "q9V@[L>2q");
        assertNotNull(chefException0);
        assertEquals(2, ChefException.INGREDIENT);
        assertEquals(3, ChefException.METHOD);
        assertEquals(1, ChefException.LOCAL);
        assertEquals(0, ChefException.STRUCTURAL);

        Object[] objectArray0 = new Object[3];
        objectArray0[0] = (Object) chefException0;
        objectArray0[1] = (Object) "q9V@[L>2q";
        // Undeclared exception!
        try {
            ChefException.arrayToString(objectArray0, "q9V@[L>2q");
            fail("Expecting exception: NullPointerException");

        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test1() throws Throwable {
        String[] stringArray0 = new String[0];
        ChefException chefException0 = new ChefException(2729, stringArray0, "0O8YO5CH");
        assertEquals(0, stringArray0.length);
        assertNotNull(chefException0);
        assertEquals(1, ChefException.LOCAL);
        assertEquals(2, ChefException.INGREDIENT);
        assertEquals(0, ChefException.STRUCTURAL);
        assertEquals(3, ChefException.METHOD);
    }

    @Test
    public void test2() throws Throwable {
        Recipe recipe0 = new Recipe("`?Rk6FR");
        assertEquals("`?Rk6FR", recipe0.getTitle());
        assertEquals(0, recipe0.getServes());
        assertNotNull(recipe0);

        ChefException chefException0 = new ChefException(17, recipe0, 17, "`?Rk6FR", "`?Rk6FR");
        assertNotNull(chefException0);
        assertEquals(1, ChefException.LOCAL);
        assertEquals(0, ChefException.STRUCTURAL);
        assertEquals(3, ChefException.METHOD);
        assertEquals(2, ChefException.INGREDIENT);
    }

    @Test
    public void test3() throws Throwable {
        ChefException chefException0 = new ChefException((-383), (String) null);
        assertNotNull(chefException0);
        assertEquals(1, ChefException.LOCAL);
        assertEquals(0, ChefException.STRUCTURAL);
        assertEquals(2, ChefException.INGREDIENT);
        assertEquals(3, ChefException.METHOD);
    }

    @Test
    public void test4() throws Throwable {
        ChefException chefException0 = new ChefException(5578, 5578, "Qd", "Qd");
        assertNotNull(chefException0);
        assertEquals(0, ChefException.STRUCTURAL);
        assertEquals(3, ChefException.METHOD);
        assertEquals(1, ChefException.LOCAL);
        assertEquals(2, ChefException.INGREDIENT);
    }

    @Test
    public void test5() throws Throwable {
        String[] stringArray0 = new String[1];
        ChefException chefException0 = null;
        try {
            chefException0 = new ChefException(8, stringArray0, "`5bvem81*IE>1K");
            fail("Expecting exception: NullPointerException");

        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test6() throws Throwable {
        ChefException chefException0 = null;
        try {
            chefException0 = new ChefException(990, (Recipe) null, 990, "+tke.qa&0g(h@S7", "riAku[9.xA/");
            fail("Expecting exception: NullPointerException");

        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test7() throws Throwable {
        Object[] objectArray0 = new Object[0];
        String string0 = ChefException.arrayToString(objectArray0, (String) null);
        assertEquals("", string0);
        assertEquals(0, objectArray0.length);
        assertNotNull(string0);
    }

    @Test
    public void test8() throws Throwable {
        ChefException chefException0 = new ChefException((-2310), "");
        Object[] objectArray0 = new Object[2];
        objectArray0[0] = (Object) chefException0;
        objectArray0[1] = (Object) "";
        String string0 = ChefException.arrayToString(objectArray0, "");
        assertNotNull(string0);
    }

    @Test
    public void test9() throws Throwable {
        ChefException chefException0 = new ChefException(9, "CX");
        assertEquals(1, ChefException.LOCAL);
    }
}
