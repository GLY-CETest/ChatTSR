package net.mooctest;

import org.junit.Test;

public class Chef_1542441410645_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
  }
}
