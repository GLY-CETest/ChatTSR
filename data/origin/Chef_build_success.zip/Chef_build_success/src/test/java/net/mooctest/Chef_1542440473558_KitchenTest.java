package net.mooctest;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;
public class Chef_1542440473558_KitchenTest {

  @Test(timeout = 4000)
  public void test000(){
      Recipe recipe = new Recipe("");
  }
  @Test(timeout = 4000)
  public void test0()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test001()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef("");
        fail("Expecting exception: FileNotFoundException");
      
      } catch(Throwable e) {
         
      }
  }
  @Test(timeout = 4000)
  public void test01()  throws Throwable  {
      String[] stringArray0 = new String[2];
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, stringArray0, "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
      }
  }

  @Test(timeout = 4000)
  public void test02()  throws Throwable  {
      Object[] objectArray0 = new Object[0];
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test03()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ChefException chefException0 = new ChefException(0, recipe0, 0, "", "");
      assertEquals("Method error, recipe , step 1:  ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test04()  throws Throwable  {
      Object[] objectArray0 = new Object[3];
      Object object0 = new Object();
      objectArray0[1] = object0;
      objectArray0[0] = object0;
      objectArray0[2] = object0;
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertNotNull(string0);
  }

  @Test(timeout = 4000)
  public void test05()  throws Throwable  {
      Object[] objectArray0 = new Object[3];
      Object object0 = new Object();
      objectArray0[0] = object0;
      // Undeclared exception!
      try { 
        ChefException.arrayToString(objectArray0, "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
      }
  }

  @Test(timeout = 4000)
  public void test06()  throws Throwable  {
      ChefException chefException0 = new ChefException(1, "");
      assertEquals("Local error: ", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test07()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, 0, "", "");
      assertEquals("Method error, step 1:  ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test08()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "");
      assertEquals("Structural error: ", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test09()  throws Throwable  {
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, (Recipe) null, 0, "", "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test10()  throws Throwable  {
      String[] stringArray0 = new String[0];
      ChefException chefException0 = new ChefException(0, stringArray0, "");
      assertEquals("Ingredient wrongly formatted: '' ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void NNtest()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient((Integer) null, ingredient_State0, (String) null);
      ingredient0.setAmount(1);
      Component component0 = new Component(ingredient0);
      int int0 = component0.getValue();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void Ntest01()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      int int0 = component0.getValue();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void Ntest02()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
      Component component0 = new Component(ingredient0);
      component0.getState();
  }

  @Test(timeout = 4000)
  public void Ntest03()  throws Throwable  {
      Integer integer0 = new Integer(1);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      Component component1 = component0.clone();
      assertEquals(1, component1.getValue());
  }

  @Test(timeout = 4000)
  public void Ntest04()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      Component component1 = component0.clone();
      assertEquals((-1), component1.getValue());
      assertEquals((-1), component0.getValue());
  }

  @Test(timeout = 4000)
  public void Ntest05()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.setState(ingredient_State0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void Ntest06()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      int int0 = component0.getValue();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void Ntest07()  throws Throwable  {
      Component component0 = null;
      try {
        component0 = new Component((Ingredient) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Ntest08()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.liquefy();
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void Ntest09()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      Component component1 = component0.clone();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void Ntest10()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.setValue(0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void Ntest11()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.getState();
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void Mtest00()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      container0.push(component0);
      arrayList0.add(component0);
      container0.stir(1);
      assertEquals(4, container0.size());
  }

  @Test(timeout = 4000)
  public void Mtest01()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      container0.push(component0);
      container0.stir(2);
      assertEquals(3, container0.size());
  }

  @Test(timeout = 4000)
  public void Mtest02()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      container0.stir(1);
      assertEquals(1, container0.size());
  }

  @Test(timeout = 4000)
  public void Mtest03()  throws Throwable  {
      Container container0 = new Container();
      container0.stir((-1));
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void Mtest04()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      String string0 = container0.serve();
      assertEquals("0 0 ", string0);
  }

  @Test(timeout = 4000)
  public void Mtest05()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void Mtest06()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      int int0 = container0.size();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void Mtest07()  throws Throwable  {
      Container container0 = new Container();
      String string0 = container0.serve();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void Mtest08()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.pop();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void Mtest09()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void Mtest10()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      arrayList0.add(component0);
      Component component1 = container0.pop();
      assertEquals(Ingredient.State.Dry, component1.getState());
  }

  @Test(timeout = 4000)
  public void Mtest11()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.peek();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void Mtest12()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void Mtest13()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      arrayList0.add(component0);
      Component component1 = container0.peek();
      assertEquals(1, component1.getValue());
  }

  @Test(timeout = 4000)
  public void Mtest14()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      arrayList0.add(component0);
      Component component1 = container0.peek();
      assertEquals((-1), component1.getValue());
  }

  @Test(timeout = 4000)
  public void Mtest15()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.size();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest16()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.shuffle();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest17()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest18()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      container0.push(component0);
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest19()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      // Undeclared exception!
      try { 
        container0.push(component0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest20()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.pop();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest21()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.peek();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest22()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.liquefy();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest23()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.combine((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest24()  throws Throwable  {
      Container container0 = null;
      try {
        container0 = new Container((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest25()  throws Throwable  {
      Container container0 = new Container();
      container0.stir(1);
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void Mtest26()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      container0.liquefy();
      String string0 = container0.serve();
      assertEquals("\u0000", string0);
  }

  @Test(timeout = 4000)
  public void Mtest27()  throws Throwable  {
      Container container0 = new Container();
      try { 
        container0.pop();
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         //
         // Local error: Folded from empty container
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest28()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.peek();
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void Mtest29()  throws Throwable  {
      Container container0 = new Container();
      int int0 = container0.size();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void Mtest30()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      assertFalse(container1.equals((Object)container0));
  }

  @Test(timeout = 4000)
  public void Mtest31()  throws Throwable  {
      Container container0 = new Container();
      container0.clean();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void Mtest32()  throws Throwable  {
      Container container0 = new Container();
      container0.shuffle();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void Mtest33()  throws Throwable  {
      Container container0 = new Container();
      container0.combine(container0);
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void ptest00()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
      String string0 = ingredient0.getName();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void ptest01()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      String string0 = ingredient0.getName();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void ptest02()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      int int0 = ingredient0.getAmount();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void ptest03()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("L");
      ingredient0.setAmount(1);
      int int0 = ingredient0.getAmount();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void ptest04()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("s");
      ingredient0.setAmount((-1));
      int int0 = ingredient0.getAmount();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void ptest05()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void ptest06()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient(" ");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 0
         //
      }
  }

  @Test(timeout = 4000)
  public void ptest07()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("A n");
      assertEquals("A n", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void ptest08()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("0 l");
        fail("Expecting exception: ChefException");
      
      } catch(Throwable e) {
         //
         // Ingredient wrongly formatted: '0 l' (ingredient name missing)
         //
      }
  }

  @Test(timeout = 4000)
  public void ptest09()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("0 g");
        fail("Expecting exception: ChefException");
      
      } catch(Throwable e) {
         //
         // Ingredient wrongly formatted: '0 g' (ingredient name missing)
         //
      }
  }

  @Test(timeout = 4000)
  public void ptest10()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("0 *");
      assertEquals("*", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void ptest11()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"\"
         //
      }
  }

  @Test(timeout = 4000)
  public void ptest12()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("A");
      ingredient0.liquefy();
      assertEquals("A", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void ptest13()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      ingredient0.dry();
      assertEquals(0, ingredient0.getAmount());
  }

  @Test(timeout = 4000)
  public void ptest14()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("F");
      ingredient0.setState((Ingredient.State) null);
      ingredient0.getstate();
  }

  @Test(timeout = 4000)
  public void ptest15()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("F");
      Ingredient.State ingredient_State0 = ingredient0.getstate();
      assertEquals(Ingredient.State.Dry, ingredient_State0);
  }

  @Test(timeout = 4000)
  public void ptest16()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("A");
      String string0 = ingredient0.getName();
      assertEquals("A", string0);
  }

  @Test(timeout = 4000)
  public void ptest17()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("L");
      // Undeclared exception!
      try { 
        ingredient0.getAmount();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void otest0()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("X");
      Container[] containerArray0 = new Container[2];
      Container container0 = new Container();
      containerArray0[0] = container0;
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      containerArray0[1] = container0;
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      Container container1 = kitchen0.cook();
      assertEquals(1, container1.size());
  }

  @Test(timeout = 4000)
  public void otest1()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("W");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.recipe = null;
      // Undeclared exception!
      try { 
        kitchen0.cook();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocotest.Kitchen", e);
      }
  }

  @Test(timeout = 4000)
  public void otest2()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("X");
      Container[] containerArray0 = new Container[2];
      Container container0 = new Container();
      containerArray0[0] = container0;
      containerArray0[1] = container0;
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      Container container1 = kitchen0.cook();
      assertEquals(0, container1.size());
  }

  @Test(timeout = 4000)
  public void otest3()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("X");
      Container[] containerArray0 = new Container[2];
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocotest.Container", e);
      }
  }

  @Test(timeout = 4000)
  public void otest4()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("s");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.mixingbowls = kitchen0.bakingdishes;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }

  @Test(timeout = 4000)
  public void otest5()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocotest.Kitchen", e);
      }
  }
  @Test(timeout = 4000)
  public void ttest0()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method((String) null, 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void ttest1()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method("", 0);
        fail("Expecting exception: ChefException");
      
      } catch(Throwable e) {
         //
         // Method error, step 1:  (Unsupported method found!)
         //
      }
  }

  @Test(timeout = 4000)
  public void itest00()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("A");
      // Undeclared exception!
      try { 
        recipe0.setIngredientValue("", 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocitest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void itest01()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      String string0 = recipe0.getTitle();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void itest02()  throws Throwable  {
      Recipe recipe0 = new Recipe("o");
      String string0 = recipe0.getTitle();
      assertEquals("o", string0);
  }

  @Test(timeout = 4000)
  public void itest03()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setServes("KKky1WY1d");
      int int0 = recipe0.getServes();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void itest04()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("7");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertTrue(arrayList0.isEmpty());
  }

  @Test(timeout = 4000)
  public void itest05()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("v");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertTrue(hashMap0.isEmpty());
  }

  @Test(timeout = 4000)
  public void itest06()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes("gas mark");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"\"
         //
         //("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void itest07()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocitest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void itest08()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("   t");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"t\"
         //
         //("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void itest09()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocitest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void itest10()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 3
         //
         //("net.moocitest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void itest11()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setMethod("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("java.util.Scanner", e);
      }
  }

  @Test(timeout = 4000)
  public void itest12()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setMethod((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocitest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void itest13()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setIngredients("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("java.util.Scanner", e);
      }
  }

  @Test(timeout = 4000)
  public void itest14()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setIngredients((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void itest15()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("  (");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"(\"
         //
         //("java.lang.NumberFormatException", e);
      }
  }

  @Test(timeout = 4000)
  public void itest16()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setCookingTime((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocitest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void itest17()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("g");
      // Undeclared exception!
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: IndexOutOfBoundsException");
      
      } catch(IndexOutOfBoundsException e) {
         //
         // Index: 0, Size: 0
         //
         //("java.util.ArrayList", e);
      }
  }

  @Test(timeout = 4000)
  public void itest18()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("g");
      // Undeclared exception!
      try { 
        recipe0.getMethod((-1));
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void itest19()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      try { 
        recipe0.setMethod("B.d");
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         //
         // Method error, step 1: d. (Unsupported method found!)
         //
         //("net.moocitest.Method", e);
      }
  }

  @Test(timeout = 4000)
  public void itest20()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocitest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void itest21()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 2
         //
         //("net.moocitest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void itest22()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertNull(hashMap0);
  }

  @Test(timeout = 4000)
  public void itest23()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes("");
        fail("Expecting exception: StringIndexOutOfBoundsException");
      
      } catch(StringIndexOutOfBoundsException e) {
      }
  }

  @Test(timeout = 4000)
  public void itest24()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      int int0 = recipe0.getServes();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void itest25()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertNull(arrayList0);
  }

  @Test(timeout = 4000)
  public void itest26()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getIngredientValue("");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //("net.moocitest.Recipe", e);
      }
  }

  @Test(timeout = 4000)
  public void itest27()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      String string0 = recipe0.getTitle();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void itest28()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setComments("");
      assertEquals("", recipe0.getTitle());
  }

  @Test(timeout = 4000)
  public void test80()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Container[] containerArray0 = new Container[2];
      recipe0.setMethod("9");
      Container container0 = new Container();
      containerArray0[0] = container0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      containerArray0[1] = container0;
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      Container container1 = kitchen0.cook();
      assertFalse(container1.equals((Object)container0));
  }

  @Test(timeout = 4000)
  public void test81()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("b");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.recipe = null;
      // Undeclared exception!
      try { 
        kitchen0.cook();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test82()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("d");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container[] containerArray0 = new Container[0];
      kitchen0.mixingbowls = containerArray0;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }

  @Test(timeout = 4000)
  public void test83()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Container[] containerArray0 = new Container[2];
      recipe0.setMethod("9");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test84()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("b");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test85()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }
}
