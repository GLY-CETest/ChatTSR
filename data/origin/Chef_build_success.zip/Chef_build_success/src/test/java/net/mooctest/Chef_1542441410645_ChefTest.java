package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Chef_1542441410645_ChefTest {

	@Test
	public void test() throws Exception {
		//fail("Not yet implemented");
		Chef chef = new Chef("test.txt");
	}

}
