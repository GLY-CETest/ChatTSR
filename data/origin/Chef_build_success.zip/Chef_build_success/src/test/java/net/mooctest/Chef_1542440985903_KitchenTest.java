package net.mooctest;

import static org.junit.Assert.*;

import java.util.HashMap;

import net.mooctest.Ingredient.State;

import org.junit.Test;

public class Chef_1542440985903_KitchenTest {
	Ingredient i3;
	Recipe r1 = new Recipe("wrh");
    Recipe r2 = new Recipe("zp");
    Recipe r3 = new Recipe("wrh");
    Recipe r4 = new Recipe("wrh");
    Method m1,m2,m3,m4,m5,m6,m7,m8,m9,m10;
    HashMap<String,Recipe>hs1=new HashMap<String,Recipe>();
  @Test(timeout = 4000)
  public void test(){
     try {
		Chef chef =new Chef("b.txt");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		assertTrue(true);
	}
     try {
		Chef chef1 =new Chef("a.txt");
		//chef1.bake();
	} catch (Exception e) {
		
		e.printStackTrace();
	}
  }
  @Test(timeout = 4000)
  public void testKit(){
	  try{
		  r1.setMethod("a");r1.setMethod("b");r1.setMethod("c");
		  r2.setMethod("a");
		  r3.setMethod("a");
		  r4.setMethod("a");
	  }catch(Exception e){
		  assertTrue(true);
	  }
	  try{
		  r1.setMethod("a\\.\\n");
	  }catch(Exception e){
		  assertTrue(true);
	  }
	  hs1.put("1", r1); hs1.put("2", r2); hs1.put("3", r3); hs1.put("4", r4);
      Kitchen k1=new Kitchen(hs1, r1);
      
      try {
		Method m1=new Method("oo", 1);
	} catch (ChefException e1) {
		// TODO Auto-generated catch block
		assertTrue(true);
	}
     /*try {
		//k1.cook();
     } catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
     }*/
     
     //method 遍历
     try {
 		m1=new Method("Take wrh from refrigerator.", 1);m1.ingredient="wrh";
 		m2=new Method("Put wrh into the mixing bowl.", 1);
 		m3=new Method("Add dry ingredients to mixing bowl.", 1);
 		m4=new Method("Remove dry ingredients to mixing bowl.", 1);
 		m5=new Method("Liquefy contents of the mixing bowl.", 1);
 		m5=new Method("Liquefy a.", 1);
 		m5=new Method("Stir a into the mixing bowl.", 2);
 		m5=new Method("Stir the mixing bowl for 2 minutes.", 1);
 		m5=new Method("Mix the mixing bowl well.", 2);
 		m5=new Method("Clean mixing bowl.", 2);
 		m5=new Method("Pour contents of the mixing bowl into the baking dish.", 1);
 		m5=new Method("Set aside.", 1);
 		m5=new Method("Refrigerate for 2 hours.", 1);
 		m5=new Method("Serve with a.", 1);
 		m5=new Method("Suggestion: cnm.", 1);
 		m5=new Method("a the b until c.", 1);
 		m5=new Method("a the b.", 1);
 	 } catch (ChefException e1) {
 		e1.printStackTrace();
 	 }
     try {
    	 
		r1.setMethod("Take wrh from refrigerator"
				+ ".Suggestion: wrh."
				+ "Take wrh from refrigerator.Put wrh into the mixing bowl."
				+ "Add dry ingredients to mixing bowl."
				+ "Remove dry ingredients to mixing bowl."
				+ "Stir wrh into the mixing bowl.");
		System.out.println(r1.getMethods().size());
		r2.setMethod("a the b.");
		hs1.clear();
		hs1.put("1", r3); //hs1.put("2", r2);
		r1.setIngredients("wrh\nwrh.");
		Kitchen k2=new Kitchen(hs1, r1);
		k2.cook();
		
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		assertTrue(true);
	}
  }
  @Test(timeout = 4000)
  public void testCom(){
	  //Component c1=new Component(ingredient);
  }
  @Test(timeout = 4000)
  public void testIng() throws ChefException{
	  Ingredient i1=new Ingredient("2 heaped wrh pinch l cup");
	  Ingredient i2=new Ingredient("2 pinch l cup");
	  i3=new Ingredient("2 l cup");
	  try{
		  Ingredient i4=new Ingredient("2 teaspoons");
	  }catch (ChefException e) {
			// TODO Auto-generated catch block
			assertTrue(true);
		}
	  Ingredient i4=new Ingredient(new Integer(1),State.Dry,"wrh");
	  i4.setState(State.Dry);
	  i4.dry();
	  i4.liquefy();
	  i4.getAmount();
	  i4.setAmount(9);
	  i4.getstate();
  }
  @Test(timeout = 4000)
  public void testCon() {
	  try {
		i3=new Ingredient("2 l cup");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  Component c1=new Component(i3);
	  c1=new Component(1, State.Dry);
	  c1.setState(State.Dry);
	  c1.getState();
	  c1.setValue(5);
	  c1.getValue();
	  c1.clone();
	  c1.liquefy();
	  
  }
  @Test(timeout = 4000)
  public void testCont() {
	  try {
			i3=new Ingredient("2 l cup");
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 Component cp1=new Component(i3);
	 Container c1=new Container();
	 Container c2=new Container(c1);
	 try {
		c2.pop();
	} catch (ChefException e1) {
		// TODO Auto-generated catch block
		//e1.printStackTrace();
	}
	 c2.push(cp1);
	 c2.peek();
	 try {
		c2.pop();
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	c2.size();
	c2.combine(c2);
	c2.clean();
	c2.liquefy();c2.serve();c2.shuffle();c2.stir(3);
	c2.push(cp1);c2.serve();c2.shuffle();c2.stir(3);
  }
  @Test(timeout = 4000)
  public void testrec() {
	 r1.setComments("asd");
	 r1.setCookingTime("das  1 sa");
	 r1.setOvenTemp("gas mark 1 1");
	 r1.setServes("1 2 3 46566");
	 assertEquals(656,r1.getServes());
	 try {
		r1.setMethod("Take wrh from refrigerator"
					+ ".Suggestion: wrh."
					+ "Take wrh from refrigerator.Put wrh into the mixing bowl."
					+ "Add dry ingredients to mixing bowl."
					+ "Remove dry ingredients to mixing bowl."
					+ "Stir wrh into the mixing bowl.");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 r1.getMethod(2);
  }
}
