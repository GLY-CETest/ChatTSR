package net.mooctest;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

public class Chef_1542441471036_KitchenTest {

	  @Test(timeout = 4000)
	  public void tesIngredient(){
	      try {
	    	  Ingredient i =new Ingredient("1 heaped l");
		} catch (Exception e) {
		}
	      try {
	    	  Ingredient i =new Ingredient("1 heaped g l cup");
		} catch (Exception e) {
		}
	      try {
	    	  Ingredient i =new Ingredient("7 bac");
		} catch (Exception e) {
		}
	      try {
	    	  Ingredient i =new Ingredient("1 heaped cup");
		} catch (Exception e) {
		}
	      try {
	    	  Ingredient i =new Ingredient("! heaped cup");
		} catch (Exception e) {
		}
	      try {
	    	  Ingredient i =new Ingredient("1 heaped qwe");
		} catch (Exception e) {
		}
	      try {
	    	  Ingredient i =new Ingredient(null);
		} catch (Exception e) {
		}
	 
	  }	
	
  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
      try {
    	  recipe.setIngredients("sad123\n123");
	} catch (Exception e2) {
		// TODO: handle exception
	}
      try {
    	  recipe.setMethod("Take abc from refrigerator.");
    	 
	} catch (Exception e2) {
		// TODO: handle exception
	}
      recipe.setOvenTemp("ad 12 weq 213");
      
  }
  @Test(timeout = 4000)
  public void testChef(){
	  try {
		  Chef c = new Chef("src/test/resources/test1");
	} catch (Exception e) {
	}
	  try {
		  Chef c = new Chef("src/test/resources/test2");
	} catch (Exception e) {
	}
	  try {
		  Chef c = new Chef("src/test/resources/test3");
	} catch (Exception e) {
	}
	  try {
		  Chef c = new Chef("src/test/resources/test4");
	} catch (Exception e) {
	}
	  try {
		  Chef c = new Chef("src/test/resources/test5");
	} catch (Exception e) {
	}
	  try {
		  Chef c = new Chef("src/test/resources/test6");
	} catch (Exception e) {
	}
	  try {
		  Chef c = new Chef("src/test/resources/test2");
	} catch (Exception e) {
	}
	  
  }
  @Test(timeout = 4000)
  public void testKitechen(){
	  HashMap<String, Recipe> h = new HashMap<String, Recipe>();
	  Recipe recipe1 = new Recipe("123");
	  Recipe recipe2 = new Recipe("456");
	  h.put("1", recipe1);
	  try {
		recipe2.setMethod("Take abc from refrigerator.");
	} catch (Exception e) {
		// TODO: handle exception
	}
	  Kitchen k = new Kitchen(h, recipe2);
	  try {
			k.cook();
		} catch (Exception e) {
			// TODO: handle exception
		}
     
  }
      @Test(timeout = 4000)
      public void Containertest(){
    	  Container c= new Container();
    	  try {
			c.pop();
		} catch (Exception e) {
		}
    	 assertEquals(0,c.size());
    	  
    	  
    	  Component a= new Component(12123, null);
    	  assertEquals(12123,a.getValue());
    	  assertEquals(null,a.getState());
    	 
    	  c.push(a);
    	  c.liquefy();
    	  assertEquals("⽛",c.serve());
    	  c.stir(2);
    	  c.push(a);
    	  assertEquals(a,c.peek());
    	  c.stir(1);
    	  c.stir(0);
    	  
    	  try {
  			assertEquals(a,c.pop());
  		} catch (Exception e) {
  		}
    	  try {
    			assertEquals(a,c.pop());
    		} catch (Exception e) {
    		}
   
    	  Component b;
    	  try {
    		  Ingredient i =new Ingredient("1 heaped qwe");
    		  b=new Component(i);
    		  c.push(b);
    		  c.serve();
  		} catch (Exception e) {
  		}
  }
  @Test(timeout = 4000)
  public void testMethod(){
     try {
    	 Method m =new Method("Take abc from refrigerator.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("test", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Liquefy abc.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Serve with abc.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     
     
     
     try {
    	 Method m =new Method(" Suggestion: abc.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Set aside.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Put abc into the mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Put abc into the 9th mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Fold abc into the mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Add dry ingredients to 9th mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Add dry ingredients.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Add abc into 9th mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Remove abc into 9th mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Combine abc into 9th mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Divide abc .", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method(" Liquefy contents of the mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method(" Liquefy contents of the 9th mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     
     try {
    	 Method m =new Method("Stir for 9 minutes.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Stir the 9th mixing bowl for 9 minutes.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method(" Stir abc into the mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method(" Stir abc into the 9th mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("   Mix well.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("   Mix the mixing bowl well.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("   Mix the 9th mixing bowl well.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("   Clean mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("   Clean 9th mixing bowl.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("  Pour contents of the mixing bowl into the baking dish.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("  Pour contents of the 9th mixing bowl into the 9th baking dish.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("abc the dbe.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("abc until abc.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("abc the abc until abc.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Refrigerate.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     try {
    	 Method m =new Method("Refrigerate for 9 hours.", 1);
	} catch (Exception e) {
		// TODO: handle exception
	}
     
  }
 }
