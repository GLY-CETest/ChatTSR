package net.mooctest;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class Chef_1542440987679_ContainerTest {
    @Test
    public void test00() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Dry;
        Component component0 = new Component(272, ingredient_State0);
        container0.push(component0);
        container0.push(component0);
        container0.combine(container0);
        container0.stir(3743);
        assertEquals(4, container0.size());
    }

    @Test
    public void test01() throws Exception {
        Container container0 = new Container();
        container0.stir((-33));
        assertEquals(0, container0.size());
    }

    @Test
    public void test02() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Dry;
        Component component0 = new Component(272, ingredient_State0);
        container0.push(component0);
        container0.combine(container0);
        String string0 = container0.serve();
        assertEquals("272 272 ", string0);
    }

    @Test
    public void test03() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
        Component component0 = new Component(2, ingredient_State0);
        container0.push(component0);
        container0.combine(container0);
        Component component1 = container0.pop();
        assertEquals(Ingredient.State.Liquid, component1.getState());
    }

    @Test
    public void test04() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Dry;
        Component component0 = new Component(670, ingredient_State0);
        container0.push(component0);
        int int0 = container0.size();
        assertEquals(1, int0);
    }

    @Test
    public void test05() throws Exception {
        Container container0 = new Container();
        container0.push((Component) null);
        Component component0 = container0.pop();
        assertNull(component0);
    }

    @Test
    public void test06() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Dry;
        Component component0 = new Component(670, ingredient_State0);
        component0.setValue(0);
        container0.push(component0);
        Component component1 = container0.pop();
        assertEquals(Ingredient.State.Dry, component1.getState());
    }

    @Test
    public void test07() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Dry;
        Component component0 = new Component((-1449), ingredient_State0);
        container0.push(component0);
        Component component1 = container0.pop();
        assertEquals(Ingredient.State.Dry, component1.getState());
    }

    @Test
    public void test08() throws Exception {
        Container container0 = new Container();
        container0.push((Component) null);
        Component component0 = container0.peek();
        assertNull(component0);
    }

    @Test
    public void test09() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Dry;
        Component component0 = new Component(670, ingredient_State0);
        component0.setValue(0);
        container0.push(component0);
        Component component1 = container0.peek();
        assertEquals(Ingredient.State.Dry, component1.getState());
    }

    @Test
    public void test10() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Dry;
        Component component0 = new Component(591, ingredient_State0);
        container0.push(component0);
        Component component1 = container0.peek();
        assertEquals(591, component1.getValue());
    }

    @Test
    public void test11() throws Exception {
        Container container0 = new Container();
        ArrayList<Component> arrayList0 = container0.contents;
        Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
        Component component0 = new Component(3, ingredient_State0);
        arrayList0.add(component0);
        component0.setValue((-1083));
        Component component1 = container0.peek();
        assertEquals((-1083), component1.getValue());
    }

    @Test
    public void test12() throws Exception {
        Container container0 = new Container();
        Container container1 = new Container(container0);
        container1.contents = null;
        try {
            container1.stir(1801);
            fail();
        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test13() throws Exception {
        Container container0 = new Container();
        container0.contents = null;
        try {
            container0.shuffle();
            fail();
        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test14() throws Exception {
        Container container0 = new Container();
        container0.push((Component) null);
        try {
            container0.serve();
            fail();
        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test15() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
        Component component0 = new Component(2, ingredient_State0);
        component0.setValue((-1286));
        container0.push(component0);
        try {
            container0.serve();
            fail();
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void test16() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Dry;
        Component component0 = new Component(670, ingredient_State0);
        Container container1 = new Container(container0);
        container1.contents = null;
        try {
            container1.push(component0);
            fail();
        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test17() throws Exception {
        Container container0 = new Container();
        container0.contents = null;
        try {
            container0.pop();
            fail();
        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test18() throws Exception {
        Container container0 = new Container();
        container0.contents = null;
        try {
            container0.peek();
            fail();
        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test19() throws Exception {
        Container container0 = new Container();
        container0.push((Component) null);
        try {
            container0.liquefy();
            fail();
        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test20() throws Exception {
        Container container0 = null;
        try {
            container0 = new Container((Container) null);
            fail();
        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test21() throws Exception {
        Container container0 = new Container();
        container0.stir(272);
        assertEquals(0, container0.size());
    }

    @Test
    public void test22() throws Exception {
        Container container0 = new Container();
        container0.stir(0);
        assertEquals(0, container0.size());
    }

    @Test
    public void test23() throws Exception {
        Container container0 = new Container();
        String string0 = container0.serve();
        assertEquals("", string0);
    }

    @Test
    public void test24() throws Exception {
        Container container0 = new Container();
        Ingredient.State ingredient_State0 = Ingredient.State.Dry;
        Component component0 = new Component(591, ingredient_State0);
        container0.push(component0);
        container0.liquefy();
        String string0 = container0.serve();
        assertEquals("\u024F", string0);
    }

    @Test
    public void test25() throws Exception {
        Container container0 = new Container();
        try {
            container0.pop();
            fail();
        } catch (Exception e) {
        }
    }

    @Test
    public void test26() throws Exception {
        Container container0 = new Container();
        try {
            container0.peek();
            fail();
        } catch (ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test27() throws Exception {
        Container container0 = new Container();
        int int0 = container0.size();
        assertEquals(0, int0);
    }

    @Test
    public void test28() throws Exception {
        Container container0 = new Container();
        Container container1 = new Container(container0);
        container1.contents = null;
        try {
            container1.size();
            fail();
        } catch (NullPointerException e) {
        }
    }

    @Test
    public void test29() throws Exception {
        Container container0 = new Container();
        container0.clean();
        assertEquals(0, container0.size());
    }

    @Test
    public void test30() throws Exception {
        Container container0 = new Container();
        container0.shuffle();
        assertEquals(0, container0.size());
    }

    @Test
    public void test31() throws Exception {
        Container container0 = new Container();
        try {
            container0.combine((Container) null);
            fail();
        } catch (NullPointerException e) {
        }
    }
}
