package net.mooctest;

import org.junit.Assert;
import org.junit.Test;

public class Chef_1542440987679_IngridientComponentTest {
    @Test
    public void testNoName() throws Exception {
        try {
            Ingredient ingredient = new Ingredient("100 kg");
            Assert.fail();
        } catch (ChefException e) {
            Assert.assertTrue(e.getMessage().contains("Ingredient wrongly formatted"));
            Assert.assertTrue(e.getMessage().contains("(ingredient name missing)"));
        }
    }

    @Test
    public void testConstruct() {
        Ingredient ingredient = new Ingredient(741, Ingredient.State.Dry, "test");
        Assert.assertEquals(741, ingredient.getAmount());
        Assert.assertEquals(Ingredient.State.Dry, ingredient.getstate());
        Assert.assertEquals("test", ingredient.getName());

        ingredient.liquefy();
        Assert.assertEquals(741, ingredient.getAmount());
        Assert.assertEquals(Ingredient.State.Liquid, ingredient.getstate());
        Assert.assertEquals("test", ingredient.getName());

        ingredient.dry();
        Assert.assertEquals(741, ingredient.getAmount());
        Assert.assertEquals(Ingredient.State.Dry, ingredient.getstate());
        Assert.assertEquals("test", ingredient.getName());
    }

    @Test
    public void testComponent() {
        Component comp = new Component(9767, Ingredient.State.Dry);
        Assert.assertEquals(9767, comp.getValue());
        Assert.assertEquals(Ingredient.State.Dry, comp.getState());

        comp.setState(Ingredient.State.Liquid);
        Assert.assertEquals(9767, comp.getValue());
        Assert.assertEquals(Ingredient.State.Liquid, comp.getState());

        Component comp2 = comp.clone();
        Assert.assertEquals(9767, comp.getValue());
        Assert.assertEquals(Ingredient.State.Liquid, comp.getState());
    }
}
