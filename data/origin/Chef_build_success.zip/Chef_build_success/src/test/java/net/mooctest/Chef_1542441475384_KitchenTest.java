package net.mooctest;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import org.junit.Test;

public class Chef_1542441475384_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
      try {
		Chef c=new Chef("");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		p(e.getMessage());
	}
      
      File f=new File("src/test/resources/test.txt");
      try {
		FileOutputStream out=new FileOutputStream(f);
		PrintStream p=new PrintStream(out);
		p.print(" \n\n");
		p.print("Ingredients\n\n");
		p.print("Ingredients.2 tablespoons heaped parsley\n");
		p.print("Ingredients.2 tablespoons pinches parsley\n");
		p.print("Cooking time\n\n");
		p.print("3 h\n");
		p.print("Method\n\n");
		p.print("Methods.11\n");
		p.print("Serves\n\n");
		p.print("3 h 20 m\n");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      try {
		Chef c=new Chef("src/test/resources/test.txt");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		p(e.getMessage());
	}
      

      
  }
  
  private <T> void p(T x) {
      System.out.println(x);
  }
}
