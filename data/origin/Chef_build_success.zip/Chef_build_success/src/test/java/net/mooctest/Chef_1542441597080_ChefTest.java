package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Chef_1542441597080_ChefTest {

	@Test(timeout = 4000)
	  public void test0()  throws Throwable  {
	      Chef chef0 = null;
	      try {
	        chef0 = new Chef((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test1()  throws Throwable  {
	      Chef chef0 = null;
	      try {
	        chef0 = new Chef("");
	        fail("Expecting exception: FileNotFoundException");
	      
	      } catch(Throwable e) {
	         //
	         //  (\u6CA1\u6709\u90A3\u4E2A\u6587\u4EF6\u6216\u76EE\u5F55)
	         //
//	         verifyException("java.io.FileInputStream", e);
	      }
	  }

}
