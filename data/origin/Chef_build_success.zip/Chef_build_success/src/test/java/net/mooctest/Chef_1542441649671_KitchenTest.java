package net.mooctest;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.junit.Test;

public class Chef_1542441649671_KitchenTest {

	@Test(timeout = 4000)
	  public void test0()  throws Throwable  {
	      Chef chef0 = null;
	      try {
	        chef0 = new Chef((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void test1()  throws Throwable  {
	      Chef chef0 = null;
	      try {
	        chef0 = new Chef("");
	        fail("Expecting exception: FileNotFoundException");
	      
	      } catch(Throwable e) {
	         //
	         // 
	         //
	      }
	  }
	  @Test(timeout = 4000)
	  public void testkit0()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("e");
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
	      Container container0 = kitchen0.cook();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      Container container1 = kitchen0.cook();
	      assertSame(container1, container0);
	  }

	  @Test(timeout = 4000)
	  public void testkit1()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("W");
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, (Container[]) null, (Container[]) null);
	      Recipe recipe1 = new Recipe((String) null);
	      kitchen0.recipe = recipe1;
	      // Undeclared exception!
	      try { 
	        kitchen0.cook();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testkit2()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("2");
	      Container[] containerArray0 = new Container[5];
	      Container container0 = new Container();
	      containerArray0[0] = container0;
	      containerArray0[1] = container0;
	      containerArray0[2] = container0;
	      containerArray0[3] = container0;
	      containerArray0[4] = container0;
	      Kitchen kitchen0 = new Kitchen((HashMap<String, Recipe>) null, recipe0, containerArray0, containerArray0);
	      Container container1 = kitchen0.cook();
	      assertFalse(container1.equals((Object)container0));
	  }

	  @Test(timeout = 4000)
	  public void testkit3()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("2");
	      Container[] containerArray0 = new Container[5];
	      Kitchen kitchen0 = null;
	      try {
	        kitchen0 = new Kitchen((HashMap<String, Recipe>) null, recipe0, containerArray0, containerArray0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testkit4()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("i");
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
	      Container[] containerArray0 = new Container[0];
	      kitchen0.mixingbowls = containerArray0;
	      Container container0 = kitchen0.cook();
	      assertNull(container0);
	  }

	  @Test(timeout = 4000)
	  public void testkit5()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      Kitchen kitchen0 = null;
	      try {
	        kitchen0 = new Kitchen(hashMap0, recipe0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }
	  @Test(timeout = 4000)
	  public void testrecip00()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setIngredients("D");
	      // Undeclared exception!
	      try { 
	        recipe0.setIngredientValue("", 0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip01()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      String string0 = recipe0.getTitle();
	      assertNull(string0);
	  }

	  @Test(timeout = 4000)
	  public void testrecip02()  throws Throwable  {
	      Recipe recipe0 = new Recipe("J");
	      String string0 = recipe0.getTitle();
	      assertEquals("J", string0);
	  }

	  @Test(timeout = 4000)
	  public void testrecip03()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setServes("W}/kP|91o");
	      int int0 = recipe0.getServes();
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void testrecip04()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("S");
	      ArrayList<Method> arrayList0 = recipe0.getMethods();
	      assertTrue(arrayList0.isEmpty());
	  }

	  @Test(timeout = 4000)
	  public void testrecip05()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setIngredients(".");
	      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
	      assertTrue(hashMap0.isEmpty());
	  }

	  @Test(timeout = 4000)
	  public void testrecip06()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setServes("PhodOZUV");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"\"
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip07()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setServes((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip08()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setOvenTemp("   t");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"t\"
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip09()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setOvenTemp((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip10()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setOvenTemp("");
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // 3
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip11()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setMethod("");
	        fail("Expecting exception: NoSuchElementException");
	      
	      } catch(NoSuchElementException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip12()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setMethod((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip13()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setIngredients("");
	        fail("Expecting exception: NoSuchElementException");
	      
	      } catch(NoSuchElementException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip14()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setIngredients((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip15()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setCookingTime("  C");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"C\"
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip16()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setCookingTime((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip17()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("S");
	      // Undeclared exception!
	      try { 
	        recipe0.getMethod(0);
	        fail("Expecting exception: IndexOutOfBoundsException");
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 0, Size: 0
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip18()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("D");
	      // Undeclared exception!
	      try { 
	        recipe0.getMethod((-1));
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip19()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      try { 
	        recipe0.setMethod("^.*");
	        fail("Expecting exception: ChefException");
	      
	      } catch(ChefException e) {
	         //
	         // Method error, step 1: *. (Unsupported method found!)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip20()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      ArrayList<Method> arrayList0 = recipe0.getMethods();
	      assertNull(arrayList0);
	  }

	  @Test(timeout = 4000)
	  public void testrecip21()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setCookingTime("");
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // 2
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip22()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.getMethod(0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip23()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      String string0 = recipe0.getTitle();
	      assertEquals("", string0);
	  }

	  @Test(timeout = 4000)
	  public void testrecip24()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.getIngredientValue("");
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecip25()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      int int0 = recipe0.getServes();
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void testrecip26()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setComments("");
	      assertEquals("", recipe0.getTitle());
	  }

	  @Test(timeout = 4000)
	  public void testrecip27()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
	      assertNull(hashMap0);
	  }

	  @Test(timeout = 4000)
	  public void testrecip28()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setServes("");
	        fail("Expecting exception: StringIndexOutOfBoundsException");
	      
	      } catch(StringIndexOutOfBoundsException e) {
	      }
	  }
	  
	  @Test(timeout = 4000)
	  public void testing00()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
	      String string0 = ingredient0.getName();
	      assertNull(string0);
	  }

	  @Test(timeout = 4000)
	  public void testing01()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      String string0 = ingredient0.getName();
	      assertEquals("", string0);
	  }

	  @Test(timeout = 4000)
	  public void testing02()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("J");
	      ingredient0.setAmount(0);
	      int int0 = ingredient0.getAmount();
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void testing03()  throws Throwable  {
	      Integer integer0 = new Integer(1);
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      int int0 = ingredient0.getAmount();
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void testing04()  throws Throwable  {
	      Integer integer0 = new Integer((-1));
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
	      int int0 = ingredient0.getAmount();
	      assertEquals((-1), int0);
	  }

	  @Test(timeout = 4000)
	  public void testing05()  throws Throwable  {
	      Ingredient ingredient0 = null;
	      try {
	        ingredient0 = new Ingredient((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testing06()  throws Throwable  {
	      Ingredient ingredient0 = null;
	      try {
	        ingredient0 = new Ingredient(" ");
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // 0
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testing07()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("L =");
	      assertEquals("L =", ingredient0.getName());
	  }

	  @Test(timeout = 4000)
	  public void testing08()  throws Throwable  {
	      Ingredient ingredient0 = null;
	      try {
	        ingredient0 = new Ingredient("8 l");
	        fail("Expecting exception: ChefException");
	      
	      } catch(Throwable e) {
	         //
	         // Ingredient wrongly formatted: '8 l' (ingredient name missing)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testing09()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("8 v");
	      assertEquals("v", ingredient0.getName());
	  }

	  @Test(timeout = 4000)
	  public void testing10()  throws Throwable  {
	      Ingredient ingredient0 = null;
	      try {
	        ingredient0 = new Ingredient("");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"\"
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testing11()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("v");
	      Ingredient.State ingredient_State0 = ingredient0.getstate();
	      assertEquals(Ingredient.State.Dry, ingredient_State0);
	  }

	  @Test(timeout = 4000)
	  public void testing12()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("v");
	      ingredient0.dry();
	      assertEquals(Ingredient.State.Dry, ingredient0.getstate());
	  }

	  @Test(timeout = 4000)
	  public void testing13()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("v");
	      ingredient0.liquefy();
	      assertEquals(Ingredient.State.Liquid, ingredient0.getstate());
	  }

	  @Test(timeout = 4000)
	  public void testing14()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("L");
	      // Undeclared exception!
	      try { 
	        ingredient0.getAmount();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testing15()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      ingredient0.setState((Ingredient.State) null);
	      ingredient0.getstate();
	  }

	  @Test(timeout = 4000)
	  public void testing16()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("v");
	      String string0 = ingredient0.getName();
	      assertEquals("v", string0);
	  }
	  
	  @Test(timeout = 4000)
	  public void testcon00()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.push(component0);
	      container0.combine(container0);
	      container0.stir(1);
	      assertEquals(4, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcon01()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.combine(container0);
	      container0.push(component0);
	      container0.stir(2);
	      assertEquals(3, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcon02()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.stir(1);
	      assertEquals(1, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcon03()  throws Throwable  {
	      Container container0 = new Container();
	      container0.stir((-1));
	      assertEquals(0, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcon04()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.push(component0);
	      String string0 = container0.serve();
	      assertEquals("\u0000\u0000", string0);
	  }

	  @Test(timeout = 4000)
	  public void testcon05()  throws Throwable  {
	      Container container0 = new Container();
	      ArrayList<Component> arrayList0 = container0.contents;
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      Component component0 = new Component(ingredient0);
	      container0.push(component0);
	      arrayList0.add(component0);
	      Component component1 = container0.pop();
	      assertEquals(0, component1.getValue());
	  }

	  @Test(timeout = 4000)
	  public void testcon06()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      int int0 = container0.size();
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void testcon07()  throws Throwable  {
	      Container container0 = new Container();
	      String string0 = container0.serve();
	      assertEquals("", string0);
	  }

	  @Test(timeout = 4000)
	  public void testcon08()  throws Throwable  {
	      Container container0 = new Container();
	      ArrayList<Component> arrayList0 = container0.contents;
	      arrayList0.add((Component) null);
	      Component component0 = container0.pop();
	      assertNull(component0);
	  }

	  @Test(timeout = 4000)
	  public void testcon09()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(1, ingredient_State0);
	      container0.push(component0);
	      Component component1 = container0.pop();
	      assertSame(component1, component0);
	  }

	  @Test(timeout = 4000)
	  public void testcon10()  throws Throwable  {
	      Container container0 = new Container();
	      Integer integer0 = new Integer((-1));
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      Component component0 = new Component(ingredient0);
	      container0.push(component0);
	      Component component1 = container0.pop();
	      assertEquals(Ingredient.State.Dry, component1.getState());
	  }

	  @Test(timeout = 4000)
	  public void testcon11()  throws Throwable  {
	      Container container0 = new Container();
	      ArrayList<Component> arrayList0 = new ArrayList<Component>();
	      container0.contents = arrayList0;
	      arrayList0.add((Component) null);
	      Component component0 = container0.peek();
	      assertNull(component0);
	  }

	  @Test(timeout = 4000)
	  public void testcon12()  throws Throwable  {
	      Container container0 = new Container();
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      Component component0 = new Component(ingredient0);
	      container0.push(component0);
	      Component component1 = container0.peek();
	      assertSame(component1, component0);
	  }

	  @Test(timeout = 4000)
	  public void testcon13()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(1, ingredient_State0);
	      container0.push(component0);
	      Component component1 = container0.peek();
	      assertEquals(Ingredient.State.Liquid, component1.getState());
	  }

	  @Test(timeout = 4000)
	  public void testcon14()  throws Throwable  {
	      Container container0 = new Container();
	      Integer integer0 = new Integer((-1));
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      Component component0 = new Component(ingredient0);
	      container0.push(component0);
	      Component component1 = container0.peek();
	      assertSame(component1, component0);
	  }

	  @Test(timeout = 4000)
	  public void testcon15()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.stir(1);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon16()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.size();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon17()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.shuffle();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon18()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents.add((Component) null);
	      // Undeclared exception!
	      try { 
	        container0.serve();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon19()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      component0.setValue((-1));
	      // Undeclared exception!
	      try { 
	        container0.serve();
	        fail("Expecting exception: IllegalArgumentException");
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon20()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      container0.contents = null;
	      Component component0 = new Component(0, ingredient_State0);
	      // Undeclared exception!
	      try { 
	        container0.push(component0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon21()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.peek();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon22()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.liquefy();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon23()  throws Throwable  {
	      Container container0 = new Container();
	      // Undeclared exception!
	      try { 
	        container0.combine((Container) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon24()  throws Throwable  {
	      Container container0 = null;
	      try {
	        container0 = new Container((Container) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon25()  throws Throwable  {
	      Container container0 = new Container();
	      container0.stir(1);
	      assertEquals(0, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcon26()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      String string0 = container0.serve();
	      assertEquals("0 ", string0);
	  }

	  @Test(timeout = 4000)
	  public void testcon27()  throws Throwable  {
	      Container container0 = new Container();
	      try { 
	        container0.pop();
	        fail("Expecting exception: ChefException");
	      
	      } catch(ChefException e) {
	         //
	         // Local error: Folded from empty container
	         //
	          
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon28()  throws Throwable  {
	      Container container0 = new Container();
	      // Undeclared exception!
	      try { 
	        container0.peek();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcon29()  throws Throwable  {
	      Container container0 = new Container();
	      container0.shuffle();
	      assertEquals(0, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcon30()  throws Throwable  {
	      Container container0 = new Container();
	      int int0 = container0.size();
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void testcon31()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.liquefy();
	      assertEquals(1, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcon32()  throws Throwable  {
	      Container container0 = new Container();
	      container0.clean();
	      assertEquals(0, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcon33()  throws Throwable  {
	      Container container0 = new Container();
	      Container container1 = new Container(container0);
	      container1.contents = null;
	      // Undeclared exception!
	      try { 
	        container1.pop();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	          
	      }
	  }
	  
	  @Test
		public void test() {
			// TODO Auto-generated method stub
			Recipe r1=new Recipe("recipe1");
			Recipe r2=new Recipe("recipe2");
			HashMap<String, Recipe> recipes=new HashMap<String, Recipe>();
			recipes.put("test1", r1);
			recipes.put("test2", r2);
			try {
				r1.setMethod("Method.m2");
			} catch (ChefException e1) {
				assertEquals("Method error, step 1: m2. (Unsupported method found!)", e1.getMessage());
			}

			try {
				r1.setMethod("m1.Take a from refrigerator.Put e into the 3th mixing bowl.");
				r1.setMethod("m2.Fold e into the 3th mixing bowl.Add dry ingredients to 3th mixing bowl.");
				r1.setMethod("m3.Add e to 3th mixing bowl.Remove e from 3th mixing bowl.Combine e into 3rd mixing bowl.");
				r1.setMethod("m4.Liquefy contents of the 3nd mixing bowl.");
				r1.setMethod("m5.Liquefy acq.");
				r1.setMethod("m6.Stir the 3th mixing bowl for 1 minutes.Stir ac into the 3th mixing bowl.Mix the 3th mixing bowl well.");
				r1.setMethod("m6.Clean 3st mixing bowl.Pour contents of the 4th mixing bowl into the 3th baking dish.");
				r1.setMethod("m7.Set aside.");
				r1.setMethod("m8.Suggestion: Suggestion.mymeth the sq until th.");
				r1.setMethod("m9.sq the th.");
				r1.setMethod("m7.Serve with e.");
				r1.setMethod("m2.Refrigerate for 3 hours.");
				assertEquals(Method.Type.Refrigerate, r1.getMethod(0).type);
				

			} catch (ChefException e) {
				// TODO Auto-generated catch block
			}
			Kitchen k1=new Kitchen(recipes, r1);
			try {
				k1.cook();
			} catch (ChefException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	  
	  
	  @Test
		public void testchef() {
			// TODO Auto-generated method stub
			try {
				Chef c1=new Chef("test.txt");
			} catch (ChefException e) {
				// TODO Auto-generated catch block
				assertEquals("Structural error: Read unexpected serve amount. Expecting title", e.getMessage());
			}catch (Exception e) {
				// TODO: handle exception
			}
			
			try {
				Chef c1=new Chef("test1.txt");
				
				java.lang.reflect.Method m1=c1.getClass().getDeclaredMethod("progressToExpected", int.class);
				m1.setAccessible(true);
				String re=(String)m1.invoke(c1, 7);
				assertEquals(null, re);
				re=(String)m1.invoke(c1, 0);
				assertEquals("title", re);
				re=(String)m1.invoke(c1, 1);
				assertEquals("comments", re);
				re=(String)m1.invoke(c1, 2);
				assertEquals("ingredient list", re);
				re=(String)m1.invoke(c1, 3);
				assertEquals("cooking time", re);
				re=(String)m1.invoke(c1, 4);
				assertEquals("oven temperature", re);
				re=(String)m1.invoke(c1, 5);
				assertEquals("methods", re);
				
				
			} catch (ChefException e) {
				System.out.println(e.getMessage());
			}catch (Exception e) {
				// TODO: handle exception
			}
			
			try {
				FileWriter fw=new FileWriter(new File("filedata"));
				fw.write("start\n\nwe will start our cook\n\nIngredients.heaped\nkg\nl"
						+ "\n\nCooking time 3\n\nPre-heat oven 2 3\n\n"
						+ "Method.Refrigerate for 3 hours.");
				fw.close();
				Chef c1=new Chef("filedata");
				
				c1.bake();
				
				File frm=new File("filedata");
				frm.delete();
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (Exception e) {
				// TODO: handle exception
			}
			
			try{
					FileWriter fw=new FileWriter(new File("filedata"));
					fw.write("start\n\nwe will start our cook\n\nIIngredients.heaped\nkg\nl"
						+ "\n\nthrow");
					fw.close();
					Chef c1=new Chef("filedata");
					
					File frm=new File("filedata");
					frm.delete();
			}catch(ChefException e){
				assertEquals("Structural error: Read unexpected comments/title. Expecting ingredient list Hint:did you specify 'Ingredients.' "
						+ "above the ingredient list?", e.getMessage());
				File frm=new File("filedata");
				frm.delete();
			}
			catch(Exception e){
				
			}
			
			
			
			try{
				Chef c1=new Chef("test1.txt");
				java.lang.reflect.Method m2=c1.getClass().getDeclaredMethod("structHint", int.class);
				
				m2.setAccessible(true);
				String str=(String)m2.invoke(c1,3 );
				assertEquals("did you specify 'Methods.' above the m"
						+ "ethods?", str);
				
				String str1=(String)m2.invoke(c1,4 );
				assertEquals("no hint available", str1);
			
			}catch(Exception e){
				
			}
			
		}
	  
	  
	  @Test
	  public void testrecipe() {
		// TODO Auto-generated method stub
		  Recipe r1=new Recipe("start");
		  try {
			r1.setIngredients("Ingredients.heaped\nkg\n");
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  r1.setIngredientValue("kg", 1);
		  assertEquals(1, r1.getIngredientValue("kg"));
	}
	  
	 @Test
	public void test2() {
		// TODO Auto-generated method stub
		Recipe r1=new Recipe("recipe1");
		Recipe r2=new Recipe("recipe2");
		HashMap<String, Recipe> recipes=new HashMap<String, Recipe>();
		recipes.put("test1", r1);
		recipes.put("test2", r2);
		try {
			r1.setMethod("m7.Set aside.");
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Kitchen k1=new Kitchen(recipes, r1);

		try {
			java.lang.reflect.Method m1=k1.getClass().getDeclaredMethod("sameVerb", String.class,String.class);
			m1.setAccessible(true);
			assertEquals(false, m1.invoke(k1, null,null));
			assertEquals(false, m1.invoke(k1, "dsghs",null));
			assertEquals(true, m1.invoke(k1, "xd","xd"));
			assertEquals(false, m1.invoke(k1, "df","dshj"));
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		try {
			r1.setMethod("m1.Take a from refrigerator.Put e into the 3th mixing bowl.");
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Kitchen k2=new Kitchen(recipes, r1);
		
	}
}
