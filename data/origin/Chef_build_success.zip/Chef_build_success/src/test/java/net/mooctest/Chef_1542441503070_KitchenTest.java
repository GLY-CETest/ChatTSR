package net.mooctest;

import static org.junit.Assert.*;

import java.util.HashMap;

import net.mooctest.Ingredient.State;

import org.junit.Test;

public class Chef_1542441503070_KitchenTest {

	private static final State State = null;

	@Test(timeout = 4000)
	public void test() {
		Recipe recipe = new Recipe("");
		recipe.getTitle();
	}

	@Test(timeout = 4000)
	public void test0() throws ChefException {
		try {
			Recipe recipe = new Recipe("");
			recipe.getTitle();
			Ingredient a = new Ingredient("");
			a.dry();
			a.getAmount();
			a.getName();
			a.liquefy();
			a.setAmount(3);
			Component b = new Component(a);
			b.getState();
			b.getValue();
			b.liquefy();
			b.setState(a.getstate());
			b.setValue(3);
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}