package net.mooctest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Scanner;

import org.junit.Test;

public class Chef_1542441227584_KitchenTest {

	private void testWithFile(String prog, String expectedOutput) throws Exception {
        File file = new File("test");
        FileOutputStream fos = new FileOutputStream(file);
        fos.write(prog.getBytes());
        fos.flush();
        fos.close();

       
        
        try
        {Chef chef0 = new Chef("test");
        }catch(Exception e) {
        	System.out.println(e.toString());
        	assertTrue(e.toString().contains( expectedOutput));
        }
        
        
    }
	
	@Test(timeout = 4000)
	  public void testcc0()  throws Throwable  {
		testWithFile("ss..\nst\nIngredients\n","java.lang.NullPointerException");
		testWithFile("Ingredients\n3\n\n","java.lang.NullPointerException");
		testWithFile("Cooking time\n3\n\n","java.lang.NullPointerException");
		testWithFile("Pre-heat oven   3   4\n","java.lang.NullPointerException");
		testWithFile("Method\n3\n\n","java.lang.NullPointerException");
		testWithFile("Serves\n3\n\n","net.mooctest.ChefException: Structural error: Read unexpected serve amount. Expecting title");
		testWithFile("Cooking time\n3\n\n","java.lang.NullPointerException");
		testWithFile("Cooking time\n3\n\n","java.lang.NullPointerException");
		
		
	
	  }
	
	
	@Test(timeout = 4000)
	  public void testz0()  throws Throwable  {
	      Chef chef0 = null;
	      try {
	        chef0 = new Chef((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("java.io.File", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testz1()  throws Throwable  {
	      Chef chef0 = null;
	      try {
	        chef0 = new Chef("");
	        fail("Expecting exception: FileNotFoundException");
	      
	      } catch(Throwable e) {
	         //
	         // 
	         //
	         //("java.io.FileInputStream", e);
	      }
	  }
	  
	  @Test(timeout = 4000)
	  public void test0()  throws Throwable  {
	      ChefException chefException0 = new ChefException((-1), "");
	      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
	  }

	  @Test(timeout = 4000)
	  public void test1()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      ChefException chefException0 = new ChefException(0, recipe0, 0, "", "");
	      assertEquals("Method error, recipe , step 1:  ()", chefException0.getMessage());
	  }

	  @Test(timeout = 4000)
	  public void test2()  throws Throwable  {
	      String[] stringArray0 = new String[0];
	      ChefException chefException0 = new ChefException(0, stringArray0, "");
	      assertEquals("net.mooctest.ChefException: Ingredient wrongly formatted: '' ()", chefException0.toString());
	  }

	  @Test(timeout = 4000)
	  public void test3()  throws Throwable  {
	      Object[] objectArray0 = new Object[5];
	      Object object0 = new Object();
	      objectArray0[0] = object0;
	      // Undeclared exception!
	      try { 
	        ChefException.arrayToString(objectArray0, "");
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctest.ChefException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test4()  throws Throwable  {
	      Object[] objectArray0 = new Object[0];
	      String string0 = ChefException.arrayToString(objectArray0, "");
	      assertEquals("", string0);
	  }

	  @Test(timeout = 4000)
	  public void test5()  throws Throwable  {
	      ChefException chefException0 = new ChefException(1, "");
	      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
	  }

	  @Test(timeout = 4000)
	  public void test6()  throws Throwable  {
	      ChefException chefException0 = new ChefException(0, 0, "", "");
	      Object[] objectArray0 = new Object[5];
	      Object object0 = new Object();
	      objectArray0[0] = object0;
	      objectArray0[1] = (Object) "";
	      objectArray0[2] = (Object) chefException0;
	      objectArray0[3] = (Object) "";
	      objectArray0[4] = (Object) chefException0;
	      String string0 = ChefException.arrayToString(objectArray0, "");
	      assertNotNull(string0);
	  }

	  @Test(timeout = 4000)
	  public void test7()  throws Throwable  {
	      ChefException chefException0 = new ChefException(0, "");
	      assertEquals("net.mooctest.ChefException: Structural error: ", chefException0.toString());
	  }

	  @Test(timeout = 4000)
	  public void test8()  throws Throwable  {
	      ChefException chefException0 = null;
	      try {
	        chefException0 = new ChefException(0, (Recipe) null, 0, "", "");
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctest.ChefException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test9()  throws Throwable  {
	      ChefException chefException0 = null;
	      try {
	        chefException0 = new ChefException(0, (String[]) null, "");
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctest.ChefException", e);
	      }
	  }
	  
	  @Test(timeout = 4000)
	  public void test00()  throws Throwable  {
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(1, ingredient_State0);
	      int int0 = component0.getValue();
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void test01()  throws Throwable  {
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component((-1), ingredient_State0);
	      int int0 = component0.getValue();
	      assertEquals((-1), int0);
	  }

	  @Test(timeout = 4000)
	  public void test02()  throws Throwable  {
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(1, ingredient_State0);
	      Component component1 = component0.clone();
	      assertEquals(1, component1.getValue());
	      assertEquals(1, component0.getValue());
	  }

	  @Test(timeout = 4000)
	  public void test03()  throws Throwable  {
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component((-1), ingredient_State0);
	      Component component1 = component0.clone();
	      assertEquals((-1), component1.getValue());
	      assertEquals((-1), component0.getValue());
	  }

	  @Test(timeout = 4000)
	  public void test04()  throws Throwable  {
	      Component component0 = null;
	      try {
	        component0 = new Component((Ingredient) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctest.Component", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void test05()  throws Throwable  {
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(0, (Ingredient.State) null);
	      component0.setState(ingredient_State0);
	      assertEquals(0, component0.getValue());
	  }

	  @Test(timeout = 4000)
	  public void test06()  throws Throwable  {
	      Component component0 = new Component(0, (Ingredient.State) null);
	      int int0 = component0.getValue();
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void test07()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      Component component0 = new Component(ingredient0);
	      Ingredient.State ingredient_State1 = component0.getState();
	      assertSame(ingredient_State0, ingredient_State1);
	  }

	  @Test(timeout = 4000)
	  public void test08()  throws Throwable  {
	      Component component0 = new Component(0, (Ingredient.State) null);
	      component0.liquefy();
	      assertEquals(0, component0.getValue());
	  }

	  @Test(timeout = 4000)
	  public void test09()  throws Throwable  {
	      Component component0 = new Component(0, (Ingredient.State) null);
	      Component component1 = component0.clone();
	      assertEquals(0, component1.getValue());
	  }

	  @Test(timeout = 4000)
	  public void test10()  throws Throwable  {
	      Component component0 = new Component(0, (Ingredient.State) null);
	      component0.setValue(0);
	      assertEquals(0, component0.getValue());
	  }

	  @Test(timeout = 4000)
	  public void test11()  throws Throwable  {
	      Component component0 = new Component(0, (Ingredient.State) null);
	      component0.getState();
	      assertEquals(0, component0.getValue());
	  }
	  
	  @Test(timeout = 4000)
	  public void testcontainer00()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.push(component0);
	      ArrayList<Component> arrayList0 = container0.contents;
	      arrayList0.add(component0);
	      container0.push(component0);
	      container0.stir(1);
	      assertEquals(4, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer01()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.push(component0);
	      ArrayList<Component> arrayList0 = container0.contents;
	      arrayList0.add(component0);
	      container0.stir(2);
	      assertEquals(3, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer02()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      Integer integer0 = new Integer(1);
	      container0.stir((int) integer0);
	      assertEquals(1, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer03()  throws Throwable  {
	      Container container0 = new Container();
	      container0.stir((-1));
	      assertEquals(0, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer04()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.push(component0);
	      String string0 = container0.serve();
	      assertEquals("\u0000\u0000", string0);
	  }

	  @Test(timeout = 4000)
	  public void testcontainer05()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.push(component0);
	      Component component1 = container0.pop();
	      assertSame(component1, component0);
	  }

	  @Test(timeout = 4000)
	  public void testcontainer06()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      int int0 = container0.size();
	      assertEquals(1, int0);
	  }

	  @Test(timeout = 4000)
	  public void testcontainer07()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.pop();
	      String string0 = container0.serve();
	      assertEquals("", string0);
	  }

	  @Test(timeout = 4000)
	  public void testcontainer08()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(1, ingredient_State0);
	      container0.push(component0);
	      Component component1 = container0.pop();
	      assertSame(component1, component0);
	  }

	  @Test(timeout = 4000)
	  public void testcontainer09()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component((-1), ingredient_State0);
	      container0.push(component0);
	      Component component1 = container0.pop();
	      assertEquals((-1), component1.getValue());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer10()  throws Throwable  {
	      Container container0 = new Container();
	      container0.push((Component) null);
	      Component component0 = container0.peek();
	      assertNull(component0);
	  }

	  @Test(timeout = 4000)
	  public void testcontainer11()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      Component component1 = container0.peek();
	      assertEquals(0, component1.getValue());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer12()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(1, ingredient_State0);
	      container0.push(component0);
	      Component component1 = container0.peek();
	      assertEquals(1, component1.getValue());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer13()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component((-1), ingredient_State0);
	      container0.push(component0);
	      Component component1 = container0.peek();
	      assertEquals(Ingredient.State.Dry, component1.getState());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer14()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.stir(1);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer15()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.size();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer16()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.shuffle();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer17()  throws Throwable  {
	      Container container0 = new Container();
	      container0.push((Component) null);
	      // Undeclared exception!
	      try { 
	        container0.serve();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer18()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component((-1), ingredient_State0);
	      container0.push(component0);
	      // Undeclared exception!
	      try { 
	        container0.serve();
	        fail("Expecting exception: IllegalArgumentException");
	      
	      } catch(IllegalArgumentException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("java.lang.Character", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer19()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.push((Component) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer20()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.pop();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer21()  throws Throwable  {
	      Container container0 = new Container();
	      container0.contents = null;
	      // Undeclared exception!
	      try { 
	        container0.peek();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer22()  throws Throwable  {
	      Container container0 = new Container();
	      container0.push((Component) null);
	      // Undeclared exception!
	      try { 
	        container0.liquefy();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer23()  throws Throwable  {
	      Container container0 = new Container();
	      // Undeclared exception!
	      try { 
	        container0.combine((Container) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer24()  throws Throwable  {
	      Container container0 = null;
	      try {
	        container0 = new Container((Container) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer25()  throws Throwable  {
	      Container container0 = new Container();
	      container0.stir(1);
	      assertEquals(0, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer26()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      String string0 = container0.serve();
	      assertEquals("0 ", string0);
	  }

	  @Test(timeout = 4000)
	  public void testcontainer27()  throws Throwable  {
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      container0.liquefy();
	      assertEquals(1, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer28()  throws Throwable  {
	      Container container0 = new Container();
	      try { 
	        container0.pop();
	        fail("Expecting exception: ChefException");
	      
	      } catch(ChefException e) {
	         //
	         // Local error: Folded from empty container
	         //
	         //("net.mooctestcontainer.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer29()  throws Throwable  {
	      Container container0 = new Container();
	      // Undeclared exception!
	      try { 
	        container0.peek();
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testcontainer30()  throws Throwable  {
	      Container container0 = new Container();
	      int int0 = container0.size();
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void testcontainer31()  throws Throwable  {
	      Container container0 = new Container();
	      Container container1 = new Container(container0);
	      assertFalse(container1.equals((Object)container0));
	  }

	  @Test(timeout = 4000)
	  public void testcontainer32()  throws Throwable  {
	      Container container0 = new Container();
	      container0.clean();
	      assertEquals(0, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer33()  throws Throwable  {
	      Container container0 = new Container();
	      container0.shuffle();
	      assertEquals(0, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testcontainer34()  throws Throwable  {
	      Container container0 = new Container();
	      container0.push((Component) null);
	      Component component0 = container0.pop();
	      assertNull(component0);
	  }

	  @Test(timeout = 4000)
	  public void testcontainer35()  throws Throwable  {
	      Container container0 = new Container();
	      container0.combine(container0);
	      assertEquals(0, container0.size());
	  }
	  
	  @Test(timeout = 4000)
	  public void testingredient00()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
	      String string0 = ingredient0.getName();
	      assertNull(string0);
	  }

	 @Test(timeout = 4000)
	  public void testingredient01()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("y");
	      String string0 = ingredient0.getName();
	      assertEquals("y", string0);
	  }

	 @Test(timeout = 4000)
	  public void testingredient02()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("y");
	      ingredient0.setAmount(1);
	      int int0 = ingredient0.getAmount();
	      assertEquals(1, int0);
	  }

	 @Test(timeout = 4000)
	  public void testingredient03()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("L");
	      // Undeclared exception!
	      try { 
	        ingredient0.getAmount();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestingredient.Ingredient", e);
	      }
	  }

	 @Test(timeout = 4000)
	  public void testingredient04()  throws Throwable  {
	      Ingredient ingredient0 = null;
	      try {
	        ingredient0 = new Ingredient((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestingredient.Ingredient", e);
	      }
	  }

	 @Test(timeout = 4000)
	  public void testingredient05()  throws Throwable  {
	      Ingredient ingredient0 = null;
	      try {
	        ingredient0 = new Ingredient(" ");
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // 0
	         //
	         //("net.mooctestingredient.Ingredient", e);
	      }
	  }

	 @Test(timeout = 4000)
	  public void testingredient06()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("M e");
	      assertEquals("M e", ingredient0.getName());
	  }

	 @Test(timeout = 4000)
	  public void testingredient07()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("9 _");
	      assertEquals("_", ingredient0.getName());
	  }

	 @Test(timeout = 4000)
	  public void testingredient08()  throws Throwable  {
	      Ingredient ingredient0 = null;
	      try {
	        ingredient0 = new Ingredient("");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"\"
	         //
	         //("java.lang.NumberFormatException", e);
	      }
	  }

	 @Test(timeout = 4000)
	  public void testingredient09()  throws Throwable  {
	      Ingredient ingredient0 = new Ingredient("M");
	      ingredient0.setAmount((-1));
	      int int0 = ingredient0.getAmount();
	      assertEquals((-1), int0);
	  }

	 @Test(timeout = 4000)
	  public void testingredient10()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
	      ingredient0.liquefy();
	      assertEquals(Ingredient.State.Liquid, ingredient0.getstate());
	  }

	 @Test(timeout = 4000)
	  public void testingredient11()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
	      ingredient0.dry();
	      assertNull(ingredient0.getName());
	  }

	 @Test(timeout = 4000)
	  public void testingredient12()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      ingredient0.setState((Ingredient.State) null);
	      ingredient0.getstate();
	  }

	 @Test(timeout = 4000)
	  public void testingredient13()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      Ingredient.State ingredient_State1 = ingredient0.getstate();
	      assertSame(ingredient_State1, ingredient_State0);
	  }

	 @Test(timeout = 4000)
	  public void testingredient14()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
	      String string0 = ingredient0.getName();
	      assertEquals("", string0);
	  }

	 @Test(timeout = 4000)
	  public void testingredient15()  throws Throwable  {
	      Integer integer0 = new Integer(0);
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
	      int int0 = ingredient0.getAmount();
	      assertEquals(0, int0);
	  }
	 
	  @Test(timeout = 4000)
	  public void testkitchen0()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe((String) null);
	      recipe0.setMethod("Y");
	      Container[] containerArray0 = new Container[5];
	      Container container0 = new Container();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      containerArray0[0] = container0;
	      containerArray0[1] = container0;
	      containerArray0[2] = container0;
	      containerArray0[3] = containerArray0[0];
	      containerArray0[4] = containerArray0[0];
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
	      Container container1 = kitchen0.cook();
	      assertNotSame(container1, container0);
	  }

	  @Test(timeout = 4000)
	  public void testkitchen1()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe((String) null);
	      Recipe recipe1 = hashMap0.put((String) null, recipe0);
	      recipe0.setMethod("Y");
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
	      kitchen0.recipe = recipe1;
	      // Undeclared exception!
	      try { 
	        kitchen0.cook();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestkitchen.Kitchen", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testkitchen2()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe((String) null);
	      recipe0.setMethod("Y");
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
	      Container[] containerArray0 = new Container[0];
	      kitchen0.mixingbowls = containerArray0;
	      Container container0 = kitchen0.cook();
	      assertNull(container0);
	  }

	  @Test(timeout = 4000)
	  public void testkitchen3()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe((String) null);
	      recipe0.setMethod("Y");
	      Container[] containerArray0 = new Container[5];
	      Kitchen kitchen0 = null;
	      try {
	        kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestkitchen.Container", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testkitchen4()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("2");
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, (Container[]) null, (Container[]) null);
	      Container container0 = kitchen0.cook();
	      assertEquals(0, container0.size());
	  }

	  @Test(timeout = 4000)
	  public void testkitchen5()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe((String) null);
	      Kitchen kitchen0 = null;
	      try {
	        kitchen0 = new Kitchen(hashMap0, recipe0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestkitchen.Kitchen", e);
	      }
	  }
	  
	  @Test(timeout = 4000)
	  public void testme0()  throws Throwable  {
	      Method method0 = null;
	      try {
	        method0 = new Method((String) null, 0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctest.Method", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testme1()  throws Throwable  {
	      Method method0 = null;
	      try {
	        method0 = new Method("", 0);
	        fail("Expecting exception: ChefException");
	      
	      } catch(Throwable e) {
	         //
	         // Method error, step 1:  (Unsupported method found!)
	         //
	         //("net.mooctest.Method", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe00()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setIngredients("g");
	      // Undeclared exception!
	      try { 
	        recipe0.setIngredientValue("", 0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestrecipe.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe01()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setServes("q|7VCZ<1u");
	      assertEquals(1, recipe0.getServes());
	  }

	  @Test(timeout = 4000)
	  public void testrecipe02()  throws Throwable  {
	      Recipe recipe0 = new Recipe("g");
	      String string0 = recipe0.getTitle();
	      assertEquals("g", string0);
	  }

	  @Test(timeout = 4000)
	  public void testrecipe03()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      String string0 = recipe0.getTitle();
	      assertEquals("", string0);
	  }

	  @Test(timeout = 4000)
	  public void testrecipe04()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setServes("v5p9XOXa");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"\"
	         //
	         //("java.lang.NumberFormatException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe05()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setServes((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestrecipe.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe06()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setOvenTemp("   b");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"b\"
	         //
	         //("java.lang.NumberFormatException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe07()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setOvenTemp((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestrecipe.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe08()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setOvenTemp("");
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // 3
	         //
	         //("net.mooctestrecipe.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe09()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setMethod("");
	        fail("Expecting exception: NoSuchElementException");
	      
	      } catch(NoSuchElementException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("java.util.Scanner", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe10()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setMethod((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestrecipe.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe11()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setIngredients("");
	        fail("Expecting exception: NoSuchElementException");
	      
	      } catch(NoSuchElementException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("java.util.Scanner", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe12()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setIngredients((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("java.io.StringReader", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe13()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setCookingTime("  m");
	        fail("Expecting exception: NumberFormatException");
	      
	      } catch(NumberFormatException e) {
	         //
	         // For input string: \"m\"
	         //
	         //("java.lang.NumberFormatException", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe14()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setCookingTime((String) null);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestrecipe.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe15()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("[");
	      // Undeclared exception!
	      try { 
	        recipe0.getMethod(0);
	        fail("Expecting exception: IndexOutOfBoundsException");
	      
	      } catch(IndexOutOfBoundsException e) {
	         //
	         // Index: 0, Size: 0
	         //
	         //("java.util.ArrayList", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe16()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("m");
	      // Undeclared exception!
	      try { 
	        recipe0.getMethod((-1));
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe17()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("O");
	      ArrayList<Method> arrayList0 = recipe0.getMethods();
	      assertTrue(arrayList0.isEmpty());
	  }

	  @Test(timeout = 4000)
	  public void testrecipe18()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      try { 
	        recipe0.setMethod("V.A");
	        fail("Expecting exception: ChefException");
	      
	      } catch(ChefException e) {
	         //
	         // Method error, step 1: A. (Unsupported method found!)
	         //
	         //("net.mooctestrecipe.Method", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe19()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setIngredients(".");
	      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
	      assertEquals(0, hashMap0.size());
	  }

	  @Test(timeout = 4000)
	  public void testrecipe20()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.getMethod(0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestrecipe.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe21()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.setCookingTime("");
	        fail("Expecting exception: ArrayIndexOutOfBoundsException");
	      
	      } catch(ArrayIndexOutOfBoundsException e) {
	         //
	         // 2
	         //
	         //("net.mooctestrecipe.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe22()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
	      assertNull(hashMap0);
	  }

	  @Test(timeout = 4000)
	  public void testrecipe23()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      // Undeclared exception!
	      try { 
	        recipe0.setServes("");
	        fail("Expecting exception: StringIndexOutOfBoundsException");
	      
	      } catch(StringIndexOutOfBoundsException e) {
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe24()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      int int0 = recipe0.getServes();
	      assertEquals(0, int0);
	  }

	  @Test(timeout = 4000)
	  public void testrecipe25()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      ArrayList<Method> arrayList0 = recipe0.getMethods();
	      assertNull(arrayList0);
	  }

	  @Test(timeout = 4000)
	  public void testrecipe26()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      // Undeclared exception!
	      try { 
	        recipe0.getIngredientValue("");
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {
	         //
	         // no message in exception (getMessage() returned null)
	         //
	         //("net.mooctestrecipe.Recipe", e);
	      }
	  }

	  @Test(timeout = 4000)
	  public void testrecipe27()  throws Throwable  {
	      Recipe recipe0 = new Recipe((String) null);
	      String string0 = recipe0.getTitle();
	      assertNull(string0);
	  }

	  @Test(timeout = 4000)
	  public void testrecipe28()  throws Throwable  {
	      Recipe recipe0 = new Recipe("");
	      recipe0.setComments("");
	      assertEquals(0, recipe0.getServes());
	  }
}
