package net.mooctest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.junit.Test;

public class Chef_1542441510751_KitchenTest {

  @Test(timeout = 4000)
  public void test() throws Throwable{
	  try{
		  HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("weilegongchanzhuyishiye,qianjin3744732874^*@#*@&$$*");
	      Container[] containerArray0 = new Container[4];
	      Container container0 = new Container();
	      containerArray0[0] = container0;
	      containerArray0[1] = container0;
	      containerArray0[2] = container0;
	      recipe0.setMethod("s");
	      containerArray0[3] = container0;
	      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      containerArray0[2] = containerArray0[1];
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
	      Container container1 = kitchen0.cook();
	      assertEquals(1, container1.size());
	  }catch(ChefException e){
		  e.printStackTrace();
	  }catch(Exception e){
		  e.printStackTrace();
	  }
	  
      
  }
  
  /**
   * Kitchen
   */

  @Test(timeout = 4000)
  public void test0Kitchen()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Container[] containerArray0 = new Container[3];
      Container container0 = new Container();
      containerArray0[0] = container0;
      recipe0.setMethod("u");
      containerArray0[1] = container0;
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      containerArray0[2] = containerArray0[1];
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      Container container1 = kitchen0.cook();
      assertEquals(1, container1.size());
  }
  

  @Test(timeout = 4000)
  public void test1Kitchen()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Recipe recipe1 = new Recipe("");
      recipe0.setMethod("S");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.recipe = recipe1;
      // Undeclared exception!
      try { 
        kitchen0.cook();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
        
      }
  }

  @Test(timeout = 4000)
  public void test2Kitchen()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Container[] containerArray0 = new Container[3];
      Container container0 = new Container();
      containerArray0[0] = container0;
      recipe0.setMethod("u");
      containerArray0[1] = container0;
      containerArray0[2] = container0;
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      Container[] containerArray1 = new Container[0];
      kitchen0.mixingbowls = containerArray1;
      Container container1 = kitchen0.cook();
      assertNull(container1);
  }

  @Test(timeout = 4000)
  public void test3Kitchen()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Container[] containerArray0 = new Container[3];
      recipe0.setMethod("u");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test4Kitchen()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("u");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test5Kitchen()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }
  
  /**
   * Chef
   */
  
  @Test(timeout = 4000)
  public void test0Chef()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test1Chef()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef("");
        fail("Expecting exception: FileNotFoundException");
      
      } catch(Throwable e) {
       
      }
  }
  
  /**
   * Component
   */
  
  @Test(timeout = 4000)
  public void test00Com()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      int int0 = component0.getValue();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void test01Com()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      int int0 = component0.getValue();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void test02Com()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      Component component1 = component0.clone();
      assertEquals(1, component0.getValue());
      assertEquals(1, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test03Com()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      Component component1 = component0.clone();
      assertEquals((-1), component0.getValue());
      assertEquals((-1), component1.getValue());
  }

  @Test(timeout = 4000)
  public void test04Com()  throws Throwable  {
      Component component0 = null;
      try {
        component0 = new Component((Ingredient) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test05Com()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      component0.setState((Ingredient.State) null);
      component0.getState();
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void test06Com()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      component0.setState(ingredient_State0);
      assertEquals(Ingredient.State.Dry, component0.getState());
  }

  @Test(timeout = 4000)
  public void test07Com()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      int int0 = component0.getValue();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test08Com()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      component0.liquefy();
      assertEquals(Ingredient.State.Liquid, component0.getState());
  }

  @Test(timeout = 4000)
  public void test09Com()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      Component component1 = component0.clone();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void test10Com()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      component0.setValue(0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void test11Com()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      Ingredient.State ingredient_State1 = component0.getState();
      assertSame(ingredient_State1, ingredient_State0);
  }
  
  /**
   * Container
   */
  

  @Test(timeout = 4000)
  public void test00Con()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      container0.push(component0);
      container0.combine(container0);
      container0.stir(2);
      assertEquals(4, container0.size());
  }

  @Test(timeout = 4000)
  public void test01Con()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      container0.stir(1);
      assertEquals(1, container0.size());
  }

  @Test(timeout = 4000)
  public void test02Con()  throws Throwable  {
      Container container0 = new Container();
      container0.stir((-1));
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test03Con()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      container0.push(component0);
      String string0 = container0.serve();
      assertEquals("0 0 ", string0);
  }

  @Test(timeout = 4000)
  public void test04Con()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      container0.push(component0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertEquals(Ingredient.State.Liquid, component1.getState());
  }

  @Test(timeout = 4000)
  public void test05Con()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      int int0 = container0.size();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void test06Con()  throws Throwable  {
      Container container0 = new Container();
      String string0 = container0.serve();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test07Con()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.pop();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void test08Con()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertEquals(Ingredient.State.Dry, component1.getState());
  }

  @Test(timeout = 4000)
  public void test09Con()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertEquals(Ingredient.State.Liquid, component1.getState());
  }

  @Test(timeout = 4000)
  public void test10Con()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.peek();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void test11Con()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void test12Con()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void test13Con()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      container0.push(component0);
      Component component1 = container0.peek();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void test14Con()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.stir(1);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test15Con()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      ArrayList<Component> arrayList0 = container1.contents;
      container1.contents = arrayList0;
      container1.contents = null;
      // Undeclared exception!
      try { 
        container1.size();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
    	  
      }
         
  }

  @Test(timeout = 4000)
  public void test16Con()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.shuffle();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test17Con()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      arrayList0.add((Component) null);
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
    
      }
  }

  @Test(timeout = 4000)
  public void test18Con()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      component0.liquefy();
      container0.push(component0);
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test19Con()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      container0.contents = arrayList0;
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      container0.contents = null;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
      Component component0 = new Component(ingredient0);
      // Undeclared exception!
      try { 
        container0.push(component0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
        
      }
  }

  @Test(timeout = 4000)
  public void test20Con()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.combine((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test21Con()  throws Throwable  {
      Container container0 = null;
      try {
        container0 = new Container((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
       
      }
  }

  @Test(timeout = 4000)
  public void test22Con()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      container0.push(component0);
      container0.stir(1);
      assertEquals(2, container0.size());
  }

  @Test(timeout = 4000)
  public void test23Con()  throws Throwable  {
      Container container0 = new Container();
      container0.stir(1);
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test24Con()  throws Throwable  {
      Container container0 = new Container();
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      container0.push(component0);
      container0.liquefy();
      String string0 = container0.serve();
      assertEquals("\u0000", string0);
  }

  @Test(timeout = 4000)
  public void test25Con()  throws Throwable  {
      Container container0 = new Container();
      try { 
        container0.pop();
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test26Con()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.peek();
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test27Con()  throws Throwable  {
      Container container0 = new Container();
      int int0 = container0.size();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test28Con()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      container1.contents = null;
      // Undeclared exception!
      try { 
        container1.pop();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test29Con()  throws Throwable  {
      Container container0 = new Container();
      container0.clean();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test30Con()  throws Throwable  {
      Container container0 = new Container();
      container0.shuffle();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void test31Con()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      // Undeclared exception!
      try { 
        container0.liquefy();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
    	  e.printStackTrace();

      }
  }
  
  /**
   * ChefException
   */
  
  @Test(timeout = 4000)
  public void test00ChefException()  throws Throwable  {
      Object[] objectArray0 = new Object[3];
      Object object0 = new Object();
      objectArray0[0] = object0;
      objectArray0[1] = objectArray0[0];
      // Undeclared exception!
      try { 
        ChefException.arrayToString(objectArray0, "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test01ChefException()  throws Throwable  {
      ChefException chefException0 = new ChefException(1, "");
      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void test02ChefException()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, 0, "", "");
      assertEquals("Method error, step 1:  ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test03ChefException()  throws Throwable  {
      Object[] objectArray0 = new Object[2];
      objectArray0[0] = (Object) "";
      objectArray0[1] = objectArray0[0];
      String string0 = ChefException.arrayToString(objectArray0, "s");
      assertEquals("s", string0);
  }

  @Test(timeout = 4000)
  public void test04ChefException()  throws Throwable  {
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, (String[]) null, "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test05ChefException()  throws Throwable  {
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, (Recipe) null, 0, "", "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test06ChefException()  throws Throwable  {
      Object[] objectArray0 = new Object[2];
      objectArray0[0] = (Object) "";
      objectArray0[1] = objectArray0[0];
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test07ChefException()  throws Throwable  {
      ChefException chefException0 = new ChefException((-1), "");
      assertEquals("Local error: ", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test08ChefException()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "");
      Object[] objectArray0 = new Object[4];
      objectArray0[0] = (Object) chefException0;
      // Undeclared exception!
      try { 
        ChefException.arrayToString(objectArray0, "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test09ChefException()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ChefException chefException0 = new ChefException(0, recipe0, 0, "", "");
      assertEquals("Method error, recipe , step 1:  ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void test10ChefException()  throws Throwable  {
      String[] stringArray0 = new String[0];
      ChefException chefException0 = new ChefException(0, stringArray0, "");
      assertEquals("net.mooctest.ChefException: Ingredient wrongly formatted: '' ()", chefException0.toString());
  }
  
  /**
   * Ingredient
   */
  
  @Test(timeout = 4000)
  public void test00Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient((Integer) null, (Ingredient.State) null, (String) null);
      ingredient0.getstate();
  }

  @Test(timeout = 4000)
  public void test01Ingredient()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
      String string0 = ingredient0.getName();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void test02Ingredient()  throws Throwable  {
      Integer integer0 = Integer.valueOf(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      String string0 = ingredient0.getName();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test03Ingredient()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      int int0 = ingredient0.getAmount();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test04Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("h");
      ingredient0.setAmount((-1));
      int int0 = ingredient0.getAmount();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void test05Ingredient()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test06Ingredient()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("1");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
        
      }
  }

  @Test(timeout = 4000)
  public void test07Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c b");
      assertEquals("c b", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void test08Ingredient()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("9 l");
        fail("Expecting exception: ChefException");
      
      } catch(Throwable e) {
        
      }
  }

  @Test(timeout = 4000)
  public void test09Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("9 _");
      ingredient0.getAmount();
      assertEquals("_", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void test10Ingredient()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test11Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      ingredient0.liquefy();
      assertEquals("c", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void test12Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      ingredient0.dry();
      assertEquals(Ingredient.State.Dry, ingredient0.getstate());
  }

  @Test(timeout = 4000)
  public void test13Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      ingredient0.setState(ingredient_State0);
      assertEquals(Ingredient.State.Dry, ingredient0.getstate());
  }

  @Test(timeout = 4000)
  public void test14Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      Ingredient.State ingredient_State0 = ingredient0.getstate();
      assertEquals(Ingredient.State.Dry, ingredient_State0);
  }

  @Test(timeout = 4000)
  public void test15Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("c");
      String string0 = ingredient0.getName();
      assertEquals("c", string0);
  }

  @Test(timeout = 4000)
  public void test16Ingredient()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("b");
      // Undeclared exception!
      try { 
        ingredient0.getAmount();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         //verifyException("net.mooctest.Ingredient", e);
      }
  }
  
  /**
   * Method
   */
  @Test(timeout = 4000)
  public void test0Method()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method((String) null, 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
       
      }
  }

  @Test(timeout = 4000)
  public void test1Method()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method("", 0);
        fail("Expecting exception: ChefException");
      
      } catch(Throwable e) {
         
      }
  }
  
  /**
   * Recipe
   */
  
  @Test(timeout = 4000)
  public void test00Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("V");
      // Undeclared exception!
      try { 
        recipe0.setIngredientValue("", 0);
        fail("Expecting exception: NullPointerException");
        recipe0.setComments("feudsiafjf^*&#");
        recipe0.setCookingTime("73284");
        recipe0.setServes("318734");
        
        String str="^Stir( the( (\\d+)(nd|rd|th|st))? mixing bowl)? for (\\d+) minutes.$";
        Method m = new Method(str,5);
        recipe0.setMethod(m.toString());
        
        
      
      } catch(NullPointerException e) {
      }catch(Exception e){
    	  e.printStackTrace();
      }
  }

  @Test(timeout = 4000)
  public void test01Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      String string0 = recipe0.getTitle();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void test02Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("V");
      String string0 = recipe0.getTitle();
      assertEquals("V", string0);
  }

  @Test(timeout = 4000)
  public void test03Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("U");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertEquals(0, arrayList0.size());
  }

  @Test(timeout = 4000)
  public void test04Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("i");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertTrue(hashMap0.isEmpty());
  }

  @Test(timeout = 4000)
  public void test05Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes("");
        fail("Expecting exception: StringIndexOutOfBoundsException");
      
      } catch(StringIndexOutOfBoundsException e) {
      }
  }

  @Test(timeout = 4000)
  public void test06Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
       
      }
  }

  @Test(timeout = 4000)
  public void test07Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("   m");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test08Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
        
      }
  }

  @Test(timeout = 4000)
  public void test09Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test10Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setMethod((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test11Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setIngredients("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test12Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setIngredients((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test13Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("  r");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
        
      }
  }

  @Test(timeout = 4000)
  public void test14Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setCookingTime((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test15Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("U");
      // Undeclared exception!
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: IndexOutOfBoundsException");
      
      } catch(IndexOutOfBoundsException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test16Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setMethod("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
        
      }
  }

  @Test(timeout = 4000)
  public void test17Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setMethod("c.n");
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test18Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test19Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
        
      }
  }

  @Test(timeout = 4000)
  public void test20Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertNull(hashMap0);
  }

  @Test(timeout = 4000)
  public void test21Recipe()  throws Throwable  {
      String string0 = "2\\uE.@b_xsRy*YBYz";
      Recipe recipe0 = new Recipe(string0);
      // Undeclared exception!
      try { 
        recipe0.setServes(string0);
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test22Recipe()  throws Throwable  {
      String string0 = "2\\uE.@b_xsRy*YBYz";
      Recipe recipe0 = new Recipe(string0);
      int int0 = recipe0.getServes();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test23Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertNull(arrayList0);
  }

  @Test(timeout = 4000)
  public void test24Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getIngredientValue("");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         
      }
  }

  @Test(timeout = 4000)
  public void test25Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      String string0 = recipe0.getTitle();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test26Recipe()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setComments("");
      assertEquals(0, recipe0.getServes());
  }
  
  /**
   * mutation-ChefException
   */
  
  @Test(timeout = 4000)
  public void test0ChefExceptionMT()  throws Throwable  {
      String[] stringArray0 = new String[0];
      ChefException chefException0 = new ChefException(1147, stringArray0, "`DW2w<*-X`)e{|H.r.");
      Object[] objectArray0 = new Object[2];
      objectArray0[0] = (Object) chefException0;
      objectArray0[1] = (Object) "`DW2w<*-X`)e{|H.r.";
      String string0 = ChefException.arrayToString(objectArray0, "`DW2w<*-X`)e{|H.r.");
      assertNotNull(string0);
  }

  @Test(timeout = 4000)
  public void test1ChefExceptionMT()  throws Throwable  {
      ChefException chefException0 = new ChefException(2956, ":6<#%\"[-9J");
      assertEquals(2, ChefException.INGREDIENT);
  }

  @Test(timeout = 4000)
  public void test2ChefExceptionMT()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "NAKO");
      assertEquals(0, ChefException.STRUCTURAL);
  }

  @Test(timeout = 4000)
  public void test3ChefExceptionMT()  throws Throwable  {
      ChefException chefException0 = new ChefException((-77), "6<<#%\"[-9J");
      assertEquals(3, ChefException.METHOD);
  }
  
  /**
   * mutation-Ingredient
   */
  
  @Test(timeout = 4000)
  public void test0IngredientMT()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("5k_lU:>E,q3`x$_ ((P");
      ingredient0.setAmount((-2148));
      assertEquals((-2148), ingredient0.getAmount());
      assertEquals("5k_lU:>E,q3`x$_ ((P", ingredient0.getName());
  }
  
  /**
   * mutation-Recipe
   */
  @Test(timeout = 4000)
  public void test0RecipeMT()  throws Throwable  {
      Recipe recipe0 = new Recipe("' (");
      int int0 = recipe0.getServes();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test1RecipeMT()  throws Throwable  {
      Recipe recipe0 = new Recipe("NqFM'yxv");
      recipe0.setIngredients("NqFM'yxv");
      assertEquals(0, recipe0.getServes());
  }
  

  @Test(timeout = 4000)
  public void test0fdhusfMT()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "Mg EM r[Q9x");
      Object[] objectArray0 = new Object[4];
      objectArray0[0] = (Object) chefException0;
      objectArray0[1] = (Object) chefException0;
      objectArray0[2] = (Object) "Mg EM r[Q9x";
      objectArray0[3] = (Object) "Mg EM r[Q9x";
      String string0 = ChefException.arrayToString(objectArray0, "Mg EM r[Q9x");
      assertNotNull(string0);
  }

  @Test(timeout = 4000)
  public void test1fdhusfMT()  throws Throwable  {
      ChefException chefException0 = new ChefException((-101), "");
      assertEquals(3, ChefException.METHOD);
  }

  @Test(timeout = 4000)
  public void test2fdhusfMT()  throws Throwable  {
      ChefException chefException0 = new ChefException(2871, "");
      assertEquals(3, ChefException.METHOD);
  }

  @Test(timeout = 4000)
  public void test3fdhusfMT()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "Mg EM r[Q9x");
      Throwable[] throwableArray0 = chefException0.getSuppressed();
      String string0 = ChefException.arrayToString(throwableArray0, "Mg EM r[Q9x");
      assertEquals("", string0);
  }
  
  
}
