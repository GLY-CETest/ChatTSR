package net.mooctest;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Test;

public class Chef_1542441648242_KitchenTest {

  @Test(timeout = 4000)
  public void test() {
    Recipe recipe = new Recipe("");
      
    try {
      Method method1 = new Method("Take A from refrigerator.",2);
      Method method2 = new Method("Put A into the 1st mixing bowl.",2);
      Method method3 = new Method("Add dry ingredients to 1st mixing bowl.",2);
      Method method4 = new Method("Add A to 1st mixing bowl.",2);
      Method method5 = new Method("Liquefy contents of the 1st mixing bowl.",2);
      Method method6 = new Method("Liquefy A.",2);
      Method method11 = new Method("Stir the 1st mixing bowl for 3 minutes.",2);
      Method method7 = new Method("Stir A into the 1st mixing bowl.",2);
      Method method8 = new Method("Mix the 1st mixing bowl well.",2);
      Method method9 = new Method("Clean 1st mixing bowl.",2);
      Method method10 = new Method("Set aside.",2);
      Method method12 = new Method("Refrigerate for 1 hours.",2);
      Method method13 = new Method("Serve with S.",2);
      Method method14 = new Method("Clean 1st mixing bowl.",2);
      Method method15 = new Method("Set aside.",2);
    } catch (ChefException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    //Component 一个实体类
    //Container--Component的容器 ArrayList<Component>
    //Recipe 有一大堆的set get方法
    try {
      Ingredient ingredient = new Ingredient("1 2 12 123");
      Ingredient ingredient2 = new Ingredient("1heaped 2 12 123");
      Ingredient ingredient3 = new Ingredient(2,Ingredient.State.Dry,"ss");
      ingredient3.setAmount(0);
      ingredient3.setState(Ingredient.State.Dry);
      assertEquals(0,ingredient3.getAmount());
      assertEquals("ss",ingredient3.getName());
      assertEquals(Ingredient.State.Dry,ingredient3.getstate());
      ingredient3.liquefy();
      assertEquals(Ingredient.State.Liquid,ingredient3.getstate());
      ingredient3.dry();
      assertEquals(Ingredient.State.Dry,ingredient3.getstate());
    } catch (ChefException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
    String path = "src\\test\\resources\\demo.txt";
    try {
      Chef chef= new Chef(path);
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    Component component1 = new Component(2,Ingredient.State.Dry);
    component1.setState(Ingredient.State.Dry);
    component1.setValue(3);
    assertEquals(3,component1.getValue());
    assertEquals(Ingredient.State.Dry,component1.getState());
    Component component2 = component1.clone();
    component1.liquefy();
    assertEquals(3,component2.getValue());
    assertEquals(Ingredient.State.Liquid,component1.getState());
    try {
      Component component3 = new Component(new Ingredient("1 2 12 123"));
    } catch (ChefException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    Container container = new Container();
    container.push(component1);
    container.push(component2);
    assertEquals(2,container.size());
    try {
      container.pop();
      assertEquals(1,container.size());
      Component com1 = container.peek();
      assertEquals(3,com1.getValue());
      container.liquefy();
      container.shuffle();
      container.push(new Component(2, Ingredient.State.Dry));
      container.stir(2);
      container.serve();
      container.combine(container);
      assertEquals(4,container.size());
      container.clean();
      assertEquals(0,container.size());
    } catch (ChefException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
    
    Recipe recipe1 = new Recipe("Recipe");
    recipe1.setComments("comment");
    //recipe1.
    try {
      recipe1.setIngredients("1\\n2\\n3");
      //recipe1.setIngredientValue("0", 5);
      assertEquals(0,recipe1.getServes());
      //assertEquals("{}",recipe1.getIngredients());
      //assertEquals(3,recipe1.getIngredientValue(s));
      assertEquals(null,recipe1.getMethods());
      assertEquals(0,recipe1.getServes());
      assertEquals("Recipe",recipe1.getTitle());
    } catch (ChefException e) {
      // TODO Auto-generated catch block
      e.printStackTrace(); 
    }
    
  }
}
