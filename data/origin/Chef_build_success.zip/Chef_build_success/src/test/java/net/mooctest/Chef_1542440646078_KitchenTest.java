package net.mooctest;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.Assert.fail;

import java.util.HashMap;

public class Chef_1542440646078_KitchenTest {
	public enum State {
		Dry, Liquid
	}

	private <T> void a(T a, T b) {
        assertEquals(a, b);
    }
    private <T> void p(T x) {
        System.out.println(x);
    }
  @Test(timeout = 4000)
  public void test() throws Exception{
      Recipe r1 = new Recipe("");
      Recipe r2=new Recipe("recipe");
      r1.setIngredients("fsdf\nfsdadfasdf\ndsfasd"); //a-in
      r1.setComments("wert");
      try{
    	  r1.setMethod("Method\\.abc");
      }catch(Exception e){
    	  
      }
      r1.setCookingTime("123 123 123");
      r1.setOvenTemp("123 123 123 123");
      r1.setOvenTemp("gas mark 123 123");
      r1.setServes("Serves 123");
      try{
    	  r1.setServes("Serves recipe");
    	  r1.setServes("recipe recipe");
      }catch(Exception e){
    	  
      }
      a(12,r1.getServes());
      a("",r1.getTitle());
      try{
    	  a(12,r1.getIngredientValue("123"));
    	  r1.setIngredientValue("123", 1);
      }catch(Exception e){
    	  
      }
      Recipe r4 = new Recipe("");
      r4.setMethod("Method\\. Take c from refrigerator.");
      r4.getMethod(0);
      r4.setOvenTemp("gas mark gas 1 gas mark"); 
      r4.setIngredients("123\n123\123");
      Recipe r3=new Recipe("123");
      r3.setIngredients("1 2 3\n4 5 6\n7 8 9");
      
      
      
      
      Ingredient i1=new Ingredient(1,null,"123");//a
      /*Ingredient i2=new Ingredient(2,null,"123 heaped|level");
      Ingredient i3=new Ingredient(1,null,"pinch?");
      Ingredient i4=new Ingredient(1,null,"dash");
      Ingredient i5=new Ingredient(1,null,"heaped");
      Ingredient i6=new Ingredient(1,null,"heaped");*/

      
      
      HashMap<String, Recipe> hsp1=new HashMap<String, Recipe>();
      hsp1.put("1",r1);
      hsp1.put("2",r2);
      hsp1.put("3",r3);
      Kitchen k1=new Kitchen(hsp1,r1);
      Kitchen k2=new Kitchen(hsp1,r4);
      k1.cook();
      try{
    	  k2.cook();
      }catch(Exception e){
    	  
      }
      
      
      
      ChefException ce1=new ChefException(0,"123");
      String[] ss1={"1","2"};
      ChefException ce2=new ChefException(0,ss1,"123");
      ChefException ce3=new ChefException(0,r1,1,"1","2");
      
      Component co1=new Component(1,null);
      Component co2=new Component(i1);
      co1.setValue(1);
      a(1,co1.getValue());
      co1.setState(null);
      a(null,co1.getState());
      co1.clone();//a
      co1.liquefy();
      
      Method m1=new Method("Take c from refrigerator.",17);
      Method m2=new Method("Put c into 12nd mixing bowl.",17);
      Method m3=new Method("Add dry ingredients to 3nd mixing bowl.",17);
      Method m4=new Method("Add c to 2nd mixing bowl.",17);
      Method m5=new Method("Liquefy contents of the 2nd mixing bowl.",17);
      Method m6=new Method("Liquefy c.",17);
      Method m7=new Method("Stir the 2nd mixing bowl for 5 minutes.",17);
      Method m8=new Method("Stir c into the 2nd mixing bowl.",17);
      Method m9=new Method("Mix the 2nd mixing bowl well.",17);
      Method m10=new Method("Clean 2nd mixing bowl.",17);
      Method m11=new Method("Pour contents of the 2nd mixing bowl into the 2nd baking dish.",17);
      Method m12=new Method("Set aside.",17);
      Method m13=new Method("Refrigerate for 2 hours.",17);
      Method m14=new Method("Suggestion: .",17);
      Method m15=new Method("c the c until c.",17);
      Method m16=new Method("Set aside.",17);
      Method m17=new Method("c the c.",17);
      Method m183=new Method("Serve with c.",17);
      
      Method m21=new Method("Fold c into 12nd mixing bowl.",17);
      Method m22=new Method("Fold c into mixing bowl.",17);
      Method m31=new Method("Add dry ingredients to mixing bowl.",17);
      Method m41=new Method("Remove c to 2nd mixing bowl.",17);
      Method m42=new Method("Combine c to 2nd mixing bowl.",17);
      Method m43=new Method("Divide c to 2nd mixing bowl.",17);
      Method m44=new Method("Divide c to mixing bowl.",17);
      Method m51=new Method("Liquefy contents of the mixing bowl.",17);
      Method m71=new Method("Stir the mixing bowl for 5 minutes.",17);
      Method m81=new Method("Stir c into the mixing bowl.",17);
      Method m91=new Method("Mix the mixing bowl well.",17);
      Method m101=new Method("Clean mixing bowl.",17);
      Method m111=new Method("Pour contents of the mixing bowl into the 2nd baking dish.",17);
      Method m112=new Method("Pour contents of the 2nd mixing bowl into the baking dish.",17);
      try{
    	  Method m131=new Method("Refrigerate for hours.",17);
      }catch(Exception e){
    	  
      }
      
      try{
    	  Chef ch1=new Chef("demo1.txt");
      }catch(Exception e){
    	  
      }
      try{
    	  Chef ch2=new Chef("demo2.txt");
      }catch(Exception e){
    	  
      }
      try{
    	  Chef ch3=new Chef("demo3.txt");
      }catch(Exception e){
    	  
      }
      try{
    	  Chef ch4=new Chef("demo4.txt");
      }catch(Exception e){
    	  
      }
      try{
    	  Chef ch5=new Chef("demo5.txt");
      }catch(Exception e){
    	  
      }
      try{
    	  Chef ch6=new Chef("demo6.txt");
      }catch(Exception e){
    	  
      }
      
      Container con1=new Container();
      Container con2=new Container(con1);
      con1.push(co1);
      con1.peek();
      con1.pop();
      a(0,con1.size());
      con1.combine(con2);
      con1.liquefy();
      con1.clean();
      a("",con1.serve());
      con1.shuffle();
      con1.stir(1);
      
  }
}
