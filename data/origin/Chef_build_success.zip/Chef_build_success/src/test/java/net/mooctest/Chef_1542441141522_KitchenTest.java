package net.mooctest;

import junit.framework.Assert;

import org.junit.Test;

public class Chef_1542441141522_KitchenTest {

  @Test(timeout = 4000)
  public void test() throws Exception{
      Recipe recipe = new Recipe("");
      String m[]={"红烧","清蒸"};
      String t[]={};
      try {
		recipe.setIngredients("苹果\n白菜\n蘑菇\n香菜");
		recipe.setComments("清蒸");
		Assert.assertEquals("", recipe.getTitle());
		recipe.setCookingTime("1  3  4");
		recipe.setOvenTemp("40 50 60 70 80 gas mark 6 546 65 643 643");//
		Assert.assertEquals(0,recipe.getServes());
		
	    ChefException chef=new ChefException(1,"txt");
	    new ChefException(1,m,"错误");
	    new ChefException(1,t,"错误");
	    new ChefException(1,2,"红烧","错误");
	    new ChefException(1,recipe,2,"红烧","错误");
	   
	    Ingredient ing=new Ingredient("小菇  青菜");
	    ing.setAmount(3);;
	    ing.liquefy();
	    ing.dry();
	    
	    Component pent=new Component(ing);
	    pent.getValue();
	    pent.setValue(5);
	    pent.setState(null);
	    pent.clone();
	    pent.liquefy();
	  
	    Container con=new Container();
	    con.push(pent);
	    con.combine(new Container());
	    con.pop();
	    con.size();
	    con.liquefy();
	    con.clean();
	    con.serve();
	    
	   } catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
}
