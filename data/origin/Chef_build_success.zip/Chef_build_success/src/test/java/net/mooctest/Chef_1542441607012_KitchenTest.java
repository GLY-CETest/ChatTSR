package net.mooctest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Scanner;

import org.junit.Test;

public class Chef_1542441607012_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
  }
  
  @Test(timeout = 4000)
  public void testa0()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testa1()  throws Throwable  {
      Chef chef0 = null;
      try {
        chef0 = new Chef("");
        fail("Expecting exception: FileNotFoundException");
      
      } catch(Throwable e) {
         //
         // 
      }
  }
  
  @Test(timeout = 4000)
  public void testb00()  throws Throwable  {
      ChefException chefException0 = new ChefException((-1), "");
      assertEquals("Local error: ", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void testb01()  throws Throwable  {
      String[] stringArray0 = new String[0];
      ChefException chefException0 = new ChefException(0, stringArray0, (String) null);
      assertEquals("Ingredient wrongly formatted: '' (null)", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void testb02()  throws Throwable  {
      // Undeclared exception!
      try { 
        ChefException.arrayToString((Object[]) null, (String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testb03()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ChefException chefException0 = new ChefException(0, recipe0, 0, "", "");
      assertEquals("Method error, recipe , step 1:  ()", chefException0.getMessage());
  }

  @Test(timeout = 4000)
  public void testb04()  throws Throwable  {
      String[] stringArray0 = new String[1];
      stringArray0[0] = "";
      ChefException chefException0 = new ChefException(0, stringArray0, "");
      assertEquals("net.mooctest.ChefException: Ingredient wrongly formatted: '' ()", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void testb05()  throws Throwable  {
      Object[] objectArray0 = new Object[0];
      String string0 = ChefException.arrayToString(objectArray0, "");
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void testb06()  throws Throwable  {
      ChefException chefException0 = new ChefException(1, "");
      assertEquals("net.mooctest.ChefException: Local error: ", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void testb07()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, 0, "", "");
      assertEquals("net.mooctest.ChefException: Method error, step 1:  ()", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void testb08()  throws Throwable  {
      ChefException chefException0 = new ChefException(0, "");
      StackTraceElement[] stackTraceElementArray0 = chefException0.getStackTrace();
      ChefException.arrayToString(stackTraceElementArray0, "");
      //  // Unstable assertion: assertEquals("Structural error: ", chefException0.getMessage());
      //  // Unstable assertion: assertEquals(14, stackTraceElementArray0.length);
      //  // Unstable assertion: assertEquals("net.mooctest.ChefException: Structural error: ", chefException0.toString());
  }

  @Test(timeout = 4000)
  public void testb09()  throws Throwable  {
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, (Recipe) null, 0, "", "");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testb10()  throws Throwable  {
      String[] stringArray0 = new String[21];
      ChefException chefException0 = null;
      try {
        chefException0 = new ChefException(0, stringArray0, stringArray0[0]);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }
  
  @Test(timeout = 4000)
  public void testc00()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      int int0 = component0.getValue();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void testc01()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      int int0 = component0.getValue();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void testc02()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
      Component component0 = new Component(ingredient0);
      component0.getState();
  }

  @Test(timeout = 4000)
  public void testc03()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(1, ingredient_State0);
      Component component1 = component0.clone();
      assertEquals(1, component1.getValue());
      assertEquals(1, component0.getValue());
  }

  @Test(timeout = 4000)
  public void testc04()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component((-1), ingredient_State0);
      Component component1 = component0.clone();
      assertEquals((-1), component1.getValue());
      assertEquals((-1), component0.getValue());
  }

  @Test(timeout = 4000)
  public void testc05()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("R");
      Component component0 = null;
      try {
        component0 = new Component(ingredient0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testc06()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      component0.setState(ingredient_State0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void testc07()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      int int0 = component0.getValue();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void testc08()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      component0.liquefy();
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void testc09()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      Component component1 = component0.clone();
      assertEquals(0, component1.getValue());
  }

  @Test(timeout = 4000)
  public void testc10()  throws Throwable  {
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      component0.setValue(0);
      assertEquals(0, component0.getValue());
  }

  @Test(timeout = 4000)
  public void testc11()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      Component component0 = new Component(ingredient0);
      Ingredient.State ingredient_State1 = component0.getState();
      assertSame(ingredient_State1, ingredient_State0);
  }
  
  @Test(timeout = 4000)
  public void testd00()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      container0.push((Component) null);
      container0.combine(container0);
      container0.stir(1);
      assertEquals(4, container0.size());
  }

  @Test(timeout = 4000)
  public void testd01()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      container0.stir(2);
      assertEquals(3, container0.size());
  }

  @Test(timeout = 4000)
  public void testd02()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      container0.stir(1);
      assertEquals(1, container0.size());
  }

  @Test(timeout = 4000)
  public void testd03()  throws Throwable  {
      Container container0 = new Container();
      container0.stir((-1));
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void testd04()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      String string0 = container0.serve();
      assertEquals("0 0 ", string0);
  }

  @Test(timeout = 4000)
  public void testd05()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      arrayList0.add(component0);
      Component component1 = container0.pop();
      assertEquals(Ingredient.State.Dry, component1.getState());
  }

  @Test(timeout = 4000)
  public void testd06()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      int int0 = container0.size();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void testd07()  throws Throwable  {
      Container container0 = new Container();
      String string0 = container0.serve();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void testd08()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.pop();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void testd09()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      arrayList0.add(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void testd10()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component((-1), ingredient_State0);
      container0.push(component0);
      Component component1 = container0.pop();
      assertSame(component1, component0);
  }

  @Test(timeout = 4000)
  public void testd11()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      Component component0 = container0.peek();
      assertNull(component0);
  }

  @Test(timeout = 4000)
  public void testd12()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      Component component1 = container0.peek();
      assertEquals(Ingredient.State.Liquid, component1.getState());
  }

  @Test(timeout = 4000)
  public void testd13()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = new ArrayList<Component>();
      container0.contents = arrayList0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(1, ingredient_State0);
      arrayList0.add(component0);
      Component component1 = container0.peek();
      assertEquals(Ingredient.State.Dry, component1.getState());
  }

  @Test(timeout = 4000)
  public void testd14()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.setValue((-1));
      container0.push(component0);
      Component component1 = container0.peek();
      assertEquals((-1), component1.getValue());
  }

  @Test(timeout = 4000)
  public void testd15()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.stir(1);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd16()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.size();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd17()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.shuffle();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd18()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd19()  throws Throwable  {
      Container container0 = new Container();
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      component0.setValue((-1));
      container0.push(component0);
      // Undeclared exception!
      try { 
        container0.serve();
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd20()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Component component0 = new Component(0, ingredient_State0);
      // Undeclared exception!
      try { 
        container0.push(component0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd21()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.pop();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd22()  throws Throwable  {
      Container container0 = new Container();
      container0.contents = null;
      // Undeclared exception!
      try { 
        container0.peek();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd23()  throws Throwable  {
      Container container0 = null;
      try {
        container0 = new Container((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd24()  throws Throwable  {
      Container container0 = new Container();
      container0.stir(1);
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void testd25()  throws Throwable  {
      Container container0 = new Container();
      ArrayList<Component> arrayList0 = container0.contents;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      arrayList0.add(component0);
      container0.liquefy();
      String string0 = container0.serve();
      assertEquals("\u0000", string0);
  }

  @Test(timeout = 4000)
  public void testd26()  throws Throwable  {
      Container container0 = new Container();
      try { 
        container0.pop();
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         //
         // Local error: Folded from empty container
         //
      }
  }

  @Test(timeout = 4000)
  public void testd27()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.peek();
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd28()  throws Throwable  {
      Container container0 = new Container();
      int int0 = container0.size();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void testd29()  throws Throwable  {
      Container container0 = new Container();
      Container container1 = new Container(container0);
      assertFalse(container1.equals((Object)container0));
  }

  @Test(timeout = 4000)
  public void testd30()  throws Throwable  {
      Container container0 = new Container();
      container0.clean();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void testd31()  throws Throwable  {
      Container container0 = new Container();
      container0.shuffle();
      assertEquals(0, container0.size());
  }

  @Test(timeout = 4000)
  public void testd32()  throws Throwable  {
      Container container0 = new Container();
      container0.push((Component) null);
      // Undeclared exception!
      try { 
        container0.liquefy();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testd33()  throws Throwable  {
      Container container0 = new Container();
      // Undeclared exception!
      try { 
        container0.combine((Container) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }
  
  @Test(timeout = 4000)
  public void teste00()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, (String) null);
      String string0 = ingredient0.getName();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void teste01()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      String string0 = ingredient0.getName();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void teste02()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      int int0 = ingredient0.getAmount();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void teste03()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("'");
      ingredient0.setAmount(1);
      int int0 = ingredient0.getAmount();
      assertEquals(1, int0);
  }

  @Test(timeout = 4000)
  public void teste04()  throws Throwable  {
      Integer integer0 = new Integer((-1));
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      Ingredient ingredient0 = new Ingredient(integer0, ingredient_State0, "");
      int int0 = ingredient0.getAmount();
      assertEquals((-1), int0);
  }

  @Test(timeout = 4000)
  public void teste05()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void teste06()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient(" ");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 0
         //
      }
  }

  @Test(timeout = 4000)
  public void teste07()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("M r");
      assertEquals("M r", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void teste08()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("0 w");
      assertEquals("w", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void teste09()  throws Throwable  {
      Ingredient ingredient0 = null;
      try {
        ingredient0 = new Ingredient("");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"\"
         //
      }
  }

  @Test(timeout = 4000)
  public void teste10()  throws Throwable  {
      Integer integer0 = new Integer(0);
      Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
      ingredient0.getstate();
  }

  @Test(timeout = 4000)
  public void teste11()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("w");
      ingredient0.liquefy();
      assertEquals("w", ingredient0.getName());
  }

  @Test(timeout = 4000)
  public void teste12()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("w");
      ingredient0.dry();
      assertEquals(Ingredient.State.Dry, ingredient0.getstate());
  }

  @Test(timeout = 4000)
  public void teste13()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("M");
      Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
      ingredient0.setState(ingredient_State0);
      assertEquals(Ingredient.State.Liquid, ingredient0.getstate());
  }

  @Test(timeout = 4000)
  public void teste14()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("w");
      Ingredient.State ingredient_State0 = ingredient0.getstate();
      assertEquals(Ingredient.State.Dry, ingredient_State0);
  }

  @Test(timeout = 4000)
  public void teste15()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("w");
      String string0 = ingredient0.getName();
      assertEquals("w", string0);
  }

  @Test(timeout = 4000)
  public void teste16()  throws Throwable  {
      Ingredient ingredient0 = new Ingredient("M");
      // Undeclared exception!
      try { 
        ingredient0.getAmount();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }
  
  @Test(timeout = 4000)
  public void testff0()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("W");
      Container[] containerArray0 = new Container[7];
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.mixingbowls = containerArray0;
      Container container0 = kitchen0.cook();
      assertNull(container0);
  }

  @Test(timeout = 4000)
  public void testff1()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("W");
      Container[] containerArray0 = new Container[7];
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      containerArray0[0] = container0;
      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
      Component component0 = new Component(0, ingredient_State0);
      containerArray0[0].push(component0);
      Container container1 = kitchen0.cook();
      assertSame(container1, container0);
  }

  @Test(timeout = 4000)
  public void testf2()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("L");
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      kitchen0.recipe = null;
      // Undeclared exception!
      try { 
        kitchen0.cook();
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testf3()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("r");
      Container[] containerArray0 = new Container[7];
      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
      Container container0 = kitchen0.cook();
      containerArray0[0] = container0;
      containerArray0[1] = container0;
      containerArray0[2] = container0;
      containerArray0[3] = containerArray0[0];
      containerArray0[4] = container0;
      containerArray0[5] = container0;
      containerArray0[6] = container0;
      Kitchen kitchen1 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
      assertFalse(kitchen1.equals((Object)kitchen0));
  }

  @Test(timeout = 4000)
  public void testf4()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("r");
      Container[] containerArray0 = new Container[7];
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testf5()  throws Throwable  {
      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
      Recipe recipe0 = new Recipe("");
      Kitchen kitchen0 = null;
      try {
        kitchen0 = new Kitchen(hashMap0, recipe0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }
  
  @Test(timeout = 4000)
  public void testf0()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method((String) null, 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void testf1()  throws Throwable  {
      Method method0 = null;
      try {
        method0 = new Method("", 0);
        fail("Expecting exception: ChefException");
      
      } catch(Throwable e) {
         //
         // Method error, step 1:  (Unsupported method found!)
         //
      }
  }
  
  @Test(timeout = 4000)
  public void test00()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setServes("4 O5V-p6D");
      assertEquals("", recipe0.getTitle());
  }

  @Test(timeout = 4000)
  public void test01()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      String string0 = recipe0.getTitle();
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void test02()  throws Throwable  {
      Recipe recipe0 = new Recipe(".");
      String string0 = recipe0.getTitle();
      assertEquals(".", string0);
  }

  @Test(timeout = 4000)
  public void test03()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      int int0 = recipe0.getServes();
      assertEquals(0, int0);
  }

  @Test(timeout = 4000)
  public void test04()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("g");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertTrue(arrayList0.isEmpty());
  }

  @Test(timeout = 4000)
  public void test05()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("d");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertTrue(hashMap0.isEmpty());
  }

  @Test(timeout = 4000)
  public void test06()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes("");
        fail("Expecting exception: StringIndexOutOfBoundsException");
      
      } catch(StringIndexOutOfBoundsException e) {
      }
  }

  @Test(timeout = 4000)
  public void test07()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes("Stirhedn");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"\"
         //
      }
  }

  @Test(timeout = 4000)
  public void test08()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("   m");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"m\"
         //
      }
  }

  @Test(timeout = 4000)
  public void test09()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test10()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setOvenTemp("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 3
         //
      }
  }

  @Test(timeout = 4000)
  public void test11()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setMethod("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test12()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setMethod((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test13()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setIngredients("");
        fail("Expecting exception: NoSuchElementException");
      
      } catch(NoSuchElementException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test14()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setIngredients((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test15()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("  m");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // For input string: \"m\"
         //
      }
  }

  @Test(timeout = 4000)
  public void test16()  throws Throwable  {
      Recipe recipe0 = new Recipe((String) null);
      // Undeclared exception!
      try { 
        recipe0.setCookingTime((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test17()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getMethod(0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test18()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setMethod("L");
      // Undeclared exception!
      try { 
        recipe0.getMethod((-1));
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test19()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      try { 
        recipe0.setMethod("^.$");
        fail("Expecting exception: ChefException");
      
      } catch(ChefException e) {
         //
         // Method error, step 1: $. (Unsupported method fo
      }
  }

  @Test(timeout = 4000)
  public void test20()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setIngredients("g");
      // Undeclared exception!
      try { 
        recipe0.setIngredientValue("", 0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test21()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setCookingTime("");
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // 2
         //
      }
  }

  @Test(timeout = 4000)
  public void test22()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
      assertNull(hashMap0);
  }

  @Test(timeout = 4000)
  public void test23()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.setServes((String) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test24()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      ArrayList<Method> arrayList0 = recipe0.getMethods();
      assertNull(arrayList0);
  }

  @Test(timeout = 4000)
  public void test25()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      // Undeclared exception!
      try { 
        recipe0.getIngredientValue("");
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test26()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      String string0 = recipe0.getTitle();
      assertEquals("", string0);
  }

  @Test(timeout = 4000)
  public void test27()  throws Throwable  {
      Recipe recipe0 = new Recipe("");
      recipe0.setComments("");
      assertEquals(0, recipe0.getServes());
  }
  
  @Test(timeout = 4000)
  public void test111() throws Exception  {
	 try {
		 Method m1=new Method("take it", 0);
	} catch (Exception e) {
		assertTrue(e instanceof ChefException);
	}
	 Method m2=new Method("Take a from refrigerator.",1);
	 
	 Method m3=new Method("Liquefy a.",1);
	 Method m4=new Method("Mix the mixing bowl well.",1);
	 Method m5=new Method("Clean mixing bowl.",1);
	 Method m6=new Method("Pour contents of the mixing bowl into the baking dish.",1);
	 Method m7=new Method("Set aside.",1);
	 Method m8=new Method("Refrigerate.",1);
	 Method m9=new Method("Serve with a.",1);
	 Method m10=new Method("Suggestion: fuck.",1);
	 Method m11=new Method("a until b.",1);
	 Method m12=new Method("Fuck the b.",1);
	 Method m13=new Method("Put a into the mixing bowl.",1);
	 Method m14=new Method("Add dry ingredients mixing bowl.",1);
	 Method m15=new Method("Add a into mixing bowl.",1);
	 Method m16=new Method("Stir for 2 minutes.",1);
	 Method m17=new Method("Stir a into the mixing bowl.",1);
	 Method m18=new Method("Liquefy contents of the mixing bowl.",1);
  } 
}
