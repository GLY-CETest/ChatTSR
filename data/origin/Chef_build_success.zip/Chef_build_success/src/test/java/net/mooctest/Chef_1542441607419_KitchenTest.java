package net.mooctest;

import net.mooctest.Ingredient.State;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;

public class Chef_1542441607419_KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      //Recipe recipe = new Recipe("");
      String file = "demo.txt";
      try {
		Chef chef = new Chef(file);
		
		//烹饪
		//chef.bake();
		
		//Component component = new Component(n, s);
		Container mbow = new Container();
		Container[] mbowls = new Container[]{mbow,mbow,mbow};
		Container bdish = new Container();
		Container[] bdishes = new Container[]{bdish,bdish,bdish};
		
		HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
		Recipe recipe = new Recipe("take");
		recipes.put("take", recipe);
		recipe.setMethod("Take hello from refrigerator.Put hello into 1th mixing bowl.Serve with hello.");
		recipe.setIngredients("\nhello\ntake\nput\nhello");
		
	    Kitchen kitchen = new Kitchen(recipes, recipe,mbowls,bdishes);
		
		a(false, recipe.getMethods().contains("put"));
		a(true, recipe.getIngredients().containsKey("hello"));
		Container container = new Container();
		container.push(new Component(1, State.Dry));
		container.push(new Component(2, State.Liquid));
		container.push(new Component(3, State.Dry));
		container.push(new Component(4, State.Liquid));
		container.push(new Component(5, State.Dry));
		a(5, container.pop().getValue());
		a(true,container.serve().length() > 2);
		container.stir(2);
		container.stir(20);
		
		ChefException chefException = new ChefException(0, "hello");
		Object[] obsObjects = new Object[3];
		obsObjects[0] = "hello";
		obsObjects[1] = "world";
		obsObjects[2] = "rain";
		a("hello,world,rain",chefException.arrayToString(obsObjects, ","));
		
		Ingredient ingredient = new Ingredient("1 heaped");
		kitchen.cook();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
  
  private <T> void a(T a, T b) {
      assertEquals(a, b);
  }

  private <T> void at(T a) {
      assertTrue((Boolean) a);
  }

  private <T> void af(T a) {
      assertFalse((Boolean) a);
  }

  private <T> void p(T x) {
      System.out.println(x);
  }
}
