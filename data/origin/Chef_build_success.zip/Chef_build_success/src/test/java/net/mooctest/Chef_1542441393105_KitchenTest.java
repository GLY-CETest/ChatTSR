package net.mooctest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

public class Chef_1542441393105_KitchenTest {

  @Test(timeout = 4000)
  public void testIngredient(){

      Ingredient intest=new Ingredient(1, Ingredient.State.Dry, "123");
     assertEquals(intest.getAmount(),1); 
     assertEquals(intest.getstate(),Ingredient.State.Dry);
     intest.setState(Ingredient.State.Liquid);
     assertEquals(intest.getstate(),Ingredient.State.Liquid);
     intest.dry();
     assertEquals(intest.getstate(),Ingredient.State.Dry);
     intest.liquefy();
     assertEquals(intest.getstate(),Ingredient.State.Liquid);
     assertEquals(intest.getName(),"123");
     intest.setAmount(5);
     assertEquals(intest.getAmount(),5); 
    try {
 		Ingredient in=new Ingredient("\\d* heaped|level g|kg|pinch(es)? ml|l|dash(es)?");
    } catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    Component component =new Component(intest);
    assertEquals(component.getValue(),5);
    assertEquals(component.getState(),Ingredient.State.Liquid);
    Component coa= component.clone();
    coa.setState(Ingredient.State.Dry);
    coa.setValue(10);
    assertEquals(coa.getValue(),10);
    assertEquals(coa.getState(),Ingredient.State.Dry);
    coa.liquefy();
    assertEquals(coa.getState(),Ingredient.State.Liquid);
  }
  @Test(timeout = 4000)
  public void testcontainer(){
	  Container container =new Container();
	 
	  Ingredient intest=new Ingredient(1, Ingredient.State.Dry, "123");
	  Component component =new Component(intest);
	  
	 try {
		container.pop();
	 
	} catch (ChefException e) {
		assertTrue(e.getMessage().equals("Local error: Folded from empty container"));
	}
	  container.push(component);
	  assertEquals(container.size(), 1);
	  
	  try {
		  container.liquefy();
		Component com= container.pop();
		assertEquals(com.getState(), Ingredient.State.Liquid);
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  Container container1 =new Container();

	  Ingredient intest1=new Ingredient(1, Ingredient.State.Dry, "456");
	  Component component1 =new Component(intest1);
	  container1.push(component1);
	  Component component2=container1.peek();
	  assertEquals(component2.getValue(),1);
	  container1.shuffle();
	  container1.combine(container);
	  assertEquals(container1.size(), 1);
	  String s=container1.serve();
	  assertTrue(s.equals("1 "));
	  container1.liquefy();
	  String s1=container1.serve();
	  assertNotNull(s1);
	  Container container2=new Container(container1);
	  container2.push(component1);
	  container2.push(component1);
	  container2.push(component1);
	  container2.stir(2);
	  container2.clean();
	  assertEquals(container2.size(), 0);
  }
  @Test(timeout = 4000)
  public void testRecipe(){
	  Recipe recipe =new Recipe("sushi");
	  try {
		recipe.setIngredients("5 heaped l cups");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  try {
			recipe.setIngredients("123 456 789");
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	  recipe.setComments("1");
	  try {
		recipe.setMethod("Take");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
	  recipe.setCookingTime("10s  1   2");
	  recipe.setOvenTemp("10 1 2 3");
	  System.out.println(recipe.getServes());
	  assertEquals("sushi", recipe.getTitle());
	  assertEquals(0,recipe.getServes());
	  HashMap<String,Ingredient> ss= recipe.getIngredients();
	  assertEquals(0, ss.size());
//	  recipe.setIngredientValue("123", 1);
	  ArrayList<Method> sss=recipe.getMethods();
	  assertEquals(sss.size(),0);
	// recipe.setServes("Serves Serves Serves ");
	  
  }
  @Test(timeout = 4000)
  public void testMethod(){
	  try {
		Method method=new Method("1", 1);
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		assertTrue(e.getMessage().equals("Method error, step 2: 1 (Unsupported method found!)"));
	}
	  
	  try {
			Method method=new Method("Take eggs from refrigerator.", 1);
			assertEquals(method.type, Method.Type.Take);
		}
	  catch (ChefException e) {
			// TODO Auto-generated catch block
			
		}

	  try {
			Method method=new Method("Add dry ingredients to st mixing bowl", 1);
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			
		}
	  try {
			Method method=new Method("Add eggs to st mixing bowl)", 1);
			assertEquals(method.type, Method.Type.Add);
		}
	  catch (ChefException e) {
			// TODO Auto-generated catch block
			
		}
	  
  }
  @Test(timeout = 4000)
  public void testchef(){
	  try {
		Chef chef =new Chef("caipu.txt");
		java.lang.reflect.Method method=chef.getClass().getDeclaredMethod("structHint", int.class);
		method.setAccessible(true);
		String s=(String) method.invoke(chef, 1);
		assertTrue(s.equals("no hint available"));
		String s1=(String) method.invoke(chef, 2);
		assertTrue(s1.equals("did you specify 'Ingredients.' above the ingredient list?"));
		String s2=(String) method.invoke(chef, 3);
		assertTrue(s2.equals("did you specify 'Methods.' above the methods?"));
	} catch (Exception e) {
		// TODO Auto-generated catch blockod 
		e.printStackTrace();
	}
	  try {
			Chef chef =new Chef("caipu.txt");
			java.lang.reflect.Method method=chef.getClass().getDeclaredMethod("progressToExpected", int.class);
			method.setAccessible(true);
			String s=(String) method.invoke(chef, 0);
			assertTrue(s.equals("title"));
			String s1=(String) method.invoke(chef, 1);
			assertTrue(s1.equals("comments"));
			String s2=(String) method.invoke(chef, 2);
			assertTrue(s2.equals("ingredient list"));
			String s3=(String) method.invoke(chef, 3);
			assertTrue(s3.equals( "cooking time"));
			String s4=(String) method.invoke(chef, 4);
			assertTrue(s4.equals("oven temperature"));
			String s5=(String) method.invoke(chef, 5);
			assertTrue(s5.equals("methods"));
			String s6=(String) method.invoke(chef, 6);
			assertTrue(s6.equals("serve amount"));
		} catch (Exception e) {
			// TODO Auto-generated catch blockod 
			e.printStackTrace();
		}
  }
  @Test(timeout = 4000)
  public void testexc(){
	  String[] a={"123","234"};
	  ChefException chefException =new ChefException(1, a,"string");
	  assertTrue(chefException.getMessage().equals("Ingredient wrongly formatted: '123 234' (string)"));
	  Recipe recipe =new Recipe("sushi");
	  ChefException chefException1 =new ChefException(1, recipe,1,"string","string");
	  assertTrue(chefException1.getMessage().equals("Method error, recipe sushi, step 2: string (string)"));
	  
	  try {
			Ingredient in1=new Ingredient("5 heaped l cups");
			Ingredient in=new Ingredient("5 heaped g ml");
			assertEquals(in1.getstate(), Ingredient.State.Liquid);
	
		
			assertEquals(in1.getstate(), Ingredient.State.Liquid);
		
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
}
