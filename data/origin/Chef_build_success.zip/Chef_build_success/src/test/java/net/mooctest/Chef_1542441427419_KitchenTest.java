package net.mooctest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;

import org.junit.Test;


public class Chef_1542441427419_KitchenTest {

  @Test
  public void test(){
      Recipe recipe = new Recipe("");
      try {
		recipe.setIngredients("test\ntest\ntest");
		recipe.setCookingTime("2015 13 13");
		recipe.setOvenTemp("2015 13 13 13 12 13");
		recipe.setServes("12 321312");
		a(recipe.getServes(),1);
		a(recipe.getTitle(),"");
		recipe.setIngredientValue("test", 3);
		a(recipe.getIngredientValue("test"),3);
		a(recipe.getIngredients().size(),1);
		recipe.setMethod("test");
		a(recipe.getMethods().size(),0);
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  	Ingredient ingredient = null;
      try {
		 ingredient = new Ingredient("test test");
		ingredient = new Ingredient("12 213 213");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
     ChefException chefException = new ChefException(0,"ex");
     String[] str = new String[]{"111","22222"};
     chefException = new ChefException(0,str,"ex");
     chefException = new ChefException(0,0,"ex","as");
     chefException = new ChefException(0,recipe,0,"ex","as");
     
     Container container = new Container();
     container = new Container(new Container());
     container.push(new Component(ingredient));
     Component component = container.peek();
     a(container.size(),1);
     container.combine(new Container());
     container.liquefy();
     container.clean();
     container.serve();
     container.shuffle();
     container.stir(2);

     try {
		container.pop();
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
     Kitchen kitchen = new Kitchen(recipes, recipe);
     try {
		kitchen.cook();
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
     try {
		Method method = new Method("Take (agt) from refrigerator.", 10);
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
    Component component2 = new Component(10,Ingredient.State.Dry);
    a(component2.getValue(), 10);
    component2.setValue(9);
    Ingredient.State state = component2.getState();
    a(state, Ingredient.State.Dry);
    component2.setState(Ingredient.State.Liquid);
    Component cloComponent = component2.clone();
    a(cloComponent.getState(), Ingredient.State.Liquid);
    
	//Component component = new Component(ingredient)
  }
  private void buildFile(String content) throws Exception {
      File file = new File("tmp");
      FileOutputStream fos = new FileOutputStream(file);
      fos.write(content.getBytes());
      fos.flush();
      fos.close();
  }
  @Test
  public void myTest(){
	  String content = "test\n\ntest\n\ntest\n\nIngredients.\nfood\n\nCooking time";
	     
      try {
    	  buildFile(content);
		Chef chef = new Chef("tmp");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
	}
      content = "test\n\nIngredients\n\nCooking time\n\nPre-heat oven";
      try {
    	  buildFile(content);
		Chef chef = new Chef("tmp");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
	}  
      content = "test\n\nPre-heat oven\n\nIngredients.";
      try {
    	  buildFile(content);
		Chef chef = new Chef("tmp");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
	}  
      content = "test\n\nMethod";
      try {
    	  buildFile(content);
		Chef chef = new Chef("tmp");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
	}
      content = "test.\n\nServes";
      try {
    	  buildFile(content);
		Chef chef = new Chef("tmp");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
		at(e.getMessage().contains("Structural error: Read unexpected serve amount. Expecting comments"));
	}
      
  }
  @Test
  public void testMethod(){	
	  try {
		Method method = new Method("Suggestion: oo", 1);
		method = new Method("Serve with adsa", 1);
		method = new Method("Set aside.", 1);
		method = new Method("Take asd from refrigerator.", 1);
		method = new Method("Put ads into mixing bowl.", 1);
		method = new Method("Fold ads into mixing bowl.", 1);
		method = new Method("Add dsad to mixing bowl.", 1);
		method = new Method("Liquefy contents of the mixing bowl.",1);
		method = new Method("Liquefy sda.",1);
		method = new Method("Stir the mixing bowl for minutes",1);
		method = new Method("Stir das into the mixing bowl.",1);
		method = new Method("Mix the mixing bowl well.",1);
		method = new Method("Clean mixing bowl.",1);
		method =new Method("Pour contents of the mixing bowl into the baking dish.",1);
		//method =new Method("Refrigerate for hours.",1);
		method =new Method("dasd the dsad until das.",1);
		method =new Method("sda the dasd.",1);
		
		
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	     Recipe recipe = new Recipe("");
	      try {
			recipe.setMethod("Suggestion: oo\nServe with adsa\nSet aside.\n"
					+ "Take asd from refrigerator.\nPut ads into mixing bowl.\nFold ads into mixing bowl."
					+ "\nAdd dsad to mixing bowl.\nLiquefy contents of the mixing bowl.\nLiquefy sda.\n"
					+ "Stir the mixing bowl for minutes\nStir das into the mixing bowl.\nMix the mixing bowl well.\n"
					+ "Clean mixing bowl.\nPour contents of the mixing bowl into the baking dish."
					+ "\ndasd the dsad until das."
					+ "\nsda the dasd.");
		     HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
		     Kitchen kitchen = new Kitchen(recipes, recipe);
		     try {
		    	   java.lang.reflect.Method method = Kitchen.class.getDeclaredMethod("sameVerb", String.class,String.class);
		    	   method.setAccessible(true);
		    	   at(method.invoke(kitchen,"A", "A"));
		    	   af(method.invoke(kitchen,null, null));
		    	   af(method.invoke(kitchen,"3", null));
		    	   at(method.invoke(kitchen,"shake", "shaken"));
		    	   at(method.invoke(kitchen,"prepare", "prepare"));
		    	   af(method.invoke(kitchen,"monitor", "prepare"));
		    	   at(method.invoke(kitchen,"stir", "stirred"));
		    	   at(method.invoke(kitchen,"carry", "carried"));
		    	    method = Kitchen.class.getDeclaredMethod("serve", int.class);
		    	   method.setAccessible(true);
		    	   method.invoke(kitchen,10);
		     } catch (Exception e) {
				// TODO: handle exception
			}
		  
		    // kitchen.cook();
		} catch (ChefException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
  @Test
  public void testExeption(){	
	  String content = "t\nPre-heat oven";
	  content = "t Pre-heat oven Ingredients Method";
	  Chef chef = null;
      try {
    	  buildFile(content);
		   chef = new Chef("tmp");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
	}
 
  }
 

  private <T> void a(T a, T b) {
      assertEquals(a, b);
  }

  private <T> void at(T a) {
      assertTrue((Boolean) a);
  }

  private <T> void af(T a) {
      assertFalse((Boolean) a);
  }

  private <T> void p(T x) {
      System.out.println(x);
  }
}
