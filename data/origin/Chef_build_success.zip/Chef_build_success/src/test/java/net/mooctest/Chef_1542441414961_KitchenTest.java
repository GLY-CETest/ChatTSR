package net.mooctest;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

public class Chef_1542441414961_KitchenTest {

	@Test
	  public void test(){
		  //R
		  Recipe recipe = new Recipe("");
		  try {
		    	  recipe.setIngredients("hello\n1 heaped kg l\n1 heaped l cup(s)\n1 heaped cup a");
		    	  assertEquals(1, recipe.getIngredientValue("l"));
		    	  assertEquals(1, recipe.getIngredientValue("cup(s)"));
		    	  assertEquals(1, recipe.getIngredientValue("a"));
		    	  
		    	  recipe.setMethod("hel.Take a from refrigerator"+
		    	  ".Put a into the 1nd mixing bowl"
		    	  +".Add dry ingredients to 1nd mixing bowl"
		    	  +".Add a to 1nd mixing bowl"
		    	  +".Liquefy contents of the 1nd mixing bowl"
		    	  +".Liquefy aa"
		    	  +".Stir the 1nd mixing bowl for 1 minutes"
		    	  +".Stir a into the 1nd mixing bowl"
		    	  +".Mix the 1nd mixing bowl well"
		    	  +".Clean 1nd mixing bowl"
		    	  +".Pour contents of the 1nd mixing bowl into the 1nd baking dish"
		    	  +".Set aside"
		    	  +".Refrigerate for 1 hours"
		    	  +".Serve with a"
		    	  +".Suggestion: 1"
		    	  +".a the a until a"
		    	  +".a the a");
		    	  
		    	  Method method = recipe.getMethod(11);
		    	  assertEquals(Method.Type.SetAside, method.type);
				} catch (ChefException e) {
					e.printStackTrace();
				}   
		  HashMap<String, Recipe>	recipes = new HashMap<String, Recipe>();
		  recipes.put("1", recipe);
		  recipes.put("2", recipe);
		  recipes.put("3", recipe);
		  Kitchen kitchen = new Kitchen(recipes, recipe);
		  
	  }
}
