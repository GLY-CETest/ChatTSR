package net.mooctest;

import java.util.HashMap;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class Chef_1542440970972_KitchenTest {

  @Test(timeout = 4000,expected=NullPointerException.class)
  public void test() throws ChefException  {
      Recipe recipe = new Recipe("fish");
      Recipe recipe2 = new Recipe("noodle");
      HashMap<String, Recipe>recipes=new HashMap<String, Recipe>();
      recipes.put("fish", recipe);
      recipes.put("noodle", recipe2);
      Kitchen kitchen=new Kitchen(recipes, recipe);
      
      kitchen.cook();
      
      
  }
  
  @Test(timeout = 4000)
  public void testRecipe01() throws ChefException  {
	  
	  Recipe recipe=new Recipe("fish");
	  recipe.setIngredients("^\\d*$ "+"heaped|level\n"
	  		+ "^g|kg|pinch(es)?\n"
	  		+ "^ml|l|dash(es)?\n"
	  		+ "^cup(s)?|teaspoon(s)?|tablespoon(s)?\n");
  }
  @Test(timeout = 4000,expected=ChefException.class)
  public void testRecipe02() throws ChefException  {
	  
	  Recipe recipe=new Recipe("fish");
	  recipe.setIngredients("1. heaped|level\n");
	  recipe.setComments("fish");
	  recipe.setMethod("\\.Take fish from refrigerator");
	  HashMap<String, Recipe>recipes=new HashMap<String, Recipe>();
	  recipes.put("fish", recipe);
	  Kitchen kitchen=new Kitchen(recipes, recipe);
    
	  kitchen.cook();
	  
  }
  
  @Test(timeout = 4000)
  public void testRecipe03() throws ChefException  {
	  
	  Recipe recipe=new Recipe("fish");
	  recipe.setIngredients("^\\d*$ "+"heaped|level\n");
	  recipe.setComments("fish");
	  recipe.setMethod("\\.Take fish from refrigerator");
	  recipe.setCookingTime("cooking time 32");
	  recipe.setOvenTemp("gas mark 32 32");
	  recipe.setServes("Serves 4352");
	  assertEquals(435, recipe.getServes());
	  recipe.getIngredients();
	  recipe.getMethod(0);
  }
  @Test(timeout = 4000)
  public void testRecipe04() throws ChefException  {
	  
	  Recipe recipe=new Recipe("fish");
	  recipe.setIngredients("heaped|level");
  }
  
  @Test(timeout = 4000)
  public void testIngredient() throws ChefException  {
	  Ingredient ingredient=new Ingredient(4, Ingredient.State.Dry, "s");
	  ingredient.setAmount(2);
	  ingredient.setState(ingredient.getstate());
	  ingredient.getAmount();
	  ingredient.getName();
	  ingredient.getstate();
	  ingredient.dry();
	  ingredient.liquefy();
  }

  
 
  


}
