package net.mooctest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.junit.Assert;
import org.junit.Test;

public class Chef_1542441221716_KitchenTest {

	private void testWithChef(String prog) {
		File file = new File("chef");
		BufferedWriter bufferedWriter = null;
		try {
			if (!file.exists()) {
				file.createNewFile();
			}
			bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, false)));
			bufferedWriter.write(prog);
			bufferedWriter.close();
			Chef chef = new Chef("chef");
		} catch (Exception e) {
		}
	}

	@Test(timeout = 4000)
	public void test() {
		testWithChef("helloworld");
		testWithChef("tomato\npotato");
		testWithChef("tomato\n\npotato");

	}

	@Test(timeout = 4000)
	public void testIngredient() {
		Integer integer0 = new Integer(0);
		Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
		ingredient0.getstate();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Ingredient ingredient1 = new Ingredient((Integer) null, ingredient_State0, "");
		String string0 = ingredient1.getName();
		assertEquals("", string0);
		Ingredient.State ingredient_State1 = Ingredient.State.Liquid;
		Ingredient ingredient2 = new Ingredient((Integer) null, ingredient_State0, "");
		ingredient2.setAmount(0);
		int int0 = ingredient2.getAmount();
		assertEquals(0, int0);
		Integer integer1 = new Integer(1);
		Ingredient.State ingredient_State2 = Ingredient.State.Liquid;
		Ingredient ingredient3 = new Ingredient(integer1, ingredient_State2, "");
		int int1 = ingredient3.getAmount();
		assertEquals(1, int1);
		Integer integer2 = Integer.getInteger((String) null, 0);
		Ingredient.State ingredient_State3 = Ingredient.State.Dry;
		Ingredient ingredient4 = new Ingredient(integer2, ingredient_State3, "");
		ingredient4.setAmount((-1));
		int int2 = ingredient4.getAmount();
		assertEquals((-1), int2);
		try {
			new Ingredient("1 heaped g ml cup(s)?");
		} catch (ChefException e) {
			e.printStackTrace();
		}

	}

	@Test(timeout = 4000)
	public void testComponent() {
		Integer integer0 = new Integer(0);
		Ingredient ingredient0 = new Ingredient(integer0, (Ingredient.State) null, "");
		ingredient0.getstate();
		Component component = new Component(ingredient0);

	}

	@Test(timeout = 4000)
	public void test001() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setIngredients("U");
		// Undeclared exception!
		try {
			recipe0.setIngredientValue("", 0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test011() throws Throwable {
		Recipe recipe0 = new Recipe((String) null);
		String string0 = recipe0.getTitle();
		assertNull(string0);
	}

	@Test(timeout = 4000)
	public void test021() throws Throwable {
		Recipe recipe0 = new Recipe("T");
		String string0 = recipe0.getTitle();
		assertEquals("T", string0);
	}

	@Test(timeout = 4000)
	public void test031() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setServes("-=%>/!f2a");
		int int0 = recipe0.getServes();
		assertEquals(2, int0);
	}

	@Test(timeout = 4000)
	public void test041() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("r");
		ArrayList<Method> arrayList0 = recipe0.getMethods();
		assertTrue(arrayList0.isEmpty());
	}

	@Test(timeout = 4000)
	public void test051() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setIngredients("'");
		HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
		assertTrue(hashMap0.isEmpty());
	}

	@Test(timeout = 4000)
	public void test061() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setServes("KH6U1cPj");
			fail("Expecting exception: NumberFormatException");

		} catch (NumberFormatException e) {

		}
	}

	@Test(timeout = 4000)
	public void test071() throws Throwable {
		Recipe recipe0 = new Recipe((String) null);
		// Undeclared exception!
		try {
			recipe0.setServes((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test081() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setOvenTemp("   f");
			fail("Expecting exception: NumberFormatException");

		} catch (NumberFormatException e) {

		}
	}

	@Test(timeout = 4000)
	public void test091() throws Throwable {
		Recipe recipe0 = new Recipe((String) null);
		// Undeclared exception!
		try {
			recipe0.setOvenTemp((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test101() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setOvenTemp("");
			fail("Expecting exception: ArrayIndexOutOfBoundsException");

		} catch (ArrayIndexOutOfBoundsException e) {

		}
	}

	@Test(timeout = 4000)
	public void test111() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setMethod("");
			fail("Expecting exception: NoSuchElementException");

		} catch (NoSuchElementException e) {

		}
	}

	@Test(timeout = 4000)
	public void test121() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setMethod((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test131() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setIngredients("");
			fail("Expecting exception: NoSuchElementException");

		} catch (NoSuchElementException e) {

		}
	}

	@Test(timeout = 4000)
	public void test141() throws Throwable {
		Recipe recipe0 = new Recipe((String) null);
		// Undeclared exception!
		try {
			recipe0.setIngredients((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test151() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setCookingTime("  ]");
			fail("Expecting exception: NumberFormatException");

		} catch (NumberFormatException e) {

		}
	}

	@Test(timeout = 4000)
	public void test161() throws Throwable {
		Recipe recipe0 = new Recipe((String) null);
		// Undeclared exception!
		try {
			recipe0.setCookingTime((String) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test171() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("Z");
		// Undeclared exception!
		try {
			recipe0.getMethod((-1));
			fail("Expecting exception: ArrayIndexOutOfBoundsException");

		} catch (ArrayIndexOutOfBoundsException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void test181() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod(" ");
		// Undeclared exception!
		try {
			recipe0.getMethod(0);
			fail("Expecting exception: IndexOutOfBoundsException");

		} catch (IndexOutOfBoundsException e) {

		}
	}

	@Test(timeout = 4000)
	public void test191() throws Throwable {
		Recipe recipe0 = new Recipe("");
		try {
			recipe0.setMethod("D.v");
			fail("Expecting exception: ChefException");

		} catch (ChefException e) {

		}
	}

	@Test(timeout = 4000)
	public void test201() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.getMethod(0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test211() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setCookingTime("");
			fail("Expecting exception: ArrayIndexOutOfBoundsException");

		} catch (ArrayIndexOutOfBoundsException e) {

		}
	}

	@Test(timeout = 4000)
	public void test221() throws Throwable {
		Recipe recipe0 = new Recipe("");
		HashMap<String, Ingredient> hashMap0 = recipe0.getIngredients();
		assertNull(hashMap0);
	}

	@Test(timeout = 4000)
	public void test231() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.setServes("");
			fail("Expecting exception: StringIndexOutOfBoundsException");

		} catch (StringIndexOutOfBoundsException e) {
		}
	}

	@Test(timeout = 4000)
	public void test241() throws Throwable {
		Recipe recipe0 = new Recipe("");
		int int0 = recipe0.getServes();
		assertEquals(0, int0);
	}

	@Test(timeout = 4000)
	public void test251() throws Throwable {
		Recipe recipe0 = new Recipe("");
		ArrayList<Method> arrayList0 = recipe0.getMethods();
		assertNull(arrayList0);
	}

	@Test(timeout = 4000)
	public void test261() throws Throwable {
		Recipe recipe0 = new Recipe("");
		// Undeclared exception!
		try {
			recipe0.getIngredientValue("");
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test271() throws Throwable {
		Recipe recipe0 = new Recipe("");
		String string0 = recipe0.getTitle();
		assertEquals("", string0);
	}

	@Test(timeout = 4000)
	public void test281() throws Throwable {
		Recipe recipe0 = new Recipe("");
		recipe0.setComments("");
		assertEquals(0, recipe0.getServes());
	}

	@Test(timeout = 4000)
	public void test1000() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("n");
		Container[] containerArray0 = new Container[0];
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
		kitchen0.mixingbowls = containerArray0;
		Container container0 = kitchen0.cook();
		assertNull(container0);
	}

	@Test(timeout = 4000)
	public void test2000() throws Throwable {
		HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
		Recipe recipe0 = new Recipe("");
		recipe0.setMethod("h");
		Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
		Container container0 = kitchen0.cook();
		assertEquals(0, container0.size());
	}

	@Test(timeout = 4000)
	public void test00() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		container0.push((Component) null);
		container0.combine(container0);
		container0.stir(2);
		assertEquals(4, container0.size());
	}

	@Test(timeout = 4000)
	public void test01() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		container0.stir(1);
		assertEquals(1, container0.size());
	}

	@Test(timeout = 4000)
	public void test02() throws Throwable {
		Container container0 = new Container();
		container0.stir((-1));
		assertEquals(0, container0.size());
	}

	@Test(timeout = 4000)
	public void test03() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
		container0.push((Component) null);
		// Undeclared exception!
		try {
			container0.serve();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
		}
	}

	@Test(timeout = 4000)
	public void test04() throws Throwable {
		Container container0 = new Container();
		Container container1 = new Container(container0);
		container0.combine(container1);
		assertEquals(0, container0.size());
	}

	@Test(timeout = 4000)
	public void test05() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		container0.push(component0);
		Component component1 = container0.pop();
		assertEquals(0, component1.getValue());
	}

	@Test(timeout = 4000)
	public void test06() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		int int0 = container0.size();
		assertEquals(1, int0);
	}

	@Test(timeout = 4000)
	public void test07() throws Throwable {
		Container container0 = new Container();
		String string0 = container0.serve();
		assertEquals("", string0);
	}

	@Test(timeout = 4000)
	public void test08() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
		Component component0 = container0.pop();
		assertNull(component0);
	}

	@Test(timeout = 4000)
	public void test09() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(1, ingredient_State0);
		container0.push(component0);
		Component component1 = container0.pop();
		assertEquals(1, component1.getValue());
	}

	@Test(timeout = 4000)
	public void test10() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		component0.setValue((-1));
		container0.push(component0);
		Component component1 = container0.pop();
		assertEquals((-1), component1.getValue());
	}

	@Test(timeout = 4000)
	public void test11() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
		Component component0 = container0.peek();
		assertNull(component0);
	}

	@Test(timeout = 4000)
	public void test12() throws Throwable {
		Container container0 = new Container();
		Container container1 = new Container(container0);
		ArrayList<Component> arrayList0 = new ArrayList<Component>();
		container1.contents = arrayList0;
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		arrayList0.add(component0);
		Component component1 = container1.peek();
		assertSame(component1, component0);
	}

	@Test(timeout = 4000)
	public void test13() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(1, ingredient_State0);
		container0.push(component0);
		Component component1 = container0.peek();
		assertSame(component1, component0);
	}

	@Test(timeout = 4000)
	public void test14() throws Throwable {
		Container container0 = new Container();
		Container container1 = new Container(container0);
		ArrayList<Component> arrayList0 = new ArrayList<Component>();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component((-1), ingredient_State0);
		arrayList0.add(component0);
		container1.contents = arrayList0;
		Component component1 = container1.peek();
		assertSame(component1, component0);
	}

	@Test(timeout = 4000)
	public void test15() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.stir(1);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
		}
	}

	@Test(timeout = 4000)
	public void test16() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.shuffle();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void test17() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
		// Undeclared exception!
		try {
			container0.serve();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test18() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		component0.setValue((-1));
		// Undeclared exception!
		try {
			container0.serve();
			fail("Expecting exception: IllegalArgumentException");

		} catch (IllegalArgumentException e) {

		}
	}

	@Test(timeout = 4000)
	public void test19() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.push(component0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test20() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.pop();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test21() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.peek();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test22() throws Throwable {
		Container container0 = new Container();
		container0.contents = null;
		// Undeclared exception!
		try {
			container0.combine(container0);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test23() throws Throwable {
		Container container0 = null;
		try {
			container0 = new Container((Container) null);
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test24() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		container0.push(component0);
		container0.stir(1);
		assertEquals(2, container0.size());
	}

	@Test(timeout = 4000)
	public void test25() throws Throwable {
		Container container0 = new Container();
		container0.stir(1);
		assertEquals(0, container0.size());
	}

	@Test(timeout = 4000)
	public void test26() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Dry;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		String string0 = container0.serve();
		assertEquals("0 ", string0);
	}

	@Test(timeout = 4000)
	public void test27() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		String string0 = container0.serve();
		assertEquals("\u0000", string0);
	}

	@Test(timeout = 4000)
	public void test28() throws Throwable {
		Container container0 = new Container();
		Ingredient.State ingredient_State0 = Ingredient.State.Liquid;
		Component component0 = new Component(0, ingredient_State0);
		container0.push(component0);
		container0.liquefy();
		assertEquals(1, container0.size());
	}

	@Test(timeout = 4000)
	public void test29() throws Throwable {
		Container container0 = new Container();
		try {
			container0.pop();
			fail("Expecting exception: ChefException");

		} catch (ChefException e) {

		}
	}

	@Test(timeout = 4000)
	public void test30() throws Throwable {
		Container container0 = new Container();
		// Undeclared exception!
		try {
			container0.peek();
			fail("Expecting exception: ArrayIndexOutOfBoundsException");

		} catch (ArrayIndexOutOfBoundsException e) {
			//
			// no message in exception (getMessage() returned null)
			//
		}
	}

	@Test(timeout = 4000)
	public void test31() throws Throwable {
		Container container0 = new Container();
		int int0 = container0.size();
		assertEquals(0, int0);
	}

	@Test(timeout = 4000)
	public void test32() throws Throwable {
		Container container0 = new Container();
		Container container1 = new Container(container0);
		container1.contents = null;
		// Undeclared exception!
		try {
			container1.size();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}

	@Test(timeout = 4000)
	public void test33() throws Throwable {
		Container container0 = new Container();
		container0.clean();
		assertEquals(0, container0.size());
	}

	@Test(timeout = 4000)
	public void test34() throws Throwable {
		Container container0 = new Container();
		container0.shuffle();
		assertEquals(0, container0.size());
	}

	@Test(timeout = 4000)
	public void test35() throws Throwable {
		Container container0 = new Container();
		container0.push((Component) null);
		// Undeclared exception!
		try {
			container0.liquefy();
			fail("Expecting exception: NullPointerException");

		} catch (NullPointerException e) {

		}
	}
	@Test(timeout = 4000)
	  public void test0()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("X");
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
	      Recipe recipe1 = new Recipe("");
	      kitchen0.recipe = recipe1;
	      // Undeclared exception!
	      try { 
	        kitchen0.cook();
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {

	      }
	  }

	  @Test(timeout = 4000)
	  public void test1()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("W");
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
	      Container container0 = kitchen0.cook();
	      Ingredient.State ingredient_State0 = Ingredient.State.Dry;
	      Component component0 = new Component(0, ingredient_State0);
	      container0.push(component0);
	      Container container1 = kitchen0.cook();
	      assertSame(container1, container0);
	  }

	  @Test(timeout = 4000)
	  public void test2()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      Container[] containerArray0 = new Container[8];
	      Container container0 = new Container();
	      containerArray0[0] = container0;
	      containerArray0[1] = container0;
	      recipe0.setMethod("W");
	      containerArray0[2] = container0;
	      containerArray0[3] = container0;
	      containerArray0[4] = containerArray0[2];
	      containerArray0[5] = container0;
	      containerArray0[6] = container0;
	      containerArray0[7] = container0;
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
	  }

	  @Test(timeout = 4000)
	  public void test3()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      Container[] containerArray0 = new Container[8];
	      recipe0.setMethod("W");
	      Kitchen kitchen0 = null;
	      try {
	        kitchen0 = new Kitchen(hashMap0, recipe0, containerArray0, containerArray0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {

	      }
	  }

	  @Test(timeout = 4000)
	  public void test4()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      recipe0.setMethod("X");
	      Kitchen kitchen0 = new Kitchen(hashMap0, recipe0);
	      Container[] containerArray0 = new Container[0];
	      kitchen0.mixingbowls = containerArray0;
	      Container container0 = kitchen0.cook();
	      assertNull(container0);
	  }

	  @Test(timeout = 4000)
	  public void test5()  throws Throwable  {
	      HashMap<String, Recipe> hashMap0 = new HashMap<String, Recipe>();
	      Recipe recipe0 = new Recipe("");
	      Kitchen kitchen0 = null;
	      try {
	        kitchen0 = new Kitchen(hashMap0, recipe0);
	        fail("Expecting exception: NullPointerException");
	      
	      } catch(NullPointerException e) {

	      }
	  }
}
