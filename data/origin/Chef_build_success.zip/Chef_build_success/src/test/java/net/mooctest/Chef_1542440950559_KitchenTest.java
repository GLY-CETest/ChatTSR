package net.mooctest;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

import org.junit.Test;

import junit.framework.Assert;

public class Chef_1542440950559_KitchenTest {

  @Test(timeout = 4000)
  public void test() throws ChefException{
      Recipe recipe = new Recipe("ertr.// ");
      recipe.setComments("ooooo");
      String cooktime="2 3 67 87";
      recipe.setCookingTime(cooktime);
      recipe.setIngredients("dfdf"+"\n");
      String data = "Hello\n, World!\r\n";
      InputStream stdin = System.in;
      try {  
    	  System.setIn(new ByteArrayInputStream(data.getBytes()));  
    	  Scanner scanner = new Scanner(System.in);  
    	  recipe.setIngredients(scanner.nextLine());
      } finally {
    	  System.setIn(stdin);
      }
      //recipe.setIngredientValue("123", 5);
      recipe.setOvenTemp("300 20 23 45 8 9 4 1 2 0");
      recipe.setServes("Serves 1234");
      recipe.setMethod("1"+"\n");
      recipe.setMethod("1dgfhgh"+"\\.");
      recipe.getMethods();
      recipe.getIngredients();      
      Assert.assertEquals("ertr.// ", recipe.getTitle());
      Assert.assertEquals(123, recipe.getServes());      
  
	  Ingredient ingre;
	  ingre=new Ingredient("1 g 7 8 9 0");
	  ingre=new Ingredient("1 kg 7 8 9 0");
	  ingre=new Ingredient("1 pinch(es) 7 8 9 0");
	  ingre=new Ingredient("1 heaped 7 8 9 0");
	  ingre=new Ingredient("1 level 7 8 9 0");
	  ingre=new Ingredient("1 ml 7 8 9 0");
	  ingre=new Ingredient("1 l 7 8 9 0");
	  ingre=new Ingredient("1 dashes 7 8 9 0");
	  ingre=new Ingredient("1 ml 7 8 9 0");
	  ingre=new Ingredient("1 tablespoon 7 8 9 0");
	  String[] a= {"cup(s)","teaspoon(s)","tablespoon(s)"};
	  for (int i=0;i<a.length;i++) {
		  String temp="1"+" "+a[i]+"7 8 9";
		  ingre=new Ingredient(temp);		  
	  }
	  Ingredient ingre2;
	  ingre2=new Ingredient(1,Ingredient.State.Dry,"1ml");
	  Assert.assertEquals(1, ingre2.getAmount());
	  Assert.assertEquals(Ingredient.State.Dry, ingre2.getstate());
	  Assert.assertEquals("1ml", ingre2.getName());
	  
	  ingre.setAmount(2);
	  ingre.setState(Ingredient.State.Dry);
	  ingre.liquefy();
	  ingre.dry();
	
	  Component com=new Component(1, Ingredient.State.Dry);
	  Component com1=new Component(ingre);
	  Assert.assertEquals(1, com.getValue());
	  Assert.assertEquals(Ingredient.State.Dry, com.getState());
	  com.clone();
	  com.setState(Ingredient.State.Dry);
	  com.setValue(2);
	  com.liquefy();
	  
	  Container con=new Container();
	  Container con2=new Container(con);
	  con.push(com);
	  con.push(com1);
	  con.peek();
	  con.size();
	  con.serve();
	  con.liquefy();
	  con.shuffle();
	  con.stir(3);
	  con.pop();
	  con.clean();
	  con.combine(con2);
	  
	  try {
		Chef chef =new Chef("1.txt");
		chef.bake();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
	  /*con.pop();*/
	  /*ingre=new Ingredient("1 g");
	  Assert.fail();*/
	  /*String ingredient="1 2g 3g 4g 5g 6g 7 8 9 0";
	  String[] tokens = ingredient.split(" ");
	  System.out.println(tokens.length);
	  System.out.println(tokens[0]);
	  if(tokens[0].matches("^\\d*$")) {
		  System.out.println(1);
	  }*/
  }
  @Test(timeout = 4000)
  public void test3() throws ChefException {
	  
  }
  
  
}

