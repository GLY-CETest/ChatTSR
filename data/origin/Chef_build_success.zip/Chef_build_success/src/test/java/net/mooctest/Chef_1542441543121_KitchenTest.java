package net.mooctest;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.*;
import java.util.HashMap;

import org.junit.Test;

import sun.security.jca.GetInstance.Instance;

public class Chef_1542441543121_KitchenTest {
	@Test(expected=Exception.class)
	public void test2() throws Exception{
		Recipe recipe=new Recipe("烤香肠");
		recipe.setMethod("then////.bea");
	}
	@Test(expected=Exception.class)
	public void test4() throws Exception{
		Container container1=new Container();
		container1.pop();
	}

	
	
	
	@Test(timeout = 4000)
	public void test1() throws Exception{
		//recipe
		Recipe recipe=new Recipe("烤香肠");
		a(recipe.getIngredients(),null);
		recipe.setIngredients("香肠 \nin2\nin\n");
		a(recipe.getIngredients().size(),2);
		recipe.setMethod("Take it from refrigerator////.Take it from refrigerator");
		recipe.setMethod("then////.Put it into the mixing bowl");
		recipe.setMethod("then////.Fold it into the mixing bowl");
		recipe.setMethod("then////.Fold it into the 1st mixing bowl");
		recipe.setMethod("then////.Fold it into the 2nd mixing bowl");
		recipe.setMethod("then////.Fold it into the 3rd mixing bowl");
		recipe.setMethod("then////.Add dry ingredients");
		recipe.setMethod("then////.Add it to 2nd mixing bowl");
		recipe.setMethod("then////.Remove it to mixing bowl");
		recipe.setMethod("then////.Remove it to 2nd mixing bowl");
		recipe.setMethod("then////.Divide it to 2nd mixing bowl");
		recipe.setMethod("then////.Combine it to 2nd mixing bowl");
		recipe.setMethod("then////.Liquefy contents of the mixing bowl");
		recipe.setMethod("then////.Liquefy contents of the 2nd mixing bowl");
		recipe.setMethod("then////.Liquefy it");
		recipe.setMethod("then////.Stir for 2 minutes");
		recipe.setMethod("then////.Stir the 2nd mixing bowl for 2 minutes");
		recipe.setMethod("then////.Stir it into the mixing bowl");
		recipe.setMethod("then////.Stir it into the 2nd mixing bowl");
		recipe.setMethod("then////.Mix well");
		recipe.setMethod("then////.Mix the 2nd mixing bowl well");
		recipe.setMethod("then////.Clean mixing bowl");
		recipe.setMethod("then////.Clean 2nd mixing bowl");
		recipe.setMethod("then////.Pour contents of the 2nd mixing bowl into the 2nd baking dish");
		recipe.setMethod("then////.Pour contents of the mixing bowl into the baking dish");
		recipe.setMethod("then////.Set aside");
		recipe.setMethod("then////.Refrigerate");
		recipe.setMethod("then////.Refrigerate for 2 hours");
		recipe.setMethod("then////.Serve with beer");
		recipe.setMethod("then////.Suggestion: hhel");
		recipe.setMethod("then////.do until night");
		recipe.setMethod("then////.pick the no");
		recipe.setOvenTemp("1 gas mark 5");
		recipe.setCookingTime("1 23 22");
		HashMap<String, Recipe> recipes=new HashMap<String, Recipe>();
		recipes.put("烤香肠",recipe);
		recipes.put("炸香肠",recipe);
		recipes.put("吃香肠",recipe);
		recipe.getMethods().add(new Method("Take it from refrigerator.",1));
		recipe.getMethods().add(new Method("Add dry ingredients.",2));
		recipe.getMethods().add(new Method("Fold it into the 2nd mixing bowl.",3));
		a(recipe.getMethods().size(),4);
		//container
		Container container1=new Container();
		container1.liquefy();
		container1.serve();
		Container container2=new Container();
		Container container3=new Container();
		Container[] containers={container1,container2,container3};
		
		//kitchen
		Kitchen kit = new Kitchen(recipes, recipe);
		Kitchen kit2=new Kitchen(recipes, recipe, containers, containers);
		a(kit2.bakingdishes.length,3);
		a(kit2.recipes.size(),3);
		a(kit2.mixingbowls.length,3);
		
//	//隐藏构造参数	
//	Class<?> clazz = XXX.class;
//	try{
//	Constructor ins = clazz.getDeclaredConstructor();
//	ins.setAccessible(true);
//	XXX xxx=ins.newInstance();
//	Method m = clazz.getDeclaredMethod("",int.class);
//	m.setAccessible(true);
//	Object[] ob={};
//	m.invoke(xxx, ob);
//	}catch(Exception e){
//		e.printStackTrace(System.out);
//	}
//	
//	
//	//public构造参数
//	Class<?> clazz1 = XXX.class;
//	try{
//	AAA aaa = new AAA();
//	Method m = clazz1.getDeclaredMethod("",int.class);
//	m.setAccessible(true);
//	Object[] ob={};
//	//m.invoke(aaa, ob);
//	}catch(Exception e){
//		e.printStackTrace(System.out);
//	}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    private <T> void a(T a, T b) {
        assertEquals(a, b);
    }

    private <T> void at(T a) {
        assertTrue((Boolean) a);
    }

    private <T> void af(T a) {
        assertFalse((Boolean) a);
    }

    private <T> void p(T x) {
        System.out.println(x);
    }	
}
