package net.mooctest;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

public class Chef_1542441476341_KitchenTest {

	@Test
	public void test() throws Exception {
		testKit();
		testReci();
		testChef();
		testChefEx();
		Ingredient ingredient = new Ingredient(1, Ingredient.State.Dry, "1");
		Component component=new Component(ingredient);
		component.setValue(1);
		assertEquals(1,component.getValue());
		System.out.println(component.clone());
		component.setState(Ingredient.State.Dry);
		component.getState();
		component.liquefy();
		Container container=new Container();
		container.serve();
		Container container2=new Container();
		container.combine(container2);
		container.serve();
		container.push(component);
		container.serve();
	}

	public void testKit() throws Exception {
		HashMap<String, Recipe> map = new HashMap();
		Recipe mainRecipe = new Recipe("mainRecipe");
		try {
			mainRecipe.setMethod("16.sdfsdf");
		} catch (Exception e) {
		}
		mainRecipe.setMethod("1.Take a from refrigerator");
		mainRecipe.setMethod("2.Put a into mixing bowl");
		mainRecipe.setMethod("2.Fold a into the 1nd mixing bowl");
		mainRecipe.setMethod("3.Add a to 1nd mixing bowl");
		mainRecipe.setMethod("3.Remove a into 2rd mixing bowl");
		mainRecipe.setMethod("3.Combine a from 3th mixing bowl");
		mainRecipe.setMethod("3.Divide a");
		mainRecipe.setMethod("4.Add dry ingredients to 1nd mixing bowl");
		mainRecipe.setMethod("4.Add dry ingredients");
		mainRecipe.setMethod("5.Liquefy contents of the 1nd mixing bowl");
		mainRecipe.setMethod("5.Liquefy contents of the mixing bowl");
		mainRecipe.setMethod("6.Liquefy a");
		mainRecipe.setMethod("6.Stir the 1nd mixing bowl for 1 minutes");
		mainRecipe.setMethod("6.Stir for 1 minutes");
		mainRecipe.setMethod("7.Stir a into the 1nd mixing bowl");

		mainRecipe.setMethod("7.Stir a into the mixing bowl");
		mainRecipe.setMethod("8.Mix the 1nd mixing bowl well");
		mainRecipe.setMethod("8.Mix the mixing bowl well");
		mainRecipe.setMethod("8.Mix well");
		mainRecipe.setMethod("9.Clean 1nd mixing bowl");
		mainRecipe.setMethod("9.Clean mixing bowl");
		mainRecipe.setMethod("11.Set aside");
		mainRecipe.setMethod("12.Refrigerate for 1 hours");
		mainRecipe.setMethod("12.Refrigerate");
		mainRecipe.setMethod("13.Serve with a");
		mainRecipe.setMethod("14.Suggestion: 123");
		mainRecipe.setMethod("15.a the a until a");
		mainRecipe.setMethod("16.a the a");
		Recipe recipe1 = new Recipe("recipe1");
		map.put("1", recipe1);
		Kitchen kitchen = new Kitchen(map, mainRecipe);
		try {
			kitchen.cook();
		} catch (Exception e) {
		}
		mainRecipe.setMethod("10.Pour contents of the 1nd mixing bowl into the 1nd baking dish");
		mainRecipe.setMethod("10.Pour contents of the mixing bowl into the baking dish");
		/*
		 * Pour contents of the( (\\d+)(nd|rd|th|st))? mixing bowl into the(
		 * (\\d+)(nd|rd|th|st))? baking dish
		 */
		mainRecipe.setMethod("10.Pour contents of the 4st mixing bowl into the 4st baking dish");
		Kitchen kitchen1 = new Kitchen(map, mainRecipe);
		kitchen1.cook();
		mainRecipe.setMethod("10.Pour contents of the 1nd mixing bowl into the 1nd baking dish");
		mainRecipe.setMethod("10.Pour contents of the mixing bowl into the baking dish");
		Kitchen kitchen2 = new Kitchen(map, mainRecipe);
		kitchen2.cook();
		mainRecipe.setMethod("10.Pour contents of the 1nd mixing bowl into the 1nd baking dish");
		Kitchen kitchen3 = new Kitchen(map, mainRecipe);
		kitchen3.cook();
		Container[] containers = new Container[2];
		containers[0] = new Container();
		containers[1] = new Container(containers[0]);
		Container[] containers1 = new Container[2];
		containers1[0] = new Container();
		containers1[1] = new Container(containers[0]);
		Kitchen kitchen4 = new Kitchen(map, mainRecipe, containers, containers1);
		kitchen4.cook();
		mainRecipe.setMethod("8.Mix well");
		Kitchen kitchen5 = new Kitchen(map, mainRecipe, containers, containers1);
		kitchen5.cook();
		mainRecipe.setMethod("4.Add dry ingredients to 1nd mixing bowl");
		mainRecipe.setIngredients("sdfsdf");
		kitchen3 = new Kitchen(map, mainRecipe);
		kitchen3.cook();
		mainRecipe.setMethod("1.Take a from refrigerator");
		Ingredient ingredient = new Ingredient(1, Ingredient.State.Dry, "1");
		mainRecipe.setIngredients("1\n1 2");
		System.out.println(mainRecipe.getIngredients());
		mainRecipe.setIngredientValue("2", 1);
		kitchen3 = new Kitchen(map, mainRecipe);
		mainRecipe.setMethod("2.Put a into mixing bowl");
		mainRecipe.setMethod("2.Fold a into the 1nd mixing bowl");
		mainRecipe.setMethod("3.Add a to 1nd mixing bowl");
		mainRecipe.setMethod("3.Remove a into 2rd mixing bowl");
		mainRecipe.setMethod("3.Combine a from 3th mixing bowl");
		mainRecipe.setMethod("3.Divide a");
		mainRecipe.setMethod("4.Add dry ingredients to 1nd mixing bowl");
		mainRecipe.setMethod("4.Add dry ingredients");
		mainRecipe.setIngredients("sdfsdf");
		kitchen3 = new Kitchen(map, mainRecipe);
		kitchen3.cook();
		mainRecipe.setMethod("5.Liquefy contents of the 1nd mixing bowl");
		mainRecipe.setMethod("5.Liquefy contents of the mixing bowl");
		mainRecipe.setIngredients("sdfsdf");
		kitchen3 = new Kitchen(map, mainRecipe);
		kitchen3.cook();
		mainRecipe.setMethod("6.Liquefy a");
		mainRecipe.setMethod("6.Stir the 1nd mixing bowl for 1 minutes");
		mainRecipe.setMethod("6.Stir for 1 minutes");
		mainRecipe.setIngredients("sdfsdf");
		kitchen3 = new Kitchen(map, mainRecipe);
		kitchen3.cook();
		mainRecipe.setMethod("7.Stir a into the 1nd mixing bowl");

		mainRecipe.setMethod("7.Stir a into the mixing bowl");
		mainRecipe.setMethod("8.Mix the 1nd mixing bowl well");
		mainRecipe.setMethod("8.Mix the mixing bowl well");
		mainRecipe.setMethod("8.Mix well");
		mainRecipe.setMethod("9.Clean 1nd mixing bowl");
		mainRecipe.setMethod("9.Clean mixing bowl");
		mainRecipe.setIngredients("sdfsdf");
		kitchen3 = new Kitchen(map, mainRecipe);
		kitchen3.cook();
		mainRecipe.setMethod("11.Set aside");
		mainRecipe.setMethod("12.Refrigerate for 1 hours");
		mainRecipe.setMethod("12.Refrigerate");
		mainRecipe.setIngredients("sdfsdf");
		kitchen3 = new Kitchen(map, mainRecipe);
		kitchen3.cook();
		mainRecipe.setMethod("13.Serve with a");
		mainRecipe.setMethod("14.Suggestion: 123");
		mainRecipe.setMethod("15.a the a until a");
		mainRecipe.setMethod("16.a the a");
	}

	public void testReci() {
		Recipe recipe = new Recipe("sdf");
		recipe.setComments("sdfsdf");
		recipe.setCookingTime("1 2 3");
		recipe.setOvenTemp("1 2 3 4");
	}

	public void testChef() throws Exception {
		Chef chef = null;
		try {
			chef = new Chef("src/main/resources/demo2.txt");
		} catch (Exception e) {
		}
		try {
			chef = new Chef("src/main/resources/demo.txt");
		} catch (Exception e) {
		}
		try {
			chef = new Chef("src/main/resources/demo1.txt");
		} catch (Exception e) {
		}
		try {
			chef = new Chef("src/main/resources/demo2.txt");
		} catch (Exception e) {
		}
		try {
			chef = new Chef("src/main/resources/demo3.txt");
		} catch (Exception e) {
		}try {
			chef = new Chef("src/main/resources/demo4.txt");
		} catch (Exception e) {
		}
		Class clazz=Chef.class;
		java.lang.reflect.Method method=null;
		try {
		method=clazz.getDeclaredMethod("structHint", new Class[] {int.class});
		}catch(Exception e) {}
		method.setAccessible(true);
		try {
			method.invoke(chef,new Object[] {1});
		} catch (Exception e) {
		}
		try {
			method.invoke(chef,new Object[] {2});
		} catch (Exception e) {
		}
		try {
			method.invoke(chef,new Object[] {3});
		} catch (Exception e) {
		}
		try {
			method=clazz.getDeclaredMethod("progressToExpected", new Class[] {int.class});
			}catch(Exception e) {}
			method.setAccessible(true);
			try {
				method.invoke(chef,new Object[] {0});
			} catch (Exception e) {
			}
			try {
				method.invoke(chef,new Object[] {1});
			} catch (Exception e) {
			}
			try {
				method.invoke(chef,new Object[] {2});
			} catch (Exception e) {
			}
			try {
				method.invoke(chef,new Object[] {3});
			} catch (Exception e) {
			}
			try {
				method.invoke(chef,new Object[] {4});
			} catch (Exception e) {
			}
			try {
				method.invoke(chef,new Object[] {5});
			} catch (Exception e) {
			}
			try {
				method.invoke(chef,new Object[] {6});
			} catch (Exception e) {
			}
			try {
				method.invoke(chef,new Object[] {7});
			} catch (Exception e) {
			}
	}
	public void testChefEx() {
		ChefException chefException=new ChefException(1, "sdfsdf");
		assertEquals("1",ChefException.arrayToString(new Object[] {1}, "sdfsdf"));
	}
}
