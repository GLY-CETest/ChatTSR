package net.mooctest;

import org.junit.Test;

public class Chef_1542441325576_KitchenTest {
  @Test(timeout = 4000)
  public void test0()  throws Throwable  {
      Recipe recipe = new Recipe("");
      recipe.setIngredients("asd");
      recipe.setComments("asd");   
  }
  
  }

