package net.mooctest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.junit.Test;

public class Chef_1542441743185_KitchenTest {

  @Test(timeout = 4000)
  public void testRecipe(){
    try {
      Recipe recipe = new Recipe(null);
    } catch (Exception e) {
	  ae(e instanceof NullPointerException, true);
	}
	  
	Recipe recipe = new Recipe("");
    ae(recipe.getTitle(), "");
    
    try {
      recipe.setIngredients("1 7g\n2 heaped g water ");
//	  recipe.setIngredients("123 123456\n123 heaped");
//	  ae(recipe.getIngredients(), null);
	} catch (ChefException e) {
	  e.printStackTrace();
	} catch (NoSuchElementException e) {
	  ae(e instanceof NoSuchElementException, true);
	}
    
    
  }
  
  @Test(timeout = 4000)
  public void testKitchen(){
	Kitchen kitchen = null;
	
	Recipe recipe = new Recipe("title");
	try {
		recipe.setMethod("123\n456.Take a from refrigerator.Put a into the mixing bowl.Add dry ingredients mixing bowl.asff");
	} catch (ChefException e1) {
		// TODO Auto-generated catch block
		ae(e1.getMessage(), "Method error, step 4: asff. (Unsupported method found!)");
	}
	
    
  }
  
  @Test(timeout = 4000)
  public void testRecipe2(){
	Ingredient ingredient1 = null;
	Ingredient ingredient2 = null;
	Ingredient ingredient3 = null;
	Ingredient ingredient4 = null;
	Ingredient ingredient5 = null;
	Ingredient ingredient6 = null;
	try {
		ingredient1 = new Ingredient("3 heaped g a");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		ingredient2 = new Ingredient("a heaped g a");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		ingredient3 = new Ingredient("3 heaped l");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		ae(e.getMessage(), "Ingredient wrongly formatted: '3 heaped l' (ingredient name missing)");
	}
	try {
		ingredient4 = new Ingredient("3 level kg a");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		ingredient5 = new Ingredient("3 teaspoon cookie");
		ingredient6 = new Ingredient("3 asdf cookie");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	HashMap<String, Ingredient> ingredients = new HashMap<String, Ingredient>();
	ingredients.put("1", ingredient1);
	ingredients.put("2", ingredient2);
	ingredients.put("3", ingredient3);
	ingredients.put("4", ingredient4);
	ingredients.put("5", ingredient5);
	ingredients.put("6", ingredient6);
	Recipe recipe = new Recipe("title");
	try {
		recipe.setIngredients("3 heaped g cookie\na heaped g cookie");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	recipe.setCookingTime("100 100 100 100 100");
    
	recipe.setOvenTemp("100 100 100 100 100");
	
	HashMap<String, Recipe> recipes = new HashMap<String, Recipe>();
	recipes.put("1", recipe);
	
	try {
		recipe.setMethod("123\\n456.Take a from refrigerator.Put a into the mixing bowl.Add dry ingredients mixing bowl.Remove a mixing bowl.Liquefy contents of the mixing bowl.Liquefy a.Stir for 2 minutes.Mix well.Clean mixing bowl. Pour contents of the mixing bowl into the baking dish.");
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	Kitchen kitchen = new Kitchen(recipes, recipe);
	try {
		kitchen.cook();
	} catch (ChefException e) {
		// TODO Auto-generated catch block
		ae(e.getMessage(), "Method error, recipe title, step 1: Take (Ingredient not found: a)");
	}
  }
  
  private Method getMethod(Class c, String name) throws Exception {
    Method m = c.getDeclaredMethod(name);
    m.setAccessible(true);
    return m;
  }

  private <T> void ae(T a, T b) {
    assertEquals(a, b);
  }
}
