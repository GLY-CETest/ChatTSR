package net.mooctest;

import static org.junit.Assert.*;
import net.mooctest.Method.Type;

import org.junit.Test;

public class Chef_1542441503070_MethodTest {

	@Test
	public void testa0() throws ChefException {
		try {
			Method a = new Method("a", 1);
			Method b = new Method("", 1);
		} catch (Exception e) {
			// TODO: handle exception
		}
		// assertEquals(Type.Take, a.type);
	}

	@Test
	public void testa01() throws ChefException {
		
		//assertEquals(null, a.type);
	}

	
	
}
